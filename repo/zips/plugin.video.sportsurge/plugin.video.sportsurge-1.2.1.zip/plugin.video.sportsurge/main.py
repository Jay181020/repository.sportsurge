# -*- coding: utf-8 -*-
"""
Main Kodi entry point for Sportsurge add-on (v1.2.1).
Routes incoming plugin URLs to categories, live events, 24/7 channels, replays, streams,
favorites, search, and resilient playback with stream health verification and auto-failover.
"""

import os
import sys
import json
import urllib.parse

# Ensure resources/lib is in python path
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

from scraper import SportsurgeScraper
from player import SportsurgePlayer
from resolvers import StreamResolver
from channels import SportsChannelsManager
from replays import ReplaysScraper
from favorites import FavoritesManager
from timeutils import format_status_badge, parse_event_start
import debrid
import updater


def get_settings():
    """Retrieves user settings from Kodi or defaults."""
    if not KODI_ENV:
        return {
            'base_url': 'https://v2.sportsurge.net',
            'timeout': 10,
            'preferred_quality': 0,
            'use_flaresolverr': False,
            'flaresolverr_url': 'http://127.0.0.1:8191/v1',
            'custom_user_agent': '',
            'cf_clearance': '',
            'use_proxy': False,
            'proxy_url': '',
            'auto_update_check': True,
            'github_repo': 'Jay181020/plugin.video.sportsurge',
            'github_token': '',
            'autoplay_stream': True,
            'autoplay_timeout': 4,
            'hide_finished_events': False,
            'enable_debrid': False,
            'debrid_service': '0',
            'rd_token': '',
            'ad_token': '',
        }

    addon = xbmcaddon.Addon()
    return {
        'base_url': addon.getSetting('base_url') or 'https://v2.sportsurge.net',
        'timeout': int(addon.getSetting('timeout') or 10),
        'preferred_quality': int(addon.getSetting('preferred_quality') or 0),
        'use_flaresolverr': addon.getSetting('use_flaresolverr') == 'true',
        'flaresolverr_url': addon.getSetting('flaresolverr_url') or 'http://127.0.0.1:8191/v1',
        'custom_user_agent': addon.getSetting('custom_user_agent') or '',
        'cf_clearance': addon.getSetting('cf_clearance') or '',
        'use_proxy': addon.getSetting('use_proxy') == 'true',
        'proxy_url': addon.getSetting('proxy_url') or '',
        'auto_update_check': addon.getSetting('auto_update_check') != 'false',
        'github_repo': addon.getSetting('github_repo') or 'Jay181020/plugin.video.sportsurge',
        'github_token': addon.getSetting('github_token') or '',
        'autoplay_stream': addon.getSetting('autoplay_stream') != 'false',
        'autoplay_timeout': int(addon.getSetting('autoplay_timeout') or 4),
        'hide_finished_events': addon.getSetting('hide_finished_events') == 'true',
        'enable_debrid': addon.getSetting('enable_debrid') == 'true',
        'debrid_service': addon.getSetting('debrid_service') or '0',
        'rd_token': addon.getSetting('rd_token') or '',
        'ad_token': addon.getSetting('ad_token') or '',
    }


def build_url(base, **params):
    """Builds plugin:// URL with trailing slash before query parameters."""
    clean_base = base.rstrip('/') + '/'
    return f"{clean_base}?{urllib.parse.urlencode(params)}"


def set_video_metadata(listitem, title, plot='', genre=''):
    """Sets video metadata using InfoTagVideo on Kodi 20+ with fallback."""
    if hasattr(listitem, 'getVideoInfoTag'):
        try:
            tag = listitem.getVideoInfoTag()
            tag.setTitle(title)
            if plot:
                tag.setPlot(plot)
            if genre:
                tag.setGenres([genre])
            return
        except Exception:
            pass
    listitem.setInfo('video', {'title': title, 'plot': plot, 'genre': genre})


def show_main_menu(base_url, handle, scraper):
    """Displays top-level categories in Kodi."""
    xbmcplugin.setContent(handle, 'videos')

    # 1. 24/7 Live Sports Channels
    channels_url = build_url(base_url, action='channels_groups')
    ch_item = xbmcgui.ListItem(label="📺 24/7 Live Sports Channels")
    ch_item.setContentLookup(False)
    set_video_metadata(ch_item, title="24/7 Live Sports Channels", plot="Stream 120+ live sports networks (ESPN, FS1, CBS Sports, Sky Sports, TNT, DAZN, TSN)")
    xbmcplugin.addDirectoryItem(handle, channels_url, ch_item, isFolder=True)

    # 2. Match Replays & Archives (Debrid)
    replays_url = build_url(base_url, action='replays_menu')
    rep_item = xbmcgui.ListItem(label="🎬 Match Replays & Archives (Debrid)")
    rep_item.setContentLookup(False)
    set_video_metadata(rep_item, title="Match Replays & Archives", plot="Watch full game replays in 1080p/4K with AllDebrid & Real-Debrid (NFL, F1, UFC, Premier League)")
    xbmcplugin.addDirectoryItem(handle, replays_url, rep_item, isFolder=True)

    # 3. My Favorite Teams
    fav_url = build_url(base_url, action='favorites_menu')
    fav_item = xbmcgui.ListItem(label="⭐ My Favorite Teams")
    fav_item.setContentLookup(False)
    set_video_metadata(fav_item, title="My Favorite Teams", plot="Quick access to all upcoming and live games for your bookmarked teams")
    xbmcplugin.addDirectoryItem(handle, fav_url, fav_item, isFolder=True)

    # 4. Search Matches & Channels
    search_url = build_url(base_url, action='search')
    search_item = xbmcgui.ListItem(label="🔍 Search Matches & Channels")
    search_item.setContentLookup(False)
    set_video_metadata(search_item, title="Search", plot="Search live matches, teams, fighters, and channels")
    xbmcplugin.addDirectoryItem(handle, search_url, search_item, isFolder=False)

    # 5. Live Sports Categories
    categories = scraper.get_categories()
    for cat in categories:
        url = build_url(base_url, action='category', cat_id=cat['id'], cat_name=cat['name'])
        listitem = xbmcgui.ListItem(label=cat['name'])
        listitem.setContentLookup(False)
        set_video_metadata(listitem, title=cat['name'], plot=f"Browse {cat['name']} live events")
        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=True)

    # Check for Updates item
    update_url = build_url(base_url, action='check_update')
    update_item = xbmcgui.ListItem(label="🔄 Check for Updates")
    update_item.setContentLookup(False)
    set_video_metadata(update_item, title='Check for Updates', plot='Check GitHub for newer releases and update automatically')
    xbmcplugin.addDirectoryItem(handle, update_url, update_item, isFolder=False)

    # Settings item
    settings_url = build_url(base_url, action='settings')
    settings_item = xbmcgui.ListItem(label="⚙️ Settings")
    settings_item.setContentLookup(False)
    set_video_metadata(settings_item, title='Settings', plot='Configure Auto-Play, Debrid, timezone, proxy, and quality')
    xbmcplugin.addDirectoryItem(handle, settings_url, settings_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_events(base_url, handle, scraper, cat_id, cat_name, settings, filter_team=None):
    """Lists live matches for the selected sport category with Auto-Play and Favorites support."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        events = scraper.get_live_events(category_id=cat_id)
    except Exception as e:
        err_msg = str(e)
        xbmcgui.Dialog().notification('Sportsurge', f"Error: {err_msg[:60]}", xbmcgui.NOTIFICATION_ERROR, 4000)
        events = []

    fav_mgr = FavoritesManager()
    hide_finished = settings.get('hide_finished_events', False)

    # Filter events if specific team was requested
    if filter_team:
        events = [ev for ev in events if filter_team.lower() in ev.get('title', '').lower() or any(filter_team.lower() in t.lower() for t in ev.get('teams', []))]

    filtered_events = []
    for ev in events:
        badge, status = format_status_badge(ev.get('time_text', ''))
        if hide_finished and status == 'done':
            continue
        ev['_badge'] = badge
        ev['_status'] = status
        filtered_events.append(ev)

    if not filtered_events:
        empty_item = xbmcgui.ListItem(label="No live matches currently available")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(filtered_events)
    autoplay = settings.get('autoplay_stream', True)

    for ev in filtered_events:
        matched_fav = fav_mgr.is_favorite_match(ev)
        star_prefix = "[B][COLOR gold]★[/COLOR][/B] " if matched_fav else ""

        badge = ev.get('_badge', '')
        status_tag = f"  {badge}" if badge else ""
        stream_tag = f"  [COLOR gray]({ev['stream_count']} streams)[/COLOR]" if ev.get('stream_count') else ""
        label = f"{star_prefix}{ev['title']}{status_tag}{stream_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        if autoplay:
            click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        else:
            click_url = manual_url

        listitem = xbmcgui.ListItem(label=label)
        if autoplay:
            listitem.setProperty('IsPlayable', 'true')
        listitem.setContentLookup(False)
        set_video_metadata(
            listitem,
            title=ev['title'],
            genre=ev.get('category_name', ''),
            plot=f"Category: {ev.get('category_name', '')}\nStatus: {ev.get('time_text', '')}\nAvailable Streams: {ev.get('stream_count', 0)}\n[B]Tip:[/B] Context Menu > 'Select Server Manually' to choose provider."
        )

        art = {}
        if ev.get('icon'):
            art['icon'] = ev['icon']
            art['thumb'] = ev['icon']
        if ev.get('fanart'):
            art['fanart'] = ev['fanart']
        if art:
            listitem.setArt(art)

        # Context menu items
        context_items = [
            ("Select Server Manually...", f"Container.Update({manual_url})")
        ]

        if matched_fav:
            rem_url = build_url(base_url, action='remove_fav', team=matched_fav)
            context_items.append((f"❌ Remove '{matched_fav}' from Favorites", f"RunPlugin({rem_url})"))
        else:
            teams = ev.get('teams', [])
            if teams:
                for t in teams[:2]:
                    if t:
                        add_url = build_url(base_url, action='add_fav', team=t)
                        context_items.append((f"⭐ Add '{t}' to Favorites", f"RunPlugin({add_url})"))
            else:
                add_url = build_url(base_url, action='add_fav', team=ev['title'])
                context_items.append(("⭐ Add to Favorite Teams", f"RunPlugin({add_url})"))

        listitem.addContextMenuItems(context_items)
        xbmcplugin.addDirectoryItem(handle, click_url, listitem, isFolder=not autoplay, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def handle_match_autoplay(base_url, handle, scraper, match_url, match_title, icon, settings):
    """
    Smart Auto-Play with Live Stream Verification and Failover:
    Probes servers with an HTTP Range/HEAD live health check, skips dead feeds,
    and seamlessly launches the best responding 1080p/720p stream.
    """
    try:
        streams = scraper.get_match_streams(match_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Sportsurge', f"Error fetching streams: {e}", xbmcgui.NOTIFICATION_ERROR)
        streams = []

    if not streams:
        xbmcgui.Dialog().notification('Sportsurge', 'No active stream servers found', xbmcgui.NOTIFICATION_WARNING)
        return

    # Sort streams by quality: 1080p > 720p, Gold > Silver > Bronze
    def sort_key(s):
        score = 0
        if '1080' in s.get('resolution', ''): score += 10
        if '60fps' in s.get('fps', ''): score += 5
        if s.get('tier') in ('HD', 'Gold'): score += 10
        return score

    sorted_streams = sorted(streams, key=sort_key, reverse=True)
    probe_timeout = settings.get('autoplay_timeout', 4)

    resolver = StreamResolver(
        user_agent=settings['custom_user_agent'],
        timeout=probe_timeout,
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url']
    )

    xbmcgui.Dialog().notification('Sportsurge Auto-Play', f"Testing streams for: {match_title[:28]}...", icon or xbmcgui.NOTIFICATION_INFO, 2500)

    candidates = sorted_streams[:8]
    verified_streams = []

    for idx, s in enumerate(candidates):
        res_url, headers = resolver.resolve(s['url'])
        if res_url and ('.m3u8' in res_url or '.mpd' in res_url):
            # Stream health check: ensure it actually returns HTTP 200 / #EXTM3U
            is_alive = resolver.verify_stream_live(res_url, headers=headers, timeout=2.0)
            if is_alive:
                verified_streams.append({
                    'url': res_url,
                    'headers': headers,
                    'site_name': s['site_name']
                })
                # Top quality working stream confirmed, launch immediately!
                break

    player = SportsurgePlayer(
        handle=handle,
        user_agent=settings['custom_user_agent'],
        timeout=settings['timeout'],
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url']
    )

    if verified_streams:
        primary = verified_streams[0]
        xbmcgui.Dialog().notification('Sportsurge', f"Auto-Playing: {primary['site_name']}", icon or xbmcgui.NOTIFICATION_INFO, 2000)

        success = player.play_resolved(
            primary['url'],
            headers=primary['headers'],
            title=f"{match_title} ({primary['site_name']})",
            icon=icon,
            referer=match_url
        )

        # If primary stream failed during Kodi player handoff, trigger instant failover to backup
        if not success and len(verified_streams) > 1:
            backup = verified_streams[1]
            xbmcgui.Dialog().notification('Sportsurge', f"Server 1 dropped. Switching to {backup['site_name']}...", icon or xbmcgui.NOTIFICATION_WARNING, 3000)
            player.play_resolved(
                backup['url'],
                headers=backup['headers'],
                title=f"{match_title} ({backup['site_name']})",
                icon=icon,
                referer=match_url
            )
    else:
        # Fall back to manual server selection if no stream passed probe
        xbmcgui.Dialog().notification('Sportsurge', 'No stream passed health check. Showing server list.', xbmcgui.NOTIFICATION_INFO, 2500)
        show_streams(base_url, handle, scraper, match_url, match_title, icon)


def show_streams(base_url, handle, scraper, match_url, match_title, icon):
    """Lists all available stream links for a specific match."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        streams = scraper.get_match_streams(match_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Sportsurge', f"Error fetching streams: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        streams = []

    if not streams:
        empty_item = xbmcgui.ListItem(label="No streams found for this match")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(streams)
    for s in streams:
        url = build_url(
            base_url,
            action='play',
            stream_url=s['url'],
            title=f"{match_title} - {s['site_name']}",
            icon=icon,
            referer=match_url
        )

        tier = s.get('tier', '')
        res = s.get('resolution', '')
        fps = s.get('fps', '')
        ads = s.get('ads', '')
        lang = s.get('language', '')

        tier_color = 'gold' if tier == 'Gold' else ('silver' if tier == 'Silver' else 'lightblue')
        tier_tag = f"[COLOR {tier_color}][{tier}][/COLOR] " if tier else ""
        res_tag = f"[B]{res}[/B]" if res else "HD"
        fps_tag = f" {fps}" if fps and '60' in fps else ""
        ads_tag = f" | [COLOR green]{ads}[/COLOR]" if ads else ""
        lang_tag = f" | {lang}" if lang and lang != 'EN' else ""

        label = f"{tier_tag}{s['site_name']} - {res_tag}{fps_tag}{ads_tag}{lang_tag}"

        listitem = xbmcgui.ListItem(label=label)
        listitem.setProperty('IsPlayable', 'true')
        listitem.setContentLookup(False)
        set_video_metadata(
            listitem,
            title=f"{match_title} - {s['site_name']}",
            plot=f"Provider: {s['site_name']}\nQuality: {res} {fps}\nLanguage: {lang}\nAds: {ads}"
        )

        if icon:
            listitem.setArt({'icon': icon, 'thumb': icon})

        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_favorites_menu(base_url, handle, scraper):
    """Displays the Favorites top-level menu."""
    xbmcplugin.setContent(handle, 'videos')
    fav_mgr = FavoritesManager()
    favs = fav_mgr.get_favorites()

    # 1. View All Favorite Games
    all_url = build_url(base_url, action='favorites_all')
    all_item = xbmcgui.ListItem(label="⭐ View All Matches for Favorited Teams")
    all_item.setContentLookup(False)
    set_video_metadata(all_item, title="All Favorite Matches", plot="Shows all live and upcoming games involving any of your saved favorite teams.")
    xbmcplugin.addDirectoryItem(handle, all_url, all_item, isFolder=True)

    # 2. List each team individually
    for team in favs:
        team_url = build_url(base_url, action='favorites_team', team=team)
        item = xbmcgui.ListItem(label=f"★ {team}")
        item.setContentLookup(False)
        set_video_metadata(item, title=team, plot=f"View upcoming and live games for {team}")

        rem_url = build_url(base_url, action='remove_fav', team=team)
        item.addContextMenuItems([
            (f"❌ Remove '{team}' from Favorites", f"RunPlugin({rem_url})")
        ])
        xbmcplugin.addDirectoryItem(handle, team_url, item, isFolder=True)

    # 3. Add Team Manually
    add_url = build_url(base_url, action='add_fav_prompt')
    add_item = xbmcgui.ListItem(label="➕ Add New Team to Favorites...")
    add_item.setContentLookup(False)
    set_video_metadata(add_item, title="Add Team", plot="Type the name of any sports team or athlete to add to favorites.")
    xbmcplugin.addDirectoryItem(handle, add_url, add_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_all_favorite_events(base_url, handle, scraper, settings):
    """Lists all upcoming & live events for all favorited teams."""
    fav_mgr = FavoritesManager()
    favs = fav_mgr.get_favorites()

    if not favs:
        empty_item = xbmcgui.ListItem(label="No favorite teams added yet. Right-click any match to bookmark your team!")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    xbmcplugin.setContent(handle, 'videos')
    try:
        events = scraper.get_live_events('all')
    except Exception:
        events = []

    matched = []
    for ev in events:
        if fav_mgr.is_favorite_match(ev):
            matched.append(ev)

    if not matched:
        empty_item = xbmcgui.ListItem(label="No upcoming or live matches found for your favorite teams.")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    # Reuse show_events rendering
    autoplay = settings.get('autoplay_stream', True)
    for ev in matched:
        badge, _ = format_status_badge(ev.get('time_text', ''))
        status_tag = f"  {badge}" if badge else ""
        label = f"[B][COLOR gold]★[/COLOR][/B] {ev['title']}{status_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', '')) if autoplay else manual_url

        item = xbmcgui.ListItem(label=label)
        if autoplay:
            item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ev['title'], genre=ev.get('category_name', ''), plot=f"Category: {ev.get('category_name', '')}")
        item.addContextMenuItems([("Select Server Manually...", f"Container.Update({manual_url})")])
        xbmcplugin.addDirectoryItem(handle, click_url, item, isFolder=not autoplay, totalItems=len(matched))

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def handle_search(base_url, handle, scraper, settings):
    """Prompts for search query and displays matching live events & channels."""
    dialog = xbmcgui.Dialog()
    query = dialog.input("Search Sportsurge (e.g. Chiefs, Arsenal, F1, ESPN)...")
    if not query:
        return

    q_lower = query.lower().strip()
    xbmcplugin.setContent(handle, 'videos')

    # 1. Search live events
    try:
        events = scraper.get_live_events('all')
    except Exception:
        events = []

    matched_events = [
        ev for ev in events
        if q_lower in ev.get('title', '').lower()
        or any(q_lower in t.lower() for t in ev.get('teams', []))
        or q_lower in ev.get('category_name', '').lower()
    ]

    # 2. Search 24/7 channels
    channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
    all_channels = channels_mgr.get_all_channels()
    matched_channels = [
        ch for ch in all_channels.values()
        if q_lower in ch['name'].lower()
    ]

    total_results = len(matched_events) + len(matched_channels)
    if total_results == 0:
        empty_item = xbmcgui.ListItem(label=f"No results found for '{query}'")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    autoplay = settings.get('autoplay_stream', True)

    # Render channels first
    for ch in matched_channels:
        ch_url = build_url(
            base_url,
            action='play_channel',
            ch_name=ch['name'],
            ch_links=json.dumps(ch['links']),
            icon=ch.get('icon', '')
        )
        item = xbmcgui.ListItem(label=f"📺 [B]{ch['name']}[/B] [COLOR gold](Live Channel)[/COLOR]")
        item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ch['name'], plot="24/7 Live Sports Channel")
        if ch.get('icon'):
            item.setArt({'icon': ch['icon'], 'thumb': ch['icon']})
        xbmcplugin.addDirectoryItem(handle, ch_url, item, isFolder=False, totalItems=total_results)

    # Render events
    for ev in matched_events:
        badge, _ = format_status_badge(ev.get('time_text', ''))
        status_tag = f"  {badge}" if badge else ""
        label = f"🔴 {ev['title']}{status_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', '')) if autoplay else manual_url

        item = xbmcgui.ListItem(label=label)
        if autoplay:
            item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ev['title'], genre=ev.get('category_name', ''), plot=f"Category: {ev.get('category_name', '')}")
        item.addContextMenuItems([("Select Server Manually...", f"Container.Update({manual_url})")])
        xbmcplugin.addDirectoryItem(handle, click_url, item, isFolder=not autoplay, totalItems=total_results)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_channels_groups(base_url, handle, channels_mgr):
    """Displays channel regional groups (US/CA, UK/EU, All A-Z)."""
    xbmcplugin.setContent(handle, 'videos')
    groups = channels_mgr.get_channel_groups()
    for g in groups:
        url = build_url(base_url, action='channels_list', group_id=g['id'], group_name=g['name'])
        item = xbmcgui.ListItem(label=g['name'])
        item.setContentLookup(False)
        set_video_metadata(item, title=g['name'], plot=f"Browse {g['name']}")
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # 4. Export M3U for IPTV Simple Client
    export_url = build_url(base_url, action='export_m3u')
    export_item = xbmcgui.ListItem(label="📋 Export Channels to IPTV Simple Client (.m3u)")
    export_item.setContentLookup(False)
    set_video_metadata(export_item, title="Export Channels to M3U", plot="Exports all 120+ live sports networks to an M3U playlist file for IPTV Simple Client / Live TV guide.")
    xbmcplugin.addDirectoryItem(handle, export_url, export_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_channels_list(base_url, handle, channels_mgr, group_id):
    """Lists individual 24/7 channels for a specific group."""
    xbmcplugin.setContent(handle, 'videos')
    channels = channels_mgr.get_channels_by_group(group_id)

    if not channels:
        empty_item = xbmcgui.ListItem(label="No channels available at this time")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(channels)
    for ch in channels:
        ch_links_json = json.dumps(ch['links'])
        url = build_url(
            base_url,
            action='play_channel',
            ch_name=ch['name'],
            ch_links=ch_links_json,
            icon=ch.get('icon', '')
        )
        lang_tag = f" [{ch['language']}]" if ch.get('language') else ""
        mirror_tag = f" ({len(ch['links'])} mirrors)" if len(ch['links']) > 1 else ""
        label = f"{ch['name']}{lang_tag}{mirror_tag}"

        item = xbmcgui.ListItem(label=label)
        item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ch['name'], plot=f"24/7 Live Stream for {ch['name']}\nAvailable Mirrors: {len(ch['links'])}")

        if ch.get('icon'):
            item.setArt({'icon': ch['icon'], 'thumb': ch['icon']})

        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def play_channel(base_url, handle, ch_name, ch_links_json, icon, settings):
    """Plays a 24/7 channel with automatic mirror failover."""
    try:
        links = json.loads(ch_links_json)
    except Exception:
        links = []

    if not links:
        xbmcgui.Dialog().notification('Sportsurge', 'No stream links found for channel', xbmcgui.NOTIFICATION_WARNING)
        return

    resolver = StreamResolver(user_agent=settings['custom_user_agent'], timeout=settings['timeout'], use_proxy=settings['use_proxy'], proxy_url=settings['proxy_url'])
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create("Sportsurge Channels", f"Connecting to {ch_name}...")

    resolved_url = None
    final_headers = None

    for idx, lnk in enumerate(links):
        if p_dialog.iscanceled():
            break
        p_dialog.update(int(((idx + 1) / len(links)) * 100), f"Connecting to mirror {idx + 1}/{len(links)}...")
        res_url, headers = resolver.resolve(lnk)
        if res_url and ('.m3u8' in res_url or '.mpd' in res_url):
            if resolver.verify_stream_live(res_url, headers=headers, timeout=2.0):
                resolved_url = res_url
                final_headers = headers
                break

    p_dialog.close()

    if resolved_url:
        player = SportsurgePlayer(handle=handle, user_agent=settings['custom_user_agent'], timeout=settings['timeout'], use_proxy=settings['use_proxy'], proxy_url=settings['proxy_url'])
        player.play_resolved(resolved_url, headers=final_headers, title=ch_name, icon=icon)
    else:
        xbmcgui.Dialog().notification('Sportsurge', f"All mirrors offline for {ch_name}", xbmcgui.NOTIFICATION_ERROR)


def show_replays_menu(base_url, handle, replays_scraper):
    """Displays replay sports categories (F1, Premier League, UFC, NFL, NBA)."""
    xbmcplugin.setContent(handle, 'videos')
    categories = replays_scraper.get_categories()
    for cat in categories:
        url = build_url(base_url, action='replays_category', cat_id=cat['id'], cat_name=cat['name'])
        item = xbmcgui.ListItem(label=cat['name'])
        item.setContentLookup(False)
        set_video_metadata(item, title=cat['name'], plot=f"Browse {cat['name']}")
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_replays_list(base_url, handle, replays_scraper, cat_id, cat_name):
    """Lists match replays available for category."""
    xbmcplugin.setContent(handle, 'videos')
    replays = replays_scraper.get_replays_for_category(cat_id)

    if not replays:
        empty_item = xbmcgui.ListItem(label=f"No replays found for {cat_name}")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(replays)
    for r in replays:
        url = build_url(base_url, action='replay_sources', article_url=r['url'], title=r['title'], icon=r.get('icon', ''))
        label = f"{r['title']} [COLOR lightblue]({r.get('date', '')})[/COLOR]" if r.get('date') else r['title']

        item = xbmcgui.ListItem(label=label)
        item.setContentLookup(False)
        set_video_metadata(item, title=r['title'], plot=f"Category: {r.get('category', '')}\nDate: {r.get('date', '')}")

        if r.get('icon'):
            item.setArt({'icon': r['icon'], 'thumb': r['icon']})

        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_replay_sources(base_url, handle, replays_scraper, article_url, title, icon):
    """Lists video download/stream sources for replay article."""
    xbmcplugin.setContent(handle, 'videos')
    sources = replays_scraper.get_replay_video_sources(article_url)

    if not sources:
        empty_item = xbmcgui.ListItem(label="No stream sources found for this replay")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(sources)
    for s in sources:
        url = build_url(base_url, action='play_replay', source_url=s['url'], title=f"{title} - {s['title']}", icon=icon)
        item = xbmcgui.ListItem(label=s['title'])
        item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=s['title'], plot=f"Hoster: {s['hoster']}\nURL: {s['url']}")
        if icon:
            item.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def play_replay(base_url, handle, source_url, title, icon, settings):
    """Resolves and plays replay via Debrid, ResolveURL, or direct link."""
    replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
    stream_url = replays_scraper.resolve_replay_stream(
        source_url,
        debrid_enabled=settings['enable_debrid'],
        debrid_service=settings['debrid_service'],
        rd_token=settings['rd_token'],
        ad_token=settings['ad_token']
    )

    if stream_url:
        player = SportsurgePlayer(handle=handle, user_agent=settings['custom_user_agent'], timeout=settings['timeout'], use_proxy=settings['use_proxy'], proxy_url=settings['proxy_url'])
        player.play_resolved(stream_url, title=title, icon=icon)
    else:
        xbmcgui.Dialog().notification('Sportsurge', 'Unable to resolve replay stream link', xbmcgui.NOTIFICATION_ERROR)


# ==========================================
# Main Router
# ==========================================

def router(argv):
    """Parses Kodi command line and routes to appropriate handler."""
    base_url = argv[0]
    handle = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else -1
    query = argv[2][1:] if len(argv) > 2 and argv[2].startswith('?') else ''
    params = dict(urllib.parse.parse_qsl(query))

    settings = get_settings()
    scraper = SportsurgeScraper(
        base_url=settings['base_url'],
        user_agent=settings['custom_user_agent'],
        cf_clearance=settings['cf_clearance'],
        use_flaresolverr=settings['use_flaresolverr'],
        flaresolverr_url=settings['flaresolverr_url'],
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url'],
        timeout=settings['timeout']
    )

    action = params.get('action')

    if not action or action == 'root':
        show_main_menu(base_url, handle, scraper)
    elif action == 'category':
        cat_id = params.get('cat_id', 'all')
        cat_name = params.get('cat_name', 'Live Sports')
        show_events(base_url, handle, scraper, cat_id, cat_name, settings)
    elif action == 'match':
        match_url = params.get('match_url', '')
        match_title = params.get('match_title', 'Match Streams')
        icon = params.get('icon', '')
        show_streams(base_url, handle, scraper, match_url, match_title, icon)
    elif action == 'match_autoplay':
        match_url = params.get('match_url', '')
        match_title = params.get('match_title', 'Match Streams')
        icon = params.get('icon', '')
        handle_match_autoplay(base_url, handle, scraper, match_url, match_title, icon, settings)
    elif action == 'favorites_menu':
        show_favorites_menu(base_url, handle, scraper)
    elif action == 'favorites_all':
        show_all_favorite_events(base_url, handle, scraper, settings)
    elif action == 'favorites_team':
        team = params.get('team', '')
        show_events(base_url, handle, scraper, 'all', team, settings, filter_team=team)
    elif action == 'add_fav':
        team = params.get('team', '')
        fav_mgr = FavoritesManager()
        if fav_mgr.add_favorite(team):
            xbmcgui.Dialog().notification('Sportsurge', f"Added '{team}' to Favorite Teams ⭐", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'remove_fav':
        team = params.get('team', '')
        fav_mgr = FavoritesManager()
        if fav_mgr.remove_favorite(team):
            xbmcgui.Dialog().notification('Sportsurge', f"Removed '{team}' from Favorites", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'add_fav_prompt':
        dialog = xbmcgui.Dialog()
        team = dialog.input("Enter Team or Fighter Name:")
        if team:
            fav_mgr = FavoritesManager()
            fav_mgr.add_favorite(team)
            xbmcgui.Dialog().notification('Sportsurge', f"Added '{team}' to Favorites ⭐", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'search':
        handle_search(base_url, handle, scraper, settings)
    elif action == 'channels_groups':
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_channels_groups(base_url, handle, channels_mgr)
    elif action == 'channels_list':
        group_id = params.get('group_id', 'all')
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_channels_list(base_url, handle, channels_mgr, group_id)
    elif action == 'export_m3u':
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        playlists_dir = ''
        try:
            playlists_dir = xbmcvfs.translatePath('special://userdata/playlists')
        except Exception:
            try:
                playlists_dir = xbmc.translatePath('special://userdata/playlists')
            except Exception:
                pass
        if not playlists_dir:
            playlists_dir = os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming', 'Kodi', 'userdata', 'playlists')
        os.makedirs(playlists_dir, exist_ok=True)
        m3u_path = os.path.join(playlists_dir, 'sportsurge_channels.m3u')
        count = channels_mgr.export_m3u_playlist(m3u_path)
        xbmcgui.Dialog().notification('Sportsurge', f"Exported {count} channels to IPTV playlist!", xbmcgui.NOTIFICATION_INFO, 4000)
    elif action == 'play_channel':
        ch_name = params.get('ch_name', 'Live Channel')
        ch_links = params.get('ch_links', '[]')
        icon = params.get('icon', '')
        play_channel(base_url, handle, ch_name, ch_links, icon, settings)
    elif action == 'replays_menu':
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replays_menu(base_url, handle, replays_scraper)
    elif action == 'replays_category':
        cat_id = params.get('cat_id', 'f1')
        cat_name = params.get('cat_name', 'Replays')
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replays_list(base_url, handle, replays_scraper, cat_id, cat_name)
    elif action == 'replay_sources':
        article_url = params.get('article_url', '')
        title = params.get('title', 'Replay')
        icon = params.get('icon', '')
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replay_sources(base_url, handle, replays_scraper, article_url, title, icon)
    elif action == 'play_replay':
        source_url = params.get('source_url', '')
        title = params.get('title', 'Replay Video')
        icon = params.get('icon', '')
        play_replay(base_url, handle, source_url, title, icon, settings)
    elif action == 'auth_rd':
        debrid.authorize_real_debrid()
    elif action == 'auth_ad':
        debrid.authorize_alldebrid()
    elif action == 'sync_debrid':
        debrid.sync_debrid_from_system()
    elif action == 'play':
        stream_url = params.get('stream_url', '')
        title = params.get('title', 'Live Stream')
        icon = params.get('icon', '')
        referer = params.get('referer', settings['base_url'])
        player = SportsurgePlayer(
            handle=handle,
            user_agent=settings['custom_user_agent'],
            timeout=settings['timeout'],
            use_proxy=settings['use_proxy'],
            proxy_url=settings['proxy_url']
        )
        player.play(stream_url, title=title, icon=icon, referer=referer)
    elif action == 'check_update':
        updater.check_and_apply_update(manual=True)
    elif action == 'settings':
        if KODI_ENV:
            xbmcaddon.Addon().openSettings()


if __name__ == '__main__':
    router(sys.argv)
