# -*- coding: utf-8 -*-
"""
Debrid manager for Real-Debrid and AllDebrid.
Supports OAuth device pairing, PIN pairing, and link unrestricting for buffer-free streaming.
"""

import json
import time
import urllib.request
import urllib.parse

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

RD_CLIENT_ID = 'X245A4XAIBGVM'
RD_API_BASE = 'https://api.real-debrid.com'
AD_API_BASE = 'https://api.alldebrid.com/v4'
AGENT_NAME = 'sportsurge-kodi'


class RealDebridClient:
    def __init__(self, token=''):
        self.token = (token or '').strip()

    def get_device_code(self):
        """Initiates OAuth device code flow."""
        url = f"{RD_API_BASE}/oauth/v2/device/code?client_id={RD_CLIENT_ID}&new_credentials=yes"
        req = urllib.request.Request(url, headers={'User-Agent': AGENT_NAME})
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read().decode('utf-8'))

    def check_credentials(self, device_code):
        """Polls for user authorization on real-debrid.com/device."""
        url = f"{RD_API_BASE}/oauth/v2/device/credentials?client_id={RD_CLIENT_ID}&code={device_code}"
        req = urllib.request.Request(url, headers={'User-Agent': AGENT_NAME})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except urllib.error.HTTPError:
            return None

    def exchange_token(self, client_id, client_secret, device_code):
        """Exchanges credentials for an access token."""
        url = f"{RD_API_BASE}/oauth/v2/token"
        data = urllib.parse.urlencode({
            'client_id': client_id,
            'client_secret': client_secret,
            'code': device_code,
            'grant_type': 'http://oauth.net/grant_type/device/1.0'
        }).encode('utf-8')
        req = urllib.request.Request(url, data=data, headers={'User-Agent': AGENT_NAME})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return data.get('access_token')

    def unrestrict(self, link):
        """Unrestricts a filehoster or mega link to a direct high-speed CDN stream."""
        if not self.token:
            return None
        url = f"{RD_API_BASE}/rest/1.0/unrestrict/link"
        data = urllib.parse.urlencode({'link': link}).encode('utf-8')
        headers = {
            'User-Agent': AGENT_NAME,
            'Authorization': f"Bearer {self.token}"
        }
        req = urllib.request.Request(url, data=data, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                res = json.loads(resp.read().decode('utf-8'))
                return res.get('download')
        except Exception as e:
            if KODI_ENV:
                xbmc.log(f"[Sportsurge RD] Unrestrict error: {e}", xbmc.LOGWARNING)
            return None

    def get_user_info(self):
        """Returns user profile information."""
        if not self.token:
            return None
        url = f"{RD_API_BASE}/rest/1.0/user"
        headers = {'User-Agent': AGENT_NAME, 'Authorization': f"Bearer {self.token}"}
        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception:
            return None


class AllDebridClient:
    def __init__(self, api_key=''):
        self.api_key = (api_key or '').strip()

    def get_pin(self):
        """Gets PIN code for user pairing."""
        url = f"{AD_API_BASE}/pin/get?agent={AGENT_NAME}"
        req = urllib.request.Request(url, headers={'User-Agent': AGENT_NAME})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            return data.get('data', {})

    def check_pin(self, check, pin):
        """Polls for PIN validation on alldebrid.com/pin."""
        url = f"{AD_API_BASE}/pin/check?agent={AGENT_NAME}&check={check}&pin={pin}"
        req = urllib.request.Request(url, headers={'User-Agent': AGENT_NAME})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                return data.get('data', {}).get('apikey')
        except Exception:
            return None

    def unrestrict(self, link):
        """Unlocks a link using AllDebrid."""
        if not self.api_key:
            return None
        url = f"{AD_API_BASE}/link/unlock?agent={AGENT_NAME}&apikey={self.api_key}&link={urllib.parse.quote(link)}"
        req = urllib.request.Request(url, headers={'User-Agent': AGENT_NAME})
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data.get('status') == 'success':
                    return data.get('data', {}).get('link')
        except Exception as e:
            if KODI_ENV:
                xbmc.log(f"[Sportsurge AD] Unlock error: {e}", xbmc.LOGWARNING)
            return None


def authorize_real_debrid():
    """Runs interactive Kodi dialog for Real-Debrid OAuth pairing."""
    if not KODI_ENV:
        return
    client = RealDebridClient()
    try:
        code_data = client.get_device_code()
    except Exception as e:
        xbmcgui.Dialog().notification("Real-Debrid", f"Failed to get code: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    device_code = code_data['device_code']
    user_code = code_data['user_code']
    verification_url = code_data.get('verification_url', 'https://real-debrid.com/device')
    interval = code_data.get('interval', 5)
    expires_in = code_data.get('expires_in', 900)

    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create(
        "Real-Debrid Authorization",
        f"1. Open a browser and go to: {verification_url}\n"
        f"2. Enter code: [B]{user_code}[/B]\n\n"
        "Waiting for confirmation..."
    )

    start_time = time.time()
    token = None

    while time.time() - start_time < expires_in:
        if p_dialog.iscanceled():
            break
        pct = int(((time.time() - start_time) / expires_in) * 100)
        p_dialog.update(pct)
        time.sleep(interval)

        creds = client.check_credentials(device_code)
        if creds and 'client_id' in creds:
            token = client.exchange_token(creds['client_id'], creds['client_secret'], device_code)
            break

    p_dialog.close()

    if token:
        addon = xbmcaddon.Addon()
        addon.setSetting('rd_token', token)
        addon.setSetting('enable_debrid', 'true')
        addon.setSetting('debrid_service', '0')
        xbmcgui.Dialog().ok("Real-Debrid", "Authorization Successful!\nReal-Debrid is now enabled.")
    else:
        xbmcgui.Dialog().notification("Real-Debrid", "Authorization timed out or cancelled.", xbmcgui.NOTIFICATION_WARNING)


def authorize_alldebrid():
    """Runs interactive Kodi dialog for AllDebrid PIN pairing."""
    if not KODI_ENV:
        return
    client = AllDebridClient()
    try:
        pin_data = client.get_pin()
    except Exception as e:
        xbmcgui.Dialog().notification("AllDebrid", f"Failed to get PIN: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    pin = pin_data.get('pin')
    check = pin_data.get('check')
    user_url = pin_data.get('user_url', 'https://alldebrid.com/pin')
    expires_in = pin_data.get('expires_in', 600)

    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create(
        "AllDebrid Authorization",
        f"1. Open a browser and go to: {user_url}\n"
        f"2. Enter PIN: [B]{pin}[/B]\n\n"
        "Waiting for confirmation..."
    )

    start_time = time.time()
    api_key = None

    while time.time() - start_time < expires_in:
        if p_dialog.iscanceled():
            break
        pct = int(((time.time() - start_time) / expires_in) * 100)
        p_dialog.update(pct)
        time.sleep(4)

        api_key = client.check_pin(check, pin)
        if api_key:
            break

    p_dialog.close()

    if api_key:
        addon = xbmcaddon.Addon()
        addon.setSetting('ad_token', api_key)
        addon.setSetting('enable_debrid', 'true')
        addon.setSetting('debrid_service', '1')
        xbmcgui.Dialog().ok("AllDebrid", "Authorization Successful!\nAllDebrid is now enabled.")
    else:
        xbmcgui.Dialog().notification("AllDebrid", "Authorization timed out or cancelled.", xbmcgui.NOTIFICATION_WARNING)


def sync_debrid_from_system():
    """
    Auto-detects and imports Real-Debrid and AllDebrid authorizations
    from script.module.acctmgr (Account Manager) or script.module.resolveurl.
    Returns (success: bool, msg: str)
    """
    if not KODI_ENV:
        return False, "Not running in Kodi"

    addon = xbmcaddon.Addon()
    synced_services = []

    # 1. Try script.module.acctmgr (Account Manager)
    try:
        acctmgr = xbmcaddon.Addon('script.module.acctmgr')
        rd_token = acctmgr.getSetting('realdebrid.token')
        if rd_token and not addon.getSetting('rd_token'):
            addon.setSetting('rd_token', rd_token)
            addon.setSetting('enable_debrid', 'true')
            addon.setSetting('debrid_service', '0')
            synced_services.append("Real-Debrid (Account Manager)")

        ad_token = acctmgr.getSetting('alldebrid.token')
        if ad_token and not addon.getSetting('ad_token'):
            addon.setSetting('ad_token', ad_token)
            addon.setSetting('enable_debrid', 'true')
            if not synced_services:
                addon.setSetting('debrid_service', '1')
            synced_services.append("AllDebrid (Account Manager)")
    except Exception:
        pass

    # 2. Try script.module.resolveurl (ResolveURL)
    try:
        resurl = xbmcaddon.Addon('script.module.resolveurl')
        if not addon.getSetting('rd_token'):
            rd_token = resurl.getSetting('RealDebridResolver_token')
            if rd_token:
                addon.setSetting('rd_token', rd_token)
                addon.setSetting('enable_debrid', 'true')
                addon.setSetting('debrid_service', '0')
                synced_services.append("Real-Debrid (ResolveURL)")

        if not addon.getSetting('ad_token'):
            ad_token = resurl.getSetting('AllDebridResolver_token')
            if ad_token:
                addon.setSetting('ad_token', ad_token)
                addon.setSetting('enable_debrid', 'true')
                if not synced_services:
                    addon.setSetting('debrid_service', '1')
                synced_services.append("AllDebrid (ResolveURL)")
    except Exception:
        pass

    if synced_services:
        summary = "\n".join(f"• {s}" for s in synced_services)
        xbmcgui.Dialog().ok("Debrid Auto-Sync", f"Successfully synced Debrid credentials:\n\n{summary}\n\nDebrid is now enabled in Sportsurge!")
        return True, summary
    else:
        xbmcgui.Dialog().notification("Debrid Auto-Sync", "No active accounts found in Account Manager or ResolveURL.", xbmcgui.NOTIFICATION_INFO, 3500)
        return False, "No active accounts found"

