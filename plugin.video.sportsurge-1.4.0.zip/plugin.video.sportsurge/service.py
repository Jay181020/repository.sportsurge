# -*- coding: utf-8 -*-
"""
Sportsurge Background Service.
Runs on Kodi startup to automatically trigger repository updates,
check for add-on updates, and silently auto-update Sportsurge.
"""

import os
import sys
import time
import threading

ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

try:
    import xbmc
    import xbmcaddon
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

import updater
import iptv_server


def startup_update_worker():
    """Waits for Kodi network initialization, then checks and applies updates."""
    if not KODI_ENV:
        return

    # Wait 8 seconds after Kodi startup to allow network/DNS to be fully ready
    for _ in range(8):
        if xbmc.Monitor().abortRequested():
            return
        time.sleep(1)

    try:
        addon = xbmcaddon.Addon()
        auto_check = addon.getSetting('auto_update_check') != 'false'
        if not auto_check:
            return

        # Trigger Kodi repository update
        xbmc.executebuiltin('UpdateAddonRepos')
        xbmc.executebuiltin('UpdateLocalAddons')

        # Check and apply silent update for Sportsurge
        updater.check_and_apply_update(manual=False, silent=True)
    except Exception as e:
        xbmc.log(f"[Sportsurge Service] Error in startup update worker: {e}", xbmc.LOGWARNING)


def run_service():
    if not KODI_ENV:
        return

    addon = xbmcaddon.Addon()
    monitor = xbmc.Monitor()

    # Start IPTV Proxy Server for TiviMate Multi-View (if enabled)
    iptv_enabled = addon.getSetting('iptv_server_enabled') != 'false'
    try:
        port = int(addon.getSetting('iptv_server_port') or '8899')
    except (ValueError, TypeError):
        port = 8899

    if iptv_enabled:
        started, server_url = iptv_server.start_iptv_server(port=port)
        if started:
            xbmc.log(f"[Sportsurge Service] IPTV Server started at {server_url}", xbmc.LOGINFO)
        else:
            xbmc.log(f"[Sportsurge Service] Failed to start IPTV Server: {server_url}", xbmc.LOGWARNING)

    # Start repository update worker
    t = threading.Thread(target=startup_update_worker)
    t.daemon = True
    t.start()

    # Keep service alive until Kodi shuts down
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break

    # Clean shutdown of IPTV Proxy Server
    if iptv_enabled:
        iptv_server.stop_iptv_server()
        xbmc.log("[Sportsurge Service] IPTV Server stopped.", xbmc.LOGINFO)


if __name__ == '__main__':
    run_service()

