# -*- coding: utf-8 -*-
"""
Auto-updater module for Sportsurge Kodi Add-on.
Supports private GitHub repositories with Personal Access Token authentication.
"""

import os
import sys
import re
import json
import shutil
import zipfile
import urllib.request
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False


DEFAULT_REPO = "Jay181020/plugin.video.sportsurge"


def parse_version(v_str):
    """Parses a version string like '1.2.3' or 'v1.2.3' into a tuple of ints."""
    cleaned = v_str.strip().lstrip('vV')
    parts = re.findall(r'\d+', cleaned)
    return tuple(int(p) for p in parts) if parts else (0,)


def get_current_version():
    """Reads current addon version from addon.xml."""
    try:
        addon_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
        xml_path = os.path.join(addon_dir, 'addon.xml')
        if os.path.exists(xml_path):
            tree = ET.parse(xml_path)
            root = tree.getroot()
            return root.attrib.get('version', '1.0.0')
    except Exception:
        pass
    if KODI_ENV:
        try:
            return xbmcaddon.Addon().getAddonInfo('version')
        except Exception:
            pass
    return '1.0.0'


def get_addons_folder():
    """Returns the absolute path to Kodi's addons directory."""
    if KODI_ENV:
        special_path = xbmcvfs.translatePath('special://home/addons')
        return os.path.abspath(special_path)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', '..'))


def fetch_latest_release(repo=DEFAULT_REPO, token=None, timeout=10):
    """
    Queries GitHub API for the latest release.
    Returns (tag_name, download_url, release_notes) or (None, None, None).
    """
    api_url = f"https://api.github.com/repos/{repo}/releases/latest"
    headers = {
        'User-Agent': 'Kodi-Sportsurge-Updater',
        'Accept': 'application/vnd.github.v3+json'
    }
    if token:
        headers['Authorization'] = f"token {token.strip()}"

    req = urllib.request.Request(api_url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            tag = data.get('tag_name', '')
            notes = data.get('body', '')

            assets = data.get('assets', [])
            zip_url = None
            for a in assets:
                name = a.get('name', '').lower()
                if name.endswith('.zip') and 'sportsurge' in name:
                    zip_url = a.get('url') or a.get('browser_download_url')
                    break

            if not zip_url:
                zip_url = data.get('zipball_url')

            return tag, zip_url, notes
    except Exception as e:
        if KODI_ENV:
            xbmc.log(f"[Sportsurge Updater] Error checking releases: {e}", xbmc.LOGWARNING)
        return None, None, str(e)


def download_zip(url, dest_file, token=None, progress_dialog=None):
    """Downloads zip file from GitHub with optional auth and progress reporting."""
    headers = {
        'User-Agent': 'Kodi-Sportsurge-Updater',
        'Accept': 'application/octet-stream'
    }
    if token:
        headers['Authorization'] = f"token {token.strip()}"

    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=30) as resp, open(dest_file, 'wb') as out:
        total_len = resp.headers.get('Content-Length')
        total_len = int(total_len) if total_len and total_len.isdigit() else 0

        chunk_size = 16384
        downloaded = 0
        while True:
            chunk = resp.read(chunk_size)
            if not chunk:
                break
            out.write(chunk)
            downloaded += len(chunk)
            if progress_dialog and total_len > 0:
                pct = int((downloaded / total_len) * 100)
                progress_dialog.update(pct, f"Downloading update... {pct}%")


def install_update_from_zip(zip_path):
    """
    Extracts downloaded zip into Kodi's addons directory.
    Handles both direct root packages and GitHub zipball subfolder structures.
    """
    addons_dir = get_addons_folder()
    target_addon_dir = os.path.join(addons_dir, 'plugin.video.sportsurge')

    with zipfile.ZipFile(zip_path, 'r') as zf:
        members = zf.namelist()
        has_plugin_root = any(m.startswith('plugin.video.sportsurge/') for m in members)

        if has_plugin_root:
            for member in members:
                zf.extract(member, addons_dir)
        else:
            root_prefix = members[0].split('/')[0] + '/' if '/' in members[0] else ''
            for member in members:
                if not member or member.endswith('/'):
                    continue
                rel_path = member[len(root_prefix):] if root_prefix and member.startswith(root_prefix) else member
                if rel_path.startswith('plugin.video.sportsurge/'):
                    rel_path = rel_path[len('plugin.video.sportsurge/'):]
                dest_path = os.path.join(target_addon_dir, rel_path)
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                with zf.open(member) as src_f, open(dest_path, 'wb') as dst_f:
                    shutil.copyfileobj(src_f, dst_f)


def check_and_apply_update(manual=False):
    """
    Main entry point for update checking.
    Prompts user and applies update if a newer version is available.
    """
    if not KODI_ENV:
        return

    addon = xbmcaddon.Addon()
    repo = addon.getSetting('github_repo') or DEFAULT_REPO
    token = addon.getSetting('github_token') or ''
    current_ver_str = get_current_version()
    current_ver = parse_version(current_ver_str)

    if manual:
        p_dialog = xbmcgui.DialogProgress()
        p_dialog.create("Sportsurge", "Checking GitHub for updates...")
    else:
        p_dialog = None

    tag, zip_url, notes = fetch_latest_release(repo, token)

    if p_dialog:
        p_dialog.close()

    if not tag or not zip_url:
        if manual:
            xbmcgui.Dialog().notification("Sportsurge", "No updates available or release not found.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    latest_ver = parse_version(tag)

    if latest_ver <= current_ver:
        if manual:
            xbmcgui.Dialog().notification(
                "Sportsurge",
                f"Already on latest version (v{current_ver_str})",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
        return

    msg = (
        f"A new version of Sportsurge is available!\n\n"
        f"Current: v{current_ver_str}\n"
        f"Latest:  {tag}\n\n"
        f"Would you like to install the update now?"
    )
    if notes:
        msg += f"\n\nChangelog:\n{notes[:150]}"

    confirmed = xbmcgui.Dialog().yesno("Sportsurge Update Available", msg)
    if not confirmed:
        return

    progress = xbmcgui.DialogProgress()
    progress.create("Sportsurge Update", "Downloading update package from GitHub...")

    temp_dir = xbmcvfs.translatePath('special://temp')
    temp_zip = os.path.join(temp_dir, 'sportsurge_update.zip')

    try:
        if os.path.exists(temp_zip):
            os.remove(temp_zip)

        download_zip(zip_url, temp_zip, token=token, progress_dialog=progress)
        progress.update(90, "Extracting and installing add-on files...")
        install_update_from_zip(temp_zip)
        progress.update(100, "Update complete!")
        progress.close()

        if os.path.exists(temp_zip):
            os.remove(temp_zip)

        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.executebuiltin('UpdateAddonRepos')

        xbmcgui.Dialog().ok(
            "Sportsurge Updated!",
            f"Successfully updated Sportsurge to {tag}!\n\n"
            "Please re-open the add-on to load the new version."
        )

    except Exception as e:
        if progress:
            progress.close()
        xbmcgui.Dialog().notification("Update Failed", f"Error: {str(e)[:60]}", xbmcgui.NOTIFICATION_ERROR, 5000)
        xbmc.log(f"[Sportsurge Updater] Update failed: {e}", xbmc.LOGERROR)
