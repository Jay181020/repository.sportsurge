# -*- coding: utf-8 -*-
"""
Main Kodi entry point for Sportsurge add-on.
Routes incoming plugin URLs to categories, live events, 24/7 channels, replays, streams, and playback.
"""

import os
import sys
import json
import urllib.parse

# Ensure resources/lib is in python path
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

from scraper import SportsurgeScraper
from player import SportsurgePlayer
from resolvers import StreamResolver
from channels import SportsChannelsManager
from replays import ReplaysScraper
import debrid
import updater


def get_settings():
    """Retrieves user settings from Kodi or defaults."""
    if not KODI_ENV:
        return {
            'base_url': 'https://v2.sportsurge.net',
            'timeout': 10,
            'preferred_quality': 0,
            'use_flaresolverr': False,
            'flaresolverr_url': 'http://127.0.0.1:8191/v1',
            'custom_user_agent': '',
            'cf_clearance': '',
            'use_proxy': False,
            'proxy_url': '',
            'auto_update_check': True,
            'github_repo': 'Jay181020/plugin.video.sportsurge',
            'github_token': '',
            'autoplay_stream': True,
            'autoplay_timeout': 4,
            'enable_debrid': False,
            'debrid_service': '0',
            'rd_token': '',
            'ad_token': '',
        }

    addon = xbmcaddon.Addon()
    return {
        'base_url': addon.getSetting('base_url') or 'https://v2.sportsurge.net',
        'timeout': int(addon.getSetting('timeout') or 10),
        'preferred_quality': int(addon.getSetting('preferred_quality') or 0),
        'use_flaresolverr': addon.getSetting('use_flaresolverr') == 'true',
        'flaresolverr_url': addon.getSetting('flaresolverr_url') or 'http://127.0.0.1:8191/v1',
        'custom_user_agent': addon.getSetting('custom_user_agent') or '',
        'cf_clearance': addon.getSetting('cf_clearance') or '',
        'use_proxy': addon.getSetting('use_proxy') == 'true',
        'proxy_url': addon.getSetting('proxy_url') or '',
        'auto_update_check': addon.getSetting('auto_update_check') != 'false',
        'github_repo': addon.getSetting('github_repo') or 'Jay181020/plugin.video.sportsurge',
        'github_token': addon.getSetting('github_token') or '',
        'autoplay_stream': addon.getSetting('autoplay_stream') != 'false',
        'autoplay_timeout': int(addon.getSetting('autoplay_timeout') or 4),
        'enable_debrid': addon.getSetting('enable_debrid') == 'true',
        'debrid_service': addon.getSetting('debrid_service') or '0',
        'rd_token': addon.getSetting('rd_token') or '',
        'ad_token': addon.getSetting('ad_token') or '',
    }


def build_url(base, **params):
    """Builds plugin:// URL with trailing slash before query parameters."""
    clean_base = base.rstrip('/') + '/'
    return f"{clean_base}?{urllib.parse.urlencode(params)}"


def set_video_metadata(listitem, title, plot='', genre=''):
    """Sets video metadata using InfoTagVideo on Kodi 20+ with fallback."""
    if hasattr(listitem, 'getVideoInfoTag'):
        try:
            tag = listitem.getVideoInfoTag()
            tag.setTitle(title)
            if plot:
                tag.setPlot(plot)
            if genre:
                tag.setGenres([genre])
            return
        except Exception:
            pass
    listitem.setInfo('video', {'title': title, 'plot': plot, 'genre': genre})


def show_main_menu(base_url, handle, scraper):
    """Displays top-level categories in Kodi."""
    xbmcplugin.setContent(handle, 'videos')

    # 1. 24/7 Live Sports Channels
    channels_url = build_url(base_url, action='channels_groups')
    ch_item = xbmcgui.ListItem(label="📺 24/7 Live Sports Channels")
    ch_item.setContentLookup(False)
    set_video_metadata(ch_item, title="24/7 Live Sports Channels", plot="Stream 120+ live sports networks (ESPN, FS1, CBS Sports, Sky Sports, TNT, DAZN, TSN)")
    xbmcplugin.addDirectoryItem(handle, channels_url, ch_item, isFolder=True)

    # 2. Match Replays & Archives (Debrid)
    replays_url = build_url(base_url, action='replays_menu')
    rep_item = xbmcgui.ListItem(label="🎬 Match Replays & Archives (Debrid)")
    rep_item.setContentLookup(False)
    set_video_metadata(rep_item, title="Match Replays & Archives", plot="Watch full game replays in 1080p/4K with AllDebrid & Real-Debrid (NFL, F1, UFC, Premier League)")
    xbmcplugin.addDirectoryItem(handle, replays_url, rep_item, isFolder=True)

    # 3. Live Sports Categories
    categories = scraper.get_categories()
    for cat in categories:
        url = build_url(base_url, action='category', cat_id=cat['id'], cat_name=cat['name'])
        listitem = xbmcgui.ListItem(label=cat['name'])
        listitem.setContentLookup(False)
        set_video_metadata(listitem, title=cat['name'], plot=f"Browse {cat['name']} live events")
        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=True)

    # Check for Updates item
    update_url = build_url(base_url, action='check_update')
    update_item = xbmcgui.ListItem(label="🔄 Check for Updates")
    update_item.setContentLookup(False)
    set_video_metadata(update_item, title='Check for Updates', plot='Check GitHub for newer releases and update automatically')
    xbmcplugin.addDirectoryItem(handle, update_url, update_item, isFolder=False)

    # Settings item
    settings_url = build_url(base_url, action='settings')
    settings_item = xbmcgui.ListItem(label="⚙️ Settings")
    settings_item.setContentLookup(False)
    set_video_metadata(settings_item, title='Settings', plot='Configure Auto-Play, Debrid, proxy, and quality')
    xbmcplugin.addDirectoryItem(handle, settings_url, settings_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_events(base_url, handle, scraper, cat_id, cat_name, settings):
    """Lists live matches for the selected sport category with Auto-Play support."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        events = scraper.get_live_events(category_id=cat_id)
    except Exception as e:
        err_msg = str(e)
        xbmcgui.Dialog().notification('Sportsurge', f"Error: {err_msg[:60]}", xbmcgui.NOTIFICATION_ERROR, 4000)
        events = []

    if not events:
        empty_item = xbmcgui.ListItem(label="No live matches currently available")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(events)
    autoplay = settings.get('autoplay_stream', True)

    for ev in events:
        status_tag = f" [{ev['time_text']}]" if ev['time_text'] else ""
        stream_tag = f" ({ev['stream_count']} streams)" if ev['stream_count'] else ""
        label = f"{ev['title']}{status_tag}{stream_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev['icon'])
        if autoplay:
            click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev['icon'])
        else:
            click_url = manual_url

        listitem = xbmcgui.ListItem(label=label)
        listitem.setContentLookup(False)
        set_video_metadata(
            listitem,
            title=ev['title'],
            genre=ev['category_name'],
            plot=f"Category: {ev['category_name']}\nStatus: {ev['time_text']}\nAvailable Streams: {ev['stream_count']}\n[B]Tip:[/B] Context Menu > 'Select Server Manually' to choose provider."
        )

        art = {}
        if ev['icon']:
            art['icon'] = ev['icon']
            art['thumb'] = ev['icon']
        if ev['fanart']:
            art['fanart'] = ev['fanart']
        if art:
            listitem.setArt(art)

        # Context menu allows picking specific server manually even when autoplay is active
        context_items = [
            ("Select Server Manually...", f"Container.Update({manual_url})")
        ]
        listitem.addContextMenuItems(context_items)

        xbmcplugin.addDirectoryItem(handle, click_url, listitem, isFolder=not autoplay, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def handle_match_autoplay(base_url, handle, scraper, match_url, match_title, icon, settings):
    """Smart Auto-Play: Probes top servers in sequence and launches the first working 1080p/720p stream."""
    try:
        streams = scraper.get_match_streams(match_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Sportsurge', f"Error fetching streams: {e}", xbmcgui.NOTIFICATION_ERROR)
        streams = []

    if not streams:
        xbmcgui.Dialog().notification('Sportsurge', 'No active stream servers found', xbmcgui.NOTIFICATION_WARNING)
        return

    # Sort streams by quality: Gold > Silver > Bronze, 1080p > 720p
    def sort_key(s):
        score = 0
        if '1080' in s.get('resolution', ''): score += 10
        if '60fps' in s.get('fps', ''): score += 5
        if s.get('tier') == 'HD' or s.get('tier') == 'Gold': score += 10
        return score

    sorted_streams = sorted(streams, key=sort_key, reverse=True)
    probe_timeout = settings.get('autoplay_timeout', 4)

    resolver = StreamResolver(
        user_agent=settings['custom_user_agent'],
        timeout=probe_timeout,
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url']
    )

    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create("Sportsurge Auto-Play", f"Searching best stream for:\n{match_title}...")

    resolved_url = None
    final_headers = None
    chosen_server_name = ""

    candidates = sorted_streams[:8]
    for idx, s in enumerate(candidates):
        if p_dialog.iscanceled():
            break
        pct = int(((idx + 1) / len(candidates)) * 100)
        p_dialog.update(pct, f"Testing Server {idx + 1}/{len(candidates)}: {s['site_name']} ({s.get('resolution', 'HD')})...")

        res_url, headers = resolver.resolve(s['url'])
        if res_url and ('.m3u8' in res_url or '.mpd' in res_url):
            resolved_url = res_url
            final_headers = headers
            chosen_server_name = s['site_name']
            break

    p_dialog.close()

    if resolved_url:
        xbmcgui.Dialog().notification('Sportsurge', f"Auto-Playing: {chosen_server_name}", icon or xbmcgui.NOTIFICATION_INFO, 2000)
        player = SportsurgePlayer(
            handle=handle,
            user_agent=settings['custom_user_agent'],
            timeout=settings['timeout'],
            use_proxy=settings['use_proxy'],
            proxy_url=settings['proxy_url']
        )
        player.play(resolved_url, title=f"{match_title} ({chosen_server_name})", icon=icon, referer=match_url)
    else:
        # Fall back to server list if auto-play couldn't find a direct stream
        show_streams(base_url, handle, scraper, match_url, match_title, icon)


def show_streams(base_url, handle, scraper, match_url, match_title, icon):
    """Lists all available stream links for a specific match."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        streams = scraper.get_match_streams(match_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Sportsurge', f"Error fetching streams: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        streams = []

    if not streams:
        empty_item = xbmcgui.ListItem(label="No streams found for this match")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(streams)
    for s in streams:
        url = build_url(
            base_url,
            action='play',
            stream_url=s['url'],
            title=f"{match_title} - {s['site_name']}",
            icon=icon,
            referer=match_url
        )

        listitem = xbmcgui.ListItem(label=s['title'])
        listitem.setContentLookup(False)
        plot_desc = f"Site: {s['site_name']}\nQuality: {s['resolution']} {s['fps']}\nBitrate: {s['bitrate']}\nLanguage: {s['language']}\nAds: {s['ads']}"
        set_video_metadata(listitem, title=s['title'], plot=plot_desc)
        listitem.setProperty('IsPlayable', 'true')

        if icon:
            listitem.setArt({'icon': icon, 'thumb': icon})

        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


# ==========================================
# 24/7 Live Sports TV Channels Handlers
# ==========================================

def show_channels_groups(base_url, handle, channels_mgr):
    """Displays 24/7 channels group menu (US/CA, UK/EU, All)."""
    xbmcplugin.setContent(handle, 'videos')
    groups = channels_mgr.get_channel_groups()

    for g in groups:
        url = build_url(base_url, action='channels_list', group_id=g['id'], group_name=g['name'])
        item = xbmcgui.ListItem(label=g['name'])
        item.setContentLookup(False)
        set_video_metadata(item, title=g['name'], plot=f"Browse {g['name']} live TV networks")
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_channels_list(base_url, handle, channels_mgr, group_id):
    """Lists individual 24/7 TV channels for the selected group."""
    xbmcplugin.setContent(handle, 'videos')
    channels = channels_mgr.get_channels_by_group(group_id)

    if not channels:
        empty_item = xbmcgui.ListItem(label="No channels available currently")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(channels)
    for ch in channels:
        name = ch['name']
        links = ch.get('links', [])
        icon = ch.get('icon', '')
        lang = ch.get('language', 'EN')

        # If channel has multiple server mirrors, allow direct play or server selection
        links_json = urllib.parse.quote(json.dumps(links))
        url = build_url(base_url, action='play_channel', ch_name=name, ch_links=links_json, icon=icon)

        label = f"[{lang}] {name} ({len(links)} Mirrors)"
        item = xbmcgui.ListItem(label=label)
        item.setContentLookup(False)
        set_video_metadata(item, title=name, plot=f"Network: {name}\nLanguage: {lang}\nAvailable Server Mirrors: {len(links)}")
        item.setProperty('IsPlayable', 'true')
        if icon:
            item.setArt({'icon': icon, 'thumb': icon})

        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def play_channel(base_url, handle, ch_name, ch_links_json, icon, settings):
    """Resolves and plays a 24/7 live TV channel with mirror failover."""
    links = json.loads(urllib.parse.unquote(ch_links_json))
    if not links:
        xbmcgui.Dialog().notification('Sportsurge', 'No links available for this channel', xbmcgui.NOTIFICATION_WARNING)
        return

    resolver = StreamResolver(
        user_agent=settings['custom_user_agent'],
        timeout=settings['timeout'],
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url']
    )

    resolved_url = None
    for lnk in links:
        res_url, headers = resolver.resolve(lnk)
        if res_url:
            resolved_url = res_url
            break

    if resolved_url:
        player = SportsurgePlayer(
            handle=handle,
            user_agent=settings['custom_user_agent'],
            timeout=settings['timeout'],
            use_proxy=settings['use_proxy'],
            proxy_url=settings['proxy_url']
        )
        player.play(resolved_url, title=ch_name, icon=icon, referer='https://super.league.st')
    else:
        xbmcgui.Dialog().notification('Sportsurge', f"Failed to resolve stream for {ch_name}", xbmcgui.NOTIFICATION_ERROR)


# ==========================================
# Match Replays & Archives (Debrid) Handlers
# ==========================================

def show_replays_menu(base_url, handle, replays_scraper):
    """Displays sports replay categories (F1, Premier League, UFC, NFL, NBA)."""
    xbmcplugin.setContent(handle, 'videos')
    cats = replays_scraper.get_categories()

    for c in cats:
        url = build_url(base_url, action='replays_category', cat_id=c['id'], cat_name=c['name'])
        item = xbmcgui.ListItem(label=c['name'])
        item.setContentLookup(False)
        set_video_metadata(item, title=c['name'], plot=f"Full match replays and event archives for {c['name']}")
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_replays_list(base_url, handle, replays_scraper, cat_id, cat_name):
    """Lists replay articles for the selected sports category."""
    xbmcplugin.setContent(handle, 'videos')
    replays = replays_scraper.get_replays_for_category(cat_id)

    if not replays:
        empty_item = xbmcgui.ListItem(label="No replays found currently")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(replays)
    for r in replays:
        url = build_url(base_url, action='replay_sources', article_url=r['url'], title=r['title'], icon=r['icon'])
        label = f"{r['title']} ({r['date']})" if r['date'] else r['title']

        item = xbmcgui.ListItem(label=label)
        item.setContentLookup(False)
        set_video_metadata(item, title=r['title'], plot=f"Event: {r['title']}\nDate: {r['date']}\nCategory: {r['category']}")
        if r['icon']:
            item.setArt({'icon': r['icon'], 'thumb': r['icon']})

        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_replay_sources(base_url, handle, replays_scraper, article_url, title, icon):
    """Lists video parts / hoster sources for a replay event."""
    xbmcplugin.setContent(handle, 'videos')
    sources = replays_scraper.get_replay_video_sources(article_url)

    if not sources:
        empty_item = xbmcgui.ListItem(label="No video sources found for this replay")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(sources)
    for s in sources:
        url = build_url(base_url, action='play_replay', source_url=s['url'], title=f"{title} - {s['title']}", icon=icon)
        item = xbmcgui.ListItem(label=s['title'])
        item.setContentLookup(False)
        set_video_metadata(item, title=s['title'], plot=f"Hoster: {s['hoster']}\nURL: {s['url']}")
        item.setProperty('IsPlayable', 'true')
        if icon:
            item.setArt({'icon': icon, 'thumb': icon})

        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def play_replay(base_url, handle, source_url, title, icon, settings):
    """Plays a replay link, unrestricting with Real-Debrid / AllDebrid if enabled."""
    replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])

    stream_url = replays_scraper.resolve_replay_stream(
        source_url=source_url,
        debrid_enabled=settings['enable_debrid'],
        debrid_service=settings['debrid_service'],
        rd_token=settings['rd_token'],
        ad_token=settings['ad_token']
    )

    if stream_url and stream_url.startswith('http'):
        player = SportsurgePlayer(
            handle=handle,
            user_agent=settings['custom_user_agent'],
            timeout=settings['timeout'],
            use_proxy=settings['use_proxy'],
            proxy_url=settings['proxy_url']
        )
        player.play(stream_url, title=title, icon=icon)
    else:
        xbmcgui.Dialog().notification('Sportsurge', 'Unable to resolve replay stream link', xbmcgui.NOTIFICATION_ERROR)


# ==========================================
# Main Router
# ==========================================

def router(argv):
    """Parses Kodi command line and routes to appropriate handler."""
    base_url = argv[0]
    handle = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else -1
    query = argv[2][1:] if len(argv) > 2 and argv[2].startswith('?') else ''
    params = dict(urllib.parse.parse_qsl(query))

    settings = get_settings()
    scraper = SportsurgeScraper(
        base_url=settings['base_url'],
        user_agent=settings['custom_user_agent'],
        cf_clearance=settings['cf_clearance'],
        use_flaresolverr=settings['use_flaresolverr'],
        flaresolverr_url=settings['flaresolverr_url'],
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url'],
        timeout=settings['timeout']
    )

    action = params.get('action')

    if not action or action == 'root':
        show_main_menu(base_url, handle, scraper)
    elif action == 'category':
        cat_id = params.get('cat_id', 'all')
        cat_name = params.get('cat_name', 'Live Sports')
        show_events(base_url, handle, scraper, cat_id, cat_name, settings)
    elif action == 'match':
        match_url = params.get('match_url', '')
        match_title = params.get('match_title', 'Match Streams')
        icon = params.get('icon', '')
        show_streams(base_url, handle, scraper, match_url, match_title, icon)
    elif action == 'match_autoplay':
        match_url = params.get('match_url', '')
        match_title = params.get('match_title', 'Match Streams')
        icon = params.get('icon', '')
        handle_match_autoplay(base_url, handle, scraper, match_url, match_title, icon, settings)
    elif action == 'channels_groups':
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_channels_groups(base_url, handle, channels_mgr)
    elif action == 'channels_list':
        group_id = params.get('group_id', 'all')
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_channels_list(base_url, handle, channels_mgr, group_id)
    elif action == 'play_channel':
        ch_name = params.get('ch_name', 'Live Channel')
        ch_links = params.get('ch_links', '[]')
        icon = params.get('icon', '')
        play_channel(base_url, handle, ch_name, ch_links, icon, settings)
    elif action == 'replays_menu':
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replays_menu(base_url, handle, replays_scraper)
    elif action == 'replays_category':
        cat_id = params.get('cat_id', 'f1')
        cat_name = params.get('cat_name', 'Replays')
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replays_list(base_url, handle, replays_scraper, cat_id, cat_name)
    elif action == 'replay_sources':
        article_url = params.get('article_url', '')
        title = params.get('title', 'Replay')
        icon = params.get('icon', '')
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replay_sources(base_url, handle, replays_scraper, article_url, title, icon)
    elif action == 'play_replay':
        source_url = params.get('source_url', '')
        title = params.get('title', 'Replay Video')
        icon = params.get('icon', '')
        play_replay(base_url, handle, source_url, title, icon, settings)
    elif action == 'auth_rd':
        debrid.authorize_real_debrid()
    elif action == 'auth_ad':
        debrid.authorize_alldebrid()
    elif action == 'play':
        stream_url = params.get('stream_url', '')
        title = params.get('title', 'Live Stream')
        icon = params.get('icon', '')
        referer = params.get('referer', settings['base_url'])
        player = SportsurgePlayer(
            handle=handle,
            user_agent=settings['custom_user_agent'],
            timeout=settings['timeout'],
            use_proxy=settings['use_proxy'],
            proxy_url=settings['proxy_url']
        )
        player.play(stream_url, title=title, icon=icon, referer=referer)
    elif action == 'check_update':
        updater.check_and_apply_update(manual=True)
    elif action == 'settings':
        if KODI_ENV:
            xbmcaddon.Addon().openSettings()


if __name__ == '__main__':
    router(sys.argv)
