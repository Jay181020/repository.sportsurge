# -*- coding: utf-8 -*-
"""
24/7 Live Sports TV Channels manager for Sportsurge.
Aggregates and organizes live sports networks (ESPN, Sky Sports, TNT, FS1, TSN, etc.)
from unblocked feeds and multi-mirror resolvers.
"""

import json
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup

DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

# Canonical Channel Groups
CHANNEL_GROUPS = [
    {'id': 'us_ca', 'name': '🏈 US & Canadian Sports (ESPN, FS1, CBS, TSN)', 'keywords': ['espn', 'fox sports', 'fs1', 'fs2', 'cbs', 'abc', 'tsn', 'sportsnet', 'nbc', 'sec network', 'nfl']},
    {'id': 'uk_eu', 'name': '⚽ UK & European Sports (Sky Sports, TNT, DAZN)', 'keywords': ['sky sports', 'tnt sports', 'dazn', 'canal+', 'laliga', 'liga', 'viaplay', 'bein']},
    {'id': 'all', 'name': '📺 All Channels (A-Z)', 'keywords': []}
]


class SportsChannelsManager:
    def __init__(self, user_agent=DEFAULT_UA, timeout=10):
        self.user_agent = user_agent
        self.timeout = timeout

    def get_channel_groups(self):
        """Returns top-level channel categories."""
        return CHANNEL_GROUPS

    def get_all_channels(self):
        """
        Fetches all live sports channels from the unblocked backend feed.
        Returns a dict: {channel_name: {'name': str, 'links': list, 'language': str, 'icon': str}}
        """
        channels = {}
        try:
            url = 'https://super.league.st'
            req = urllib.request.Request(url, headers={'User-Agent': self.user_agent})
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                html = resp.read().decode('utf-8', errors='ignore')

            for line in html.splitlines():
                if 'window.matches = JSON.parse(`' in line:
                    raw_json = line.split('window.matches = JSON.parse(`')[1].rsplit('`)', 1)[0]
                    matches_data = json.loads(raw_json)
                    for m in matches_data:
                        for ch in m.get('channels', []):
                            name = ch.get('name', '').strip()
                            if not name:
                                continue
                            links = ch.get('links', [])
                            lang = ch.get('language', 'EN')
                            icon = m.get('team1Img', '')

                            if name not in channels:
                                channels[name] = {
                                    'name': name,
                                    'links': list(links),
                                    'language': lang,
                                    'icon': icon
                                }
                            else:
                                for lnk in links:
                                    if lnk not in channels[name]['links']:
                                        channels[name]['links'].append(lnk)
                    break
        except Exception as e:
            print(f"Error fetching 24/7 channels: {e}")

        return channels

    def get_channels_by_group(self, group_id='all'):
        """Filters channels by group (us_ca, uk_eu, all)."""
        all_channels = self.get_all_channels()
        if not all_channels:
            return []

        group = next((g for g in CHANNEL_GROUPS if g['id'] == group_id), None)
        if not group or not group['keywords']:
            # All channels sorted alphabetically
            return [all_channels[k] for k in sorted(all_channels.keys())]

        keywords = group['keywords']
        filtered = []
        for name in sorted(all_channels.keys()):
            name_lower = name.lower()
            if any(kw in name_lower for kw in keywords):
                filtered.append(all_channels[name])

        return filtered

    def export_m3u_playlist(self, filepath):
        """Exports all live channels to an M3U playlist file for IPTV Simple Client."""
        channels = self.get_all_channels()
        lines = ['#EXTM3U']
        for name, data in sorted(channels.items()):
            links_json = urllib.parse.quote(json.dumps(data['links']))
            logo = data.get('icon', '')
            lang = data.get('language', 'EN')
            plugin_url = f"plugin://plugin.video.sportsurge/?action=play_channel&ch_name={urllib.parse.quote(name)}&ch_links={links_json}"
            lines.append(f'#EXTINF:-1 tvg-name="{name}" tvg-logo="{logo}" group-title="Live Sports ({lang})",{name}')
            lines.append(plugin_url)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
        return len(channels)
