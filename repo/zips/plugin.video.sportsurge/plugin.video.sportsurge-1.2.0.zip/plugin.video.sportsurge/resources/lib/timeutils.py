# -*- coding: utf-8 -*-
"""
Time and status utilities for Sportsurge.
Handles Kodi/OS timezone detection, converts match times to local clock,
and formats color-coded live/upcoming/finished badges.
"""

import re
import json
from datetime import datetime, timedelta, timezone

try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False


def get_local_utc_offset():
    """
    Returns the user's local timezone offset in hours from UTC.
    First tries Kodi's locale.timezone setting via JSON-RPC,
    then falls back to the host operating system's local clock offset.
    """
    if KODI_ENV:
        try:
            resp_str = xbmc.executeJSONRPC(
                '{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}'
            )
            data = json.loads(resp_str)
            tz_name = data.get('result', {}).get('value', '')
            if tz_name:
                try:
                    import zoneinfo
                    tz = zoneinfo.ZoneInfo(tz_name)
                    offset_sec = datetime.now(tz).utcoffset().total_seconds()
                    return offset_sec / 3600.0
                except Exception:
                    pass
        except Exception:
            pass

    local_offset = datetime.now().astimezone().utcoffset()
    if local_offset is not None:
        return local_offset.total_seconds() / 3600.0
    return 0.0


def parse_event_start(time_str, default_hour_utc=None):
    """
    Parses various time formats:
    - '19:30' or '03:20' (assumed UTC from feeds)
    - '2026-09-14 02:00:00'
    - 'Today, 19:30'
    Returns (local_time_str, status_code, delta_minutes)
    status_code: 'live' | 'soon' | 'done'
    """
    if not time_str:
        return '', 'unknown', 0

    now = datetime.now(timezone.utc)
    offset_hours = get_local_utc_offset()

    hm_match = re.search(r'\b(\d{1,2}):(\d{2})\b', time_str)
    if hm_match:
        hour = int(hm_match.group(1))
        minute = int(hm_match.group(2))

        event_utc = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if (event_utc - now).total_seconds() < -12 * 3600:
            event_utc += timedelta(days=1)
        elif (event_utc - now).total_seconds() > 12 * 3600:
            event_utc -= timedelta(days=1)

        event_local = event_utc + timedelta(hours=offset_hours)
        diff_sec = (event_utc - now).total_seconds()
        diff_min = int(diff_sec / 60)

        local_str = event_local.strftime('%I:%M %p').lstrip('0')

        if 0 <= -diff_min <= 180:
            status = 'live'
        elif diff_min > 0:
            status = 'soon'
        else:
            status = 'done'

        return local_str, status, diff_min

    if 'live' in time_str.lower():
        return 'LIVE NOW', 'live', 0

    return time_str, 'unknown', 0


def format_status_badge(time_str, stream_count=0):
    """
    Formats a user-friendly color badge for Kodi list items:
    - [COLOR lime]● LIVE[/COLOR]
    - [COLOR yellow]Starts in 25m (7:30 PM)[/COLOR]
    - [COLOR gray]Ended (5:00 PM)[/COLOR]
    """
    local_str, status, diff_min = parse_event_start(time_str)

    if status == 'live':
        badge = '[B][COLOR lime]● LIVE[/COLOR][/B]'
    elif status == 'soon':
        if diff_min < 60:
            badge = f'[COLOR yellow]Starts in {diff_min}m ({local_str})[/COLOR]'
        else:
            hours = diff_min // 60
            mins = diff_min % 60
            badge = f'[COLOR yellow]Starts in {hours}h {mins}m ({local_str})[/COLOR]'
    elif status == 'done':
        badge = f'[COLOR gray]Ended ({local_str})[/COLOR]'
    else:
        badge = f'[COLOR lightblue]{time_str}[/COLOR]' if time_str else ''

    return badge, status
