# -*- coding: utf-8 -*-
"""
Multi-host stream resolver for Sportsurge streams.
Extracts direct HLS (.m3u8) video streams from embed players, iframes, and scripts.
"""

import re
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup

DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

# Domains/URLs to ignore when following iframes (ads, analytics, chat)
IGNORED_IFRAMES = [
    'google', 'doubleclick', 'histats', 'chatango', 'disqus',
    'facebook', 'twitter', 'popcash', 'adsterra', 'exoclick',
    'bet365', 'whos.amung.us', 'counter', 'analytics', 'turnstile',
    'cloudflare', 'recaptcha', 'monetag'
]


try:
    from . import econfig
    from . import jsunpack
except (ImportError, ValueError):
    import econfig
    import jsunpack


def extract_packed_js(html):
    """
    Detects and unpacks all Dean Edwards packed scripts in the HTML.
    """
    unpacked_scripts = []
    # Match eval(function(p,a,c,k,e,d)...) or eval(function(p,a,c,k,e,r)...)
    for m in re.finditer(r'(eval\s*\(\s*function\s*\(p,\s*a,\s*c,\s*k,\s*e,.*?\)\s*\))', html, re.DOTALL):
        snippet = m.group(1)
        try:
            if jsunpack.detect(snippet):
                unpacked_scripts.append(jsunpack.unpack(snippet))
        except Exception:
            continue
    return '\n'.join(unpacked_scripts)


def unpack_dean_edwards(p, a, c, k, e=None, d=None):
    """
    Unpacks Dean Edwards p.a.c.k.e.r javascript.
    Supports argument unpacking (p, a, c, k) or jsunpack.
    """
    if isinstance(k, str):
        k_list = k.split('|')
    else:
        k_list = list(k)

    def repl(m):
        word = m.group(0)
        try:
            val = int(word, a) if a <= 36 else 0
            if val < len(k_list) and k_list[val]:
                return k_list[val]
        except ValueError:
            pass
        return word

    return re.sub(r'\b\w+\b', repl, p)


def clean_m3u8_url(url):
    """Cleans JSON-escaped slashes and unicode ampersands."""
    if not url:
        return ''
    cleaned = url.replace(r'\/', '/').replace(r'\u0026', '&').strip('\'"')
    return cleaned


def find_m3u8_in_text(text):
    """
    Searches for .m3u8 URLs across common player patterns:
    - Direct URLs
    - Clappr configs (window.PP_CLAPPR_CONFIG, Clappr.Player)
    - VideoJS / Hls.js source configs
    """
    if not text:
        return None

    # 1. Clappr config JSON
    clappr_match = re.search(r'["\'](?:src|source|srcBase)["\']\s*:\s*["\'](https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)["\']', text)
    if clappr_match:
        return clean_m3u8_url(clappr_match.group(1))

    # 2. Player setup object (file: "...", source: "...")
    setup_match = re.search(r'(?:file|source|src)\s*:\s*["\'](https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)["\']', text)
    if setup_match:
        return clean_m3u8_url(setup_match.group(1))

    # 3. StreamUrl assignment (const streamUrl = "...")
    stream_var_match = re.search(r'(?:streamUrl|hlsUrl|videoUrl|stream_url)\s*=\s*["\'](https?://[^\s"\'<>]+\.m3u8[^\s"\'<>]*)["\']', text)
    if stream_var_match:
        return clean_m3u8_url(stream_var_match.group(1))

    # 4. Generic direct .m3u8 match
    generic_matches = re.findall(r'["\'](https?://[^\s"\'<>\\]+\.m3u8[^\s"\'<>]*)["\']', text)
    for m in generic_matches:
        cleaned = clean_m3u8_url(m)
        if 'favicon' not in cleaned.lower():
            return cleaned

    return None


class StreamResolver:
    def __init__(self, user_agent=DEFAULT_UA, timeout=10, use_proxy=False, proxy_url=''):
        self.user_agent = user_agent
        self.timeout = timeout
        self.use_proxy = use_proxy
        self.proxy_url = (proxy_url or '').strip()
        self.visited_urls = set()

        if self.use_proxy and self.proxy_url:
            proxy_handler = urllib.request.ProxyHandler({
                'http': self.proxy_url,
                'https': self.proxy_url
            })
            self.opener = urllib.request.build_opener(proxy_handler)
        else:
            self.opener = urllib.request.build_opener()

    def fetch(self, url, referer=None):
        """Fetches page content with appropriate browser headers."""
        headers = {
            'User-Agent': self.user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Connection': 'keep-alive',
        }
        if referer:
            headers['Referer'] = referer
            parsed_ref = urllib.parse.urlparse(referer)
            headers['Origin'] = f"{parsed_ref.scheme}://{parsed_ref.netloc}"

        req = urllib.request.Request(url, headers=headers)
        with self.opener.open(req, timeout=self.timeout) as resp:
            final_url = resp.geturl()
            content = resp.read().decode('utf-8', errors='ignore')
            return final_url, content


    def resolve(self, initial_url, referer=None, depth=0):
        """
        Recursively resolves a stream link down to a direct HLS (.m3u8) URL.
        Returns tuple: (playback_url_with_kodi_headers, headers_dict) or (None, None)
        """
        if depth > 4 or initial_url in self.visited_urls:
            return None, None

        # Handle ?get= redirector wrappers (from SportHD/FutbolLibre)
        m_get = re.search(r'[?&]get=(https?[^&]+)', initial_url)
        if m_get:
            return self.resolve(urllib.parse.unquote(m_get.group(1)), referer=referer, depth=depth + 1)

        try:
            current_url, html = self.fetch(initial_url, referer=referer)
        except Exception:
            return None, None

        parsed_current = urllib.parse.urlparse(current_url)
        origin = f"{parsed_current.scheme}://{parsed_current.netloc}"

        # Step 1: Direct .m3u8 check
        direct_m3u8 = find_m3u8_in_text(html)
        if direct_m3u8:
            return self._build_kodi_stream(direct_m3u8, current_url, origin)

        # Step 2: Check window._econfig (SportHD econfig blob decoder)
        try:
            if econfig.find_econfig(html):
                ec_stream, _ = econfig.extract_stream_from_html(html)
                if ec_stream:
                    return self._build_kodi_stream(ec_stream, current_url, origin)
        except Exception:
            pass

        # Step 3: Check character-array join: return(["...", ...].join(""))
        arr_m = re.search(r'return\s*\(\s*(\[(?:"[^"]*",?\s*)+\])\.join', html)
        if arr_m:
            try:
                char_fl = ''.join(re.findall(r'"([^"]*)"', arr_m.group(1))).replace(r'\/', '/')
                if char_fl and '.m3u8' in char_fl:
                    return self._build_kodi_stream(char_fl, current_url, origin)
            except Exception:
                pass

        # Step 4: Check for packed JavaScript (using jsunpack)
        unpacked_js = extract_packed_js(html)
        if unpacked_js:
            packed_m3u8 = find_m3u8_in_text(unpacked_js)
            if packed_m3u8:
                return self._build_kodi_stream(packed_m3u8, current_url, origin)
            # Also check econfig in unpacked code
            try:
                if econfig.find_econfig(unpacked_js):
                    ec_stream, _ = econfig.extract_stream_from_html(unpacked_js)
                    if ec_stream:
                        return self._build_kodi_stream(ec_stream, current_url, origin)
            except Exception:
                pass

        # Step 5: Check player API with mirror rotation & ?ppcfg=1 (SportHD Nexa/Vertex/Sansat engine)
        if any(h in current_url for h in ['nexa', 'vertex', 'sansat', 'glisco', 'api/player.php']):
            cid = '1'
            parsed_q = urllib.parse.parse_qs(parsed_current.query)
            if 'id' in parsed_q and parsed_q['id']:
                cid = parsed_q['id'][0]
            else:
                m_load = re.search(r'loadPlayerChannel\(\s*["\']?(\d+)["\']?\s*\)', html)
                if m_load:
                    cid = m_load.group(1)
                else:
                    m_data = re.search(r'data-channel-id=["\'](\d+)["\']', html)
                    if m_data:
                        cid = m_data.group(1)

            # Build candidate hosts list
            hosts = [parsed_current.netloc]
            m_host = re.match(r'^(?:s\d+\.)?(nexa\.st|vertex\.st)$', parsed_current.netloc)
            if m_host:
                base = m_host.group(1)
                for h in (base, f"s1.{base}", f"s2.{base}", f"s3.{base}"):
                    if h not in hosts:
                        hosts.append(h)

            import time
            for host in hosts:
                try:
                    api_url = f"{parsed_current.scheme}://{host}/api/player.php?id={cid}"
                    api_ref = f"{parsed_current.scheme}://{host}/"
                    _, api_resp = self.fetch(api_url, referer=api_ref)
                    target_match = re.search(r'["\']url["\']\s*:\s*["\']([^"\']+)["\']', api_resp)
                    if not target_match:
                        continue
                    cand_frame = clean_m3u8_url(target_match.group(1))

                    # 1) Try SportHD ?ppcfg=1 trick
                    sep = '&' if '?' in cand_frame else '?'
                    cfg_url = f"{cand_frame}{sep}ppcfg=1&_={int(time.time() * 1000)}"
                    try:
                        _, cfg_resp = self.fetch(cfg_url, referer=api_ref)
                        # Check direct JSON config
                        try:
                            cfg_data = json.loads(cfg_resp)
                            direct_src = cfg_data.get('src') or cfg_data.get('srcBase')
                            if direct_src:
                                frame_origin = f"{urllib.parse.urlparse(cand_frame).scheme}://{urllib.parse.urlparse(cand_frame).netloc}"
                                return self._build_kodi_stream(direct_src, cand_frame, frame_origin)
                        except Exception:
                            pass
                        # Check m3u8 in cfg response
                        cfg_m3u8 = find_m3u8_in_text(cfg_resp)
                        if cfg_m3u8:
                            frame_origin = f"{urllib.parse.urlparse(cand_frame).scheme}://{urllib.parse.urlparse(cand_frame).netloc}"
                            return self._build_kodi_stream(cfg_m3u8, cand_frame, frame_origin)
                    except Exception:
                        pass

                    # 2) Fallback to normal recursive resolve of candidate frame
                    res, headers = self.resolve(cand_frame, referer=api_ref, depth=depth + 1)
                    if res:
                        return res, headers
                except Exception:
                    continue

        # Step 6: Parse iframes and follow them
        soup = BeautifulSoup(html, 'html.parser')
        iframes = soup.find_all('iframe')
        for ifr in iframes:
            src = ifr.get('src', '').strip()
            if not src or src.startswith('javascript:'):
                continue

            full_iframe_url = urllib.parse.urljoin(current_url, src)

            # Check if iframe is an ignored ad/tracker
            if any(ign in full_iframe_url.lower() for ign in IGNORED_IFRAMES):
                continue

            res, headers = self.resolve(full_iframe_url, referer=current_url, depth=depth + 1)
            if res:
                return res, headers

        return None, None

    def _build_kodi_stream(self, m3u8_url, referer, origin):
        """
        Formats the stream URL for Kodi's VideoPlayer / inputstream.adaptive
        with pipe-separated HTTP headers.
        """
        headers = {
            'User-Agent': self.user_agent,
            'Referer': referer,
            'Origin': origin,
            'verifypeer': 'false',
        }


        # Build Kodi pipe format: URL|User-Agent=...&Referer=...&Origin=...
        query_params = urllib.parse.urlencode(headers)
        kodi_playback_url = f"{m3u8_url}|{query_params}"

        return kodi_playback_url, headers

    def verify_stream_live(self, m3u8_url, headers=None, timeout=2.5):
        """
        Probes a direct .m3u8 stream URL with a fast Range GET or HEAD
        to verify that the stream server is genuinely online and returning HTTP 200/206/302.
        Returns True if alive, False if 403/404/500/timeout/unreachable.
        """
        if not m3u8_url:
            return False

        clean_url = m3u8_url.split('|')[0]
        req_headers = {
            'User-Agent': self.user_agent,
            'Accept': '*/*',
            'Connection': 'keep-alive',
            'Range': 'bytes=0-512',
        }
        if headers:
            for k, v in headers.items():
                if k.lower() not in ('range', 'host', 'verifypeer'):
                    req_headers[k] = v

        try:
            req = urllib.request.Request(clean_url, headers=req_headers)
            with self.opener.open(req, timeout=timeout) as resp:
                code = resp.getcode()
                if code in (200, 206, 301, 302):
                    sample = resp.read(256)
                    if sample:
                        sample_str = sample.decode('utf-8', errors='ignore')
                        if '#EXTM3U' in sample_str or '#EXT' in sample_str or '<html' not in sample_str.lower():
                            return True
                    return True
        except Exception:
            return False

        return False

