# -*- coding: utf-8 -*-
"""
IPTV Proxy Server for Sportsurge (v1.4.0).
Provides a lightweight local HTTP streaming proxy for TiviMate, VLC, and IPTV clients.
Enables true Multi-View (split-screen / quad-box) on Firestick / Android TV with zero 403 blocks.
"""

import os
import sys
import json
import time
import socket
import urllib.request
import urllib.parse
import threading
import http.server

try:
    from . import channels
    from . import resolvers
    from . import streameast
except (ImportError, ValueError):
    import channels
    import resolvers
    import streameast

# Default configuration
DEFAULT_PORT = 8899
DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

# High-reliability direct FAST sports channels (24/7 public HLS feeds with full logos)
FAST_SPORTS_CHANNELS = [
    {
        'name': 'Red Bull TV HD',
        'group': '⚡ Action & Extreme Sports',
        'logo': 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f5/Red_Bull_TV_logo.svg/512px-Red_Bull_TV_logo.svg.png',
        'url': 'https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8'
    },
    {
        'name': 'Stadium 24/7 Live HD',
        'group': '🏈 US & Canadian Sports',
        'logo': 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Stadium_sports_network_logo.svg/512px-Stadium_sports_network_logo.svg.png',
        'url': 'https://stadium-sinclair.amagi.tv/playlist.m3u8'
    },
    {
        'name': 'Fubo Sports Network',
        'group': '🏈 US & Canadian Sports',
        'logo': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Fubo_Sports_Network_logo.svg/512px-Fubo_Sports_Network_logo.svg.png',
        'url': 'https://fubotv.amagi.tv/playlist.m3u8'
    },
    {
        'name': 'Fight Network (Combat / MMA)',
        'group': '🥊 Combat & MMA',
        'logo': 'https://upload.wikimedia.org/wikipedia/en/thumb/e/e0/Fight_Network_logo.svg/512px-Fight_Network_logo.svg.png',
        'url': 'https://stream-us.amagi.tv/hls/amagi_hls_data_anthem-fightnetwork-dash/master.m3u8'
    },
    {
        'name': 'PFL MMA (Professional Fighters League)',
        'group': '🥊 Combat & MMA',
        'logo': 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/PFL_logo.svg/512px-PFL_logo.svg.png',
        'url': 'https://pfl-pfl-1-us.plex.wurl.tv/playlist.m3u8'
    },
    {
        'name': 'Motorsport.tv 24/7',
        'group': '🏎️ Motor Sports',
        'logo': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/Motorsport.tv_logo.svg/512px-Motorsport.tv_logo.svg.png',
        'url': 'https://motorsport-linear.akamaized.net/hls/live/2042453/linear/master.m3u8'
    },
    {
        'name': 'MavTV Select Motorsports HD',
        'group': '🏎️ Motor Sports',
        'logo': 'https://upload.wikimedia.org/wikipedia/en/thumb/3/30/MavTV_logo.svg/512px-MavTV_logo.svg.png',
        'url': 'https://mavtv-mavtvselect-1-us.rakuten.wurl.tv/playlist.m3u8'
    },
    {
        'name': 'World Poker Tour 24/7',
        'group': '♠️ Poker & Gaming',
        'logo': 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f6/World_Poker_Tour_logo.svg/512px-World_Poker_Tour_logo.svg.png',
        'url': 'https://stream-us.amagi.tv/hls/amagi_hls_data_wpt-wpt247-dash/master.m3u8'
    },
    {
        'name': 'ACC Digital Network (NCAA)',
        'group': '🏈 US & Canadian Sports',
        'logo': 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/02/Atlantic_Coast_Conference_logo.svg/512px-Atlantic_Coast_Conference_logo.svg.png',
        'url': 'https://accdn-sinclair.amagi.tv/playlist.m3u8'
    },
    {
        'name': 'Outdoor America 24/7',
        'group': '🎣 Outdoor & Adventure',
        'logo': 'https://upload.wikimedia.org/wikipedia/en/thumb/2/23/Outdoor_Channel_logo.svg/512px-Outdoor_Channel_logo.svg.png',
        'url': 'https://outdoor-outdooramerica-1-us.samsung.wurl.tv/playlist.m3u8'
    }
]


def get_local_ip():
    """Finds the local LAN IPv4 address for multi-device network sharing."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.settimeout(0.5)
        # Connect to a dummy external IP to determine interface
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'


class IPTVRequestHandler(http.server.BaseHTTPRequestHandler):
    """
    HTTP Request Handler serving dynamic M3U playlists, manifest rewriting,
    and video chunk streaming with upstream header injection.
    """
    server_version = "SportsurgeIPTV/1.4.0"

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        path = parsed.path
        query = urllib.parse.parse_qs(parsed.query)

        if path in ('/', '/status'):
            self._handle_status()
        elif path in ('/playlist.m3u', '/playlist.m3u8', '/sportsurge.m3u'):
            self._handle_playlist(query)
        elif path == '/m3u8':
            self._handle_m3u8(query)
        elif path == '/ts':
            self._handle_ts(query)
        elif path == '/resolve':
            self._handle_resolve(query)
        else:
            self.send_response(404)
            self.end_headers()
            self.wfile.write(b"404 Not Found")

    def _handle_status(self):
        """Displays status webpage and JSON API info."""
        local_ip = get_local_ip()
        port = self.server.server_port
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Sportsurge IPTV Proxy Server</title>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #0f172a; color: #f8fafc; padding: 30px; }}
        .card {{ max-width: 680px; margin: 0 auto; background: #1e293b; padding: 25px; border-radius: 12px; border: 1px solid #334155; }}
        h1 {{ color: #38bdf8; margin-top: 0; }}
        code {{ background: #0f172a; color: #38bdf8; padding: 3px 8px; border-radius: 4px; font-size: 1.1em; }}
        .badge {{ display: inline-block; background: #22c55e; color: #052e16; font-weight: bold; padding: 4px 10px; border-radius: 9999px; margin-bottom: 15px; }}
        ol {{ line-height: 1.8; color: #cbd5e1; }}
        a {{ color: #38bdf8; text-decoration: none; }}
    </style>
</head>
<body>
    <div class="card">
        <span class="badge">● SERVER ONLINE</span>
        <h1>Sportsurge TiviMate IPTV Server</h1>
        <p>Built-in proxy streaming server for TiviMate Multi-View (split-screen / quad-box) on Firestick & Android TV.</p>
        <hr style="border: 0; border-top: 1px solid #334155; margin: 20px 0;">
        <h3>📲 TiviMate Playlist URLs:</h3>
        <p><strong>Same-Device (Firestick Loopback):</strong><br>
           <code>http://127.0.0.1:{port}/playlist.m3u</code></p>
        <p><strong>LAN Network Sharing (Other Devices / Tablets):</strong><br>
           <code>http://{local_ip}:{port}/playlist.m3u</code></p>
        <hr style="border: 0; border-top: 1px solid #334155; margin: 20px 0;">
        <h3>⚡ Multi-View Remote Control Quick Guide:</h3>
        <ol>
            <li>Open TiviMate &gt; <strong>Add Playlist</strong> &gt; <strong>M3U playlist</strong> &gt; enter the URL above.</li>
            <li>Tune into any game or 24/7 sports channel full screen.</li>
            <li>Press and hold the <strong>Select / OK</strong> button on your remote.</li>
            <li>From the bottom menu, select <strong>Multi-View</strong> (grid icon).</li>
            <li>Select <strong>Add Screen</strong> to create a 2-screen, 3-screen, or 4-screen quad-box!</li>
            <li>Use the <strong>Directional Pad</strong> to switch active game audio in real time.</li>
        </ol>
    </div>
</body>
</html>"""
        body = html.encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_playlist(self, query):
        """Generates a dynamic, fully-tagged M3U playlist."""
        host = self.headers.get('Host', f"127.0.0.1:{self.server.server_port}")
        base_proxy = f"http://{host}"

        lines = ['#EXTM3U name="Sportsurge Live Sports"']

        # 1. Add Fast Channels (Direct HLS)
        for ch in FAST_SPORTS_CHANNELS:
            name = ch['name']
            group = ch['group']
            logo = ch['logo']
            url = ch['url']
            lines.append(f'#EXTINF:-1 tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}')
            lines.append(url)

        # 2. Add 24/7 Sports TV Networks
        include_channels = query.get('channels', ['true'])[0].lower() != 'false'
        if include_channels:
            try:
                cm = channels.SportsChannelsManager(timeout=5)
                all_chs = cm.get_all_channels()
                for name, data in sorted(all_chs.items()):
                    links = data.get('links', [])
                    if not links:
                        continue
                    first_link = links[0]
                    lang = data.get('language', 'US')
                    logo = data.get('icon') or ''
                    group = "🏈 US & Canadian Sports" if lang in ('US', 'CA') else f"⚽ Global Sports ({lang})"

                    # Proxy URL through the server's resolver
                    stream_url = f"{base_proxy}/resolve?url={urllib.parse.quote(first_link)}&name={urllib.parse.quote(name)}"
                    lines.append(f'#EXTINF:-1 tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}')
                    lines.append(stream_url)
            except Exception as e:
                pass

        # 3. Add Active Live Games (StreamEast / Live matches)
        include_games = query.get('games', ['true'])[0].lower() != 'false'
        if include_games:
            try:
                se = streameast.StreamEastScraper(timeout=5)
                live_events = se.get_live_events()
                for ev in live_events:
                    title = ev.get('title', '')
                    cat = ev.get('category_name', 'Live Sports')
                    logo = ev.get('icon', '')
                    ev_url = ev.get('streameast_url') or ev.get('url', '')
                    if not title or not ev_url:
                        continue

                    stream_url = f"{base_proxy}/resolve?url={urllib.parse.quote(ev_url)}&name={urllib.parse.quote(title)}"
                    lines.append(f'#EXTINF:-1 tvg-name="{title}" tvg-logo="{logo}" group-title="🔥 Live Games ({cat})",{title}')
                    lines.append(stream_url)
            except Exception:
                pass

        body = '\n'.join(lines).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/x-mpegurl; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        self.wfile.write(body)

    def _handle_resolve(self, query):
        """Resolves an upstream web stream link and redirects or serves rewritten M3U8."""
        raw_url = query.get('url', [''])[0]
        name = query.get('name', ['Sportsurge'])[0]
        if not raw_url:
            self.send_response(400)
            self.end_headers()
            self.wfile.write(b"Missing url parameter")
            return

        resolver = resolvers.StreamResolver(user_agent=DEFAULT_UA, timeout=6)
        resolved_url = None
        final_headers = None

        # Check if URL is already a direct .m3u8
        if '.m3u8' in raw_url:
            resolved_url = raw_url
            final_headers = {'User-Agent': DEFAULT_UA}
        elif 'streameast' in raw_url:
            try:
                se = streameast.StreamEastScraper(user_agent=DEFAULT_UA, timeout=6)
                streams = se.get_match_streams(raw_url)
                for s in streams:
                    s_url = s.get('url')
                    if s_url:
                        res, hdrs = resolver.resolve(s_url)
                        if res and '.m3u8' in res:
                            resolved_url = res
                            final_headers = hdrs
                            break
            except Exception:
                pass
        else:
            # General channel resolution
            res, hdrs = resolver.resolve(raw_url)
            if res and '.m3u8' in res:
                resolved_url = res
                final_headers = hdrs

        if not resolved_url:
            self.send_response(503)
            self.end_headers()
            self.wfile.write(f"Unable to resolve live stream for {name}".encode('utf-8'))
            return

        # Clean URL if pipe format
        clean_m3u8 = resolved_url.split('|')[0]
        ref = final_headers.get('Referer', '') if final_headers else ''

        # Redirect client to the rewritten /m3u8 endpoint
        host = self.headers.get('Host', f"127.0.0.1:{self.server.server_port}")
        m3u8_endpoint = f"http://{host}/m3u8?url={urllib.parse.quote(clean_m3u8)}&ref={urllib.parse.quote(ref)}"
        self.send_response(302)
        self.send_header('Location', m3u8_endpoint)
        self.end_headers()

    def _handle_m3u8(self, query):
        """Fetches remote HLS manifest and rewrites chunk lines to proxy through /ts."""
        target_url = query.get('url', [''])[0]
        referer = query.get('ref', [''])[0]
        if not target_url:
            self.send_response(400)
            self.end_headers()
            return

        headers = {
            'User-Agent': DEFAULT_UA,
            'Accept': '*/*',
            'Connection': 'keep-alive'
        }
        if referer:
            headers['Referer'] = referer
            parsed_ref = urllib.parse.urlsplit(referer)
            headers['Origin'] = f"{parsed_ref.scheme}://{parsed_ref.netloc}"

        try:
            req = urllib.request.Request(target_url, headers=headers)
            with urllib.request.urlopen(req, timeout=8) as resp:
                content = resp.read().decode('utf-8', errors='ignore')

            # Base URL for relative paths
            base_url = target_url.rsplit('/', 1)[0] + '/'
            host = self.headers.get('Host', f"127.0.0.1:{self.server.server_port}")
            base_proxy = f"http://{host}"

            rewritten = []
            for line in content.splitlines():
                sline = line.strip()
                if sline and not sline.startswith('#'):
                    chunk_url = urllib.parse.urljoin(base_url, sline)
                    if '.m3u8' in chunk_url:
                        rewritten_url = f"{base_proxy}/m3u8?url={urllib.parse.quote(chunk_url)}&ref={urllib.parse.quote(referer)}"
                    else:
                        rewritten_url = f"{base_proxy}/ts?url={urllib.parse.quote(chunk_url)}&ref={urllib.parse.quote(referer)}"
                    rewritten.append(rewritten_url)
                else:
                    rewritten.append(line)

            body = '\n'.join(rewritten).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
            self.send_header('Content-Length', str(len(body)))
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(body)
        except Exception as e:
            self.send_response(502)
            self.end_headers()
            self.wfile.write(str(e).encode('utf-8'))

    def _handle_ts(self, query):
        """Relays video chunks directly to player with required Referer/Origin headers."""
        target_url = query.get('url', [''])[0]
        referer = query.get('ref', [''])[0]
        if not target_url:
            self.send_response(400)
            self.end_headers()
            return

        headers = {
            'User-Agent': DEFAULT_UA,
            'Accept': '*/*',
            'Connection': 'keep-alive'
        }
        if referer:
            headers['Referer'] = referer
            parsed_ref = urllib.parse.urlsplit(referer)
            headers['Origin'] = f"{parsed_ref.scheme}://{parsed_ref.netloc}"

        try:
            req = urllib.request.Request(target_url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                chunk_data = resp.read()

            self.send_response(200)
            self.send_header('Content-Type', 'video/mp2t')
            self.send_header('Content-Length', str(len(chunk_data)))
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            self.wfile.write(chunk_data)
        except Exception as e:
            self.send_response(502)
            self.end_headers()

    def log_message(self, format, *args):
        # Suppress stdout spam during playback
        pass


class ThreadedIPTVServer(http.server.ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True


_SERVER_INSTANCE = None
_SERVER_THREAD = None
_SERVER_LOCK = threading.Lock()


def start_iptv_server(port=DEFAULT_PORT):
    """Starts the IPTV Proxy Server in a background daemon thread."""
    global _SERVER_INSTANCE, _SERVER_THREAD
    with _SERVER_LOCK:
        if _SERVER_INSTANCE is not None:
            return True, f"http://127.0.0.1:{_SERVER_INSTANCE.server_port}"

        try:
            server = ThreadedIPTVServer(('0.0.0.0', port), IPTVRequestHandler)
            _SERVER_INSTANCE = server
            _SERVER_THREAD = threading.Thread(target=server.serve_forever, daemon=True)
            _SERVER_THREAD.start()
            return True, f"http://127.0.0.1:{port}"
        except Exception as e:
            return False, str(e)


def stop_iptv_server():
    """Shuts down the running IPTV Proxy Server."""
    global _SERVER_INSTANCE, _SERVER_THREAD
    with _SERVER_LOCK:
        if _SERVER_INSTANCE:
            try:
                _SERVER_INSTANCE.shutdown()
                _SERVER_INSTANCE.server_close()
            except Exception:
                pass
            _SERVER_INSTANCE = None
            _SERVER_THREAD = None
            return True
        return False


def is_server_running():
    """Checks if the proxy server is currently active."""
    return _SERVER_INSTANCE is not None


def get_server_port():
    if _SERVER_INSTANCE:
        return _SERVER_INSTANCE.server_port
    return DEFAULT_PORT


def export_m3u_file(destination_path, server_url=None):
    """
    Exports a complete M3U playlist to a file on disk (e.g. /sdcard/Download/sportsurge_tivimate.m3u).
    Returns (success: bool, count: int, error_msg: str)
    """
    try:
        url = server_url or f"http://127.0.0.1:{get_server_port()}"
        m3u_url = f"{url}/playlist.m3u"
        req = urllib.request.Request(m3u_url, headers={'User-Agent': DEFAULT_UA})
        with urllib.request.urlopen(req, timeout=10) as resp:
            content = resp.read().decode('utf-8', errors='ignore')

        os.makedirs(os.path.dirname(os.path.abspath(destination_path)), exist_ok=True)
        with open(destination_path, 'w', encoding='utf-8') as f:
            f.write(content)

        channel_count = content.count('#EXTINF:')
        return True, channel_count, ''
    except Exception as e:
        return False, 0, str(e)
