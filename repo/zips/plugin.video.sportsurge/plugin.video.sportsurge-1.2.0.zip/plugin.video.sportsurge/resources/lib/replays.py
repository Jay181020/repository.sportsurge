# -*- coding: utf-8 -*-
"""
Sports Replay & VOD scraper for Sportsurge.
Extracts full match replays (Formula 1, Premier League, UFC, NFL, NBA)
and integrates with AllDebrid and Real-Debrid for buffer-free streaming.
"""

import re
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup
from debrid import RealDebridClient, AllDebridClient

DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

REPLAY_CATEGORIES = [
    {'id': 'f1', 'name': '🏎️ Formula 1 & Motorsports Replays', 'query': 'Formula 1'},
    {'id': 'epl', 'name': '⚽ Premier League & European Soccer Replays', 'query': 'Premier League'},
    {'id': 'ucl', 'name': '🏆 UEFA Champions League Replays', 'query': 'UCL'},
    {'id': 'ufc', 'name': '🥊 UFC & MMA Full Fight Replays', 'query': 'UFC'},
    {'id': 'nfl', 'name': '🏈 NFL & American Football Replays', 'query': 'NFL'},
    {'id': 'nba', 'name': '🏀 NBA & Basketball Replays', 'query': 'NBA'},
]


class ReplaysScraper:
    def __init__(self, user_agent=DEFAULT_UA, timeout=10):
        self.user_agent = user_agent
        self.timeout = timeout
        self.base_url = 'https://fullmatchsports.cc'

    def get_categories(self):
        """Returns the replay sports categories."""
        return REPLAY_CATEGORIES

    def get_replays_for_category(self, cat_id='f1'):
        """Fetches list of available match replays for category."""
        cat = next((c for c in REPLAY_CATEGORIES if c['id'] == cat_id), None)
        query = cat['query'] if cat else 'Formula 1'

        url = f"{self.base_url}/?s={urllib.parse.quote(query)}"
        req = urllib.request.Request(url, headers={'User-Agent': self.user_agent})
        replays = []

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                html = resp.read().decode('utf-8', errors='ignore')
            soup = BeautifulSoup(html, 'html.parser')
            items = soup.select('article')

            for it in items:
                h2 = it.select_one('h2.entry-title a')
                if not h2:
                    continue
                title = h2.text.strip()
                link = h2.get('href')

                # Thumbnail / poster
                img = it.select_one('img')
                icon = img.get('src', '') if img else ''

                # Time / date
                time_tag = it.select_one('time')
                date_str = time_tag.text.strip() if time_tag else ''

                replays.append({
                    'title': title,
                    'url': link,
                    'icon': icon,
                    'date': date_str,
                    'category': cat['name'] if cat else 'Replay'
                })
        except Exception as e:
            print(f"Error scraping replays: {e}")

        return replays

    def get_replay_video_sources(self, article_url):
        """
        Parses article page to extract direct video/hoster links (Mega, 1fichier, Rapidgator, etc.).
        Returns list of source dicts: [{'title': str, 'url': str, 'hoster': str}]
        """
        req = urllib.request.Request(article_url, headers={'User-Agent': self.user_agent})
        sources = []

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                html = resp.read().decode('utf-8', errors='ignore')
            soup = BeautifulSoup(html, 'html.parser')

            # Look for download / cloud hoster buttons
            links = soup.select('a.maxbutton, a[href*="mega.nz"], a[href*="1fichier"], a[href*="rapidgator"], a[href*="filemoon"], a[href*="streamtape"]')
            for idx, a in enumerate(links):
                href = a.get('href', '').strip()
                if not href or 'ko-fi' in href:
                    continue
                btn_text = a.text.strip() or f"Source {idx + 1}"

                hoster = 'Unknown'
                if 'mega.nz' in href:
                    hoster = 'Mega'
                elif '1fichier' in href:
                    hoster = '1fichier'
                elif 'rapidgator' in href:
                    hoster = 'Rapidgator'
                elif 'filemoon' in href:
                    hoster = 'Filemoon'
                elif 'streamtape' in href:
                    hoster = 'Streamtape'

                sources.append({
                    'title': f"[{hoster}] {btn_text}",
                    'url': href,
                    'hoster': hoster
                })
        except Exception as e:
            print(f"Error parsing replay sources: {e}")

        return sources

    def resolve_replay_stream(self, source_url, debrid_enabled=False, debrid_service='0', rd_token='', ad_token=''):
        """
        Resolves a replay video link using:
        1. Real-Debrid / AllDebrid unrestrict (if configured)
        2. ResolveURL (supports 230+ video file hosters)
        3. Direct source URL
        """
        if not source_url:
            return None

        # 1. Real-Debrid / AllDebrid unrestrict
        if debrid_enabled:
            if debrid_service == '0' and rd_token:
                rd = RealDebridClient(rd_token)
                direct = rd.unrestrict(source_url)
                if direct:
                    return direct
            elif debrid_service == '1' and ad_token:
                ad = AllDebridClient(ad_token)
                direct = ad.unrestrict(source_url)
                if direct:
                    return direct

        # 2. ResolveURL Fallback (230+ hosters)
        try:
            import resolveurl
            if resolveurl.HostedMediaFile(source_url).valid_url():
                resolved = resolveurl.resolve(source_url)
                if resolved:
                    return resolved
        except Exception:
            pass

        return source_url

