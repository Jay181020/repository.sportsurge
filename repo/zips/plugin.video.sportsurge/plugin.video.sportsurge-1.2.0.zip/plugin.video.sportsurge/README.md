# Sportsurge Kodi Video Addon (`plugin.video.sportsurge`)

Kodi Video Add-on for Sportsurge live sports streaming, powered by an advanced multi-tier resolver engine replicated from SportHD.

## Features
- **Live Sports Feeds**: 200+ daily games across NFL, NBA, Premier League, MLB, NHL, MMA/UFC, Boxing, F1, and WWE.
- **SportHD Resolver Engine**:
  - `?ppcfg=1` direct JSON probe.
  - Multi-mirror rotation (`nexa.st`, `s1.nexa.st`, `s2.nexa.st`, `vertex.st`).
  - Layered `window._econfig` 4-chunk base64 permutation deobfuscator.
  - Dean Edwards P.A.C.K.E.R javascript unpacker.
  - Automatic fallback to unblocked live sports feed (`super.league.st`) with zero Cloudflare Turnstile challenges.
- **Cross-Platform**: Fully compatible with Amazon Firestick, Android TV, Nvidia Shield, and PC (Kodi 19 / 20 / 21).
- **Auto-Update Engine**: In-addon auto-updater that syncs releases directly from this private GitHub repository.

## Installation
1. Download `plugin.video.sportsurge-1.0.0.zip` from Releases.
2. In Kodi, go to **Settings** > **System** > **Add-ons** > Enable **Unknown sources**.
3. Go to **Add-ons** > **Install from zip file** and select the downloaded zip.
