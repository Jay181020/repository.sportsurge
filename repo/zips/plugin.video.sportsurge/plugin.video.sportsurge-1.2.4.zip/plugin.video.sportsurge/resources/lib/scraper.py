# -*- coding: utf-8 -*-
"""
Sportsurge scraper: Extracts live sports categories, matches, and stream links.
Supports direct HTTP requests, manual cf_clearance cookies, and FlareSolverr.
"""

import json
import re
import time
import urllib.request
import urllib.parse
from bs4 import BeautifulSoup
from streameast import StreamEastScraper

DEFAULT_BASE_URL = 'https://v2.sportsurge.net'
DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

# Canonical sports list with display icons/labels
CATEGORIES = [
    {'id': 'all', 'name': '🔴 Live Sports (All Active)', 'slug': 'live-sports/'},
    {'id': '14', 'name': '🏈 Football (NFL, CFB, CFL, UFL)', 'slug': 'watch-nfl-streams/'},
    {'id': 'basketball', 'name': '🏀 Basketball (NBA, NCAAB, WNBA)', 'slug': 'watch-basketball-streams/'},
    {'id': '2', 'name': '⚾ Baseball (MLB)', 'slug': 'watch-baseball-streams/'},
    {'id': 'hockey', 'name': '🏒 Hockey (NHL)', 'slug': 'watch-hockey-streams/'},
    {'id': 'mma', 'name': '🥊 MMA / UFC', 'slug': 'watch-mma-streams/'},
    {'id': 'boxing', 'name': '🥊 Boxing', 'slug': 'watch-boxing-streams/'},
    {'id': '26', 'name': '⚽ Soccer', 'slug': 'https://soccersurge.io/'},
    {'id': 'motorsports', 'name': '🏎️ Motor Sports (F1, MotoGP, NASCAR)', 'slug': 'watch-f1-streams/'},
    {'id': 'wwe', 'name': '🤼 WWE', 'slug': 'watch-wwe-streams/'},
]


def _clean_match_name(s):
    s = s.lower()
    s = re.sub(r'[^a-z0-9\s]', ' ', s)
    stop = {'fc', 'cf', 'sc', 'the', 'club', 'team'}
    return [w for w in s.split() if w not in stop and len(w) > 1]


def _split_match_teams(title, teams=None):
    if teams and len(teams) >= 2:
        return teams[0], teams[1]
    for sep in [' vs ', ' vs. ', ' v ', ' @ ', ' - ']:
        if sep in title.lower():
            parts = re.split(re.escape(sep), title, flags=re.IGNORECASE)
            if len(parts) >= 2:
                return parts[0].strip(), parts[1].strip()
    return title, ''


def _team_similarity(t1, t2):
    w1 = set(_clean_match_name(t1))
    w2 = set(_clean_match_name(t2))
    if not w1 or not w2:
        return False
    if w1 == w2:
        return True
    inter = w1.intersection(w2)
    if inter == w1 or inter == w2:
        diff1 = w1 - inter
        diff2 = w2 - inter
        conflict_pairs = [{'city', 'united'}, {'real', 'atletico'}]
        for cp in conflict_pairs:
            if (cp & diff1) and (cp & diff2):
                return False
        return True
    union = w1.union(w2)
    return (len(inter) / len(union)) >= 0.6


def _matches_same_event(title1, teams1, title2, teams2):
    a1, b1 = _split_match_teams(title1, teams1)
    a2, b2 = _split_match_teams(title2, teams2)
    if not b1 or not b2:
        return _team_similarity(a1, a2)
    return (_team_similarity(a1, a2) and _team_similarity(b1, b2)) or \
           (_team_similarity(a1, b2) and _team_similarity(b1, a2))


class SportsurgeScraper:
    def __init__(self, base_url=DEFAULT_BASE_URL, user_agent=DEFAULT_UA,
                 cf_clearance='', use_flaresolverr=False, flaresolverr_url='',
                 use_proxy=False, proxy_url='', timeout=10):
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip('/')
        self.user_agent = user_agent or DEFAULT_UA
        self.cf_clearance = (cf_clearance or '').strip()
        self.use_flaresolverr = use_flaresolverr
        self.flaresolverr_url = flaresolverr_url or 'http://127.0.0.1:8191/v1'
        self.use_proxy = use_proxy
        self.proxy_url = (proxy_url or '').strip()
        self.timeout = timeout
        self.streameast = StreamEastScraper(user_agent=self.user_agent, timeout=self.timeout)

        # Configure opener with proxy if enabled
        if self.use_proxy and self.proxy_url:
            proxy_handler = urllib.request.ProxyHandler({
                'http': self.proxy_url,
                'https': self.proxy_url
            })
            self.opener = urllib.request.build_opener(proxy_handler)
        else:
            self.opener = urllib.request.build_opener()

    def fetch_html(self, url, referer=None):
        """Fetches HTML using FlareSolverr if enabled, else standard urllib."""
        if self.use_flaresolverr and self.flaresolverr_url:
            return self._fetch_via_flaresolverr(url)
        return self._fetch_direct(url, referer=referer)

    def _fetch_direct(self, url, referer=None):
        headers = {
            'User-Agent': self.user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Upgrade-Insecure-Requests': '1'
        }
        if referer:
            headers['Referer'] = referer
        if self.cf_clearance:
            headers['Cookie'] = f"cf_clearance={self.cf_clearance}"

        req = urllib.request.Request(url, headers=headers)
        with self.opener.open(req, timeout=self.timeout) as resp:
            return resp.read().decode('utf-8', errors='ignore')

    def _fetch_via_flaresolverr(self, url):
        """Dispatches request through FlareSolverr to solve Cloudflare challenge."""
        payload = json.dumps({
            'cmd': 'request.get',
            'url': url,
            'maxTimeout': int(self.timeout * 1000)
        }).encode('utf-8')

        req = urllib.request.Request(
            self.flaresolverr_url,
            data=payload,
            headers={'Content-Type': 'application/json'}
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout + 15) as resp:
                data = json.loads(resp.read().decode('utf-8'))
                if data.get('status') == 'ok':
                    return data.get('solution', {}).get('response', '')
                raise RuntimeError(f"FlareSolverr error: {data.get('message', 'Unknown error')}")
        except urllib.error.URLError as e:
            reason = str(e.reason if hasattr(e, 'reason') else e)
            if '10061' in reason or 'refused' in reason.lower():
                raise RuntimeError(
                    f"FlareSolverr is not running on {self.flaresolverr_url} (Connection Refused Win10061).\n"
                    "Please start FlareSolverr first, or disable FlareSolverr in the Sportsurge Add-on Settings."
                )
            raise RuntimeError(f"Failed to connect to FlareSolverr: {reason}")


    def get_categories(self):
        """Returns the list of sport categories."""
        return CATEGORIES

    def get_live_events(self, category_id=None):
        """
        Scrapes live matches from /live-sports/ (or super.league.st fallback).
        Merges matching StreamEast live feeds and appends unique StreamEast matches.
        """
        matches = []
        try:
            url = f"{self.base_url}/live-sports/"
            html = self.fetch_html(url)
            soup = BeautifulSoup(html, 'html.parser')
            rows = soup.select('.match-row')
            if not rows:
                matches = self.get_league_events(category_id=category_id)
            else:
                for row in rows:
                    cat_attr = row.get('data-category', '').strip()
                    # Filter if a specific category was requested
                    if category_id and category_id != 'all' and cat_attr != category_id:
                        search_attr = row.get('data-search', '').lower()
                        if category_id.lower() not in search_attr:
                            continue

                    href = row.get('href', '').strip()
                    if not href:
                        continue
                    match_url = urllib.parse.urljoin(self.base_url + '/', href)
                    title = row.get('title', '').strip()

                    teams = []
                    logos = []
                    team_nodes = row.select('.match-row-team')
                    for tn in team_nodes:
                        name_span = tn.select_one('.match-row-team-name')
                        if name_span:
                            teams.append(name_span.text.strip())
                        img = tn.select_one('img')
                        if img and img.get('src'):
                            logos.append(urllib.parse.urljoin(self.base_url + '/', img.get('src')))

                    if not title:
                        title = ' vs '.join(teams) if teams else 'Live Sports Match'

                    cat_elem = row.select_one('.match-row-category')
                    category_name = cat_elem.text.strip() if cat_elem else ''

                    time_elem = row.select_one('.match-row-time') or row.select_one('.match-row-status')
                    time_text = ''
                    if time_elem:
                        time_text = ' '.join(time_elem.text.split())

                    is_live_row = 'live' in time_text.lower() or bool(row.select_one('.live-badge, .is-live, [class*="live"]'))

                    pill = row.select_one('.watch-pill')
                    stream_count_str = pill.text.strip() if pill else ''
                    s_match = re.search(r'(\d+)', stream_count_str)
                    stream_count = int(s_match.group(1)) if s_match else 0

                    icon = logos[0] if logos else ''
                    fanart = logos[1] if len(logos) > 1 else icon

                    matches.append({
                        'title': title,
                        'teams': teams,
                        'logos': logos,
                        'icon': icon,
                        'fanart': fanart,
                        'category_name': category_name,
                        'category_id': cat_attr,
                        'time_text': time_text,
                        'is_live': is_live_row,
                        'stream_count': stream_count,
                        'url': match_url
                    })
        except Exception as e:
            err_str = str(e).lower()
            if '403' in err_str or 'forbidden' in err_str or 'turnstile' in err_str or 'flaresolverr' in err_str:
                matches = self.get_league_events(category_id=category_id)
            else:
                matches = self.get_league_events(category_id=category_id)

        # Merge StreamEast events seamlessly into the match list
        try:
            se_events = self.streameast.get_live_events(category_id=category_id)
            for se in se_events:
                se_title = se.get('title', '')
                se_teams = se.get('teams', [])
                se_url = se.get('streameast_url', '')

                matched = False
                for m in matches:
                    if _matches_same_event(m.get('title', ''), m.get('teams', []), se_title, se_teams):
                        if '@@se=' not in m['url'] and se_url:
                            m['url'] = f"{m['url']}@@se={urllib.parse.quote(se_url)}"
                            m['stream_count'] = m.get('stream_count', 0) + 1
                        if se.get('is_live'):
                            m['is_live'] = True
                        if se.get('start_timestamp') and not m.get('start_timestamp'):
                            m['start_timestamp'] = se['start_timestamp']
                        matched = True
                        break

                if not matched:
                    # Append match unique to StreamEast
                    matches.append(se)
        except Exception:
            pass

        return matches

    def get_league_events(self, category_id=None):
        """
        Scrapes live matches from super.league.st (unblocked feed).
        Provides 200+ live sports events with working servers and accurate Unix timestamps.
        """
        now_ts = time.time()
        try:
            url = 'https://super.league.st'
            req = urllib.request.Request(url, headers={'User-Agent': self.user_agent})
            html = self.opener.open(req, timeout=self.timeout).read().decode('utf-8', errors='ignore')
            for line in html.splitlines():
                if 'window.matches = JSON.parse(`' in line:
                    raw_json = line.split('window.matches = JSON.parse(`')[1].rsplit('`)', 1)[0]
                    matches_data = json.loads(raw_json)
                    matches = []
                    for m in matches_data:
                        sport = m.get('sport', '')
                        if category_id and category_id != 'all':
                            cat_lower = category_id.lower()
                            if cat_lower not in sport.lower() and cat_lower not in str(m).lower():
                                continue
                        team1 = m.get('team1', '')
                        team2 = m.get('team2', '')
                        title = f"{team1} vs {team2}" if team1 and team2 else m.get('matchstr', 'Live Match')
                        channels = m.get('channels', [])
                        chans_json = urllib.parse.quote(json.dumps(channels))
                        match_url = f"league://channels={chans_json}"

                        start_ts_raw = m.get('startTimestamp')
                        start_ts = None
                        is_live = False
                        if start_ts_raw:
                            start_ts = start_ts_raw / 1000.0 if start_ts_raw > 1e11 else float(start_ts_raw)
                            dur_sec = m.get('duration', 120) * 60
                            diff_sec = now_ts - start_ts
                            if 0 <= diff_sec <= dur_sec:
                                is_live = True

                        matches.append({
                            'title': title,
                            'teams': [team1, team2] if team1 and team2 else [title],
                            'logos': [m.get('team1Img', ''), m.get('team2Img', '')],
                            'icon': m.get('team1Img', ''),
                            'fanart': m.get('team2Img', m.get('team1Img', '')),
                            'category_name': sport,
                            'category_id': sport,
                            'time_text': m.get('matchText', '').split('[')[0].strip(),
                            'start_timestamp': start_ts,
                            'is_live': is_live,
                            'stream_count': len(channels),
                            'url': match_url
                        })
                    return matches
        except Exception:
            pass
        return []

    def _get_league_streams(self, match_url):
        query = match_url.replace('league://channels=', '')
        channels = json.loads(urllib.parse.unquote(query))
        streams = []
        for ch in channels:
            name = ch.get('name', 'Stream')
            lang = ch.get('language', 'EN')
            links = ch.get('links', [])
            for idx, lnk in enumerate(links):
                label = f"[{lang}] {name} - Server {idx + 1}" if len(links) > 1 else f"[{lang}] {name}"
                streams.append({
                    'title': label,
                    'site_name': name,
                    'tier': 'HD',
                    'resolution': '1080p',
                    'fps': '60fps',
                    'bitrate': 'HD',
                    'language': lang,
                    'ads': 'No ads',
                    'url': lnk,
                    'match_url': match_url
                })
        return streams

    def _get_sportsurge_streams(self, match_url):
        html = self.fetch_html(match_url, referer=f"{self.base_url}/live-sports/")
        soup = BeautifulSoup(html, 'html.parser')

        streams = []
        items = soup.select('.stream-item')

        for it in items:
            href = it.get('data-href', '').strip()
            if not href:
                inner_link = it.select_one('[data-href]')
                if inner_link:
                    href = inner_link.get('data-href', '').strip()

            if not href:
                continue

            site_elem = it.select_one('.stream-row-site-name')
            site_name = site_elem.text.strip() if site_elem else 'Stream'

            tier_elem = it.select_one('.stream-tier-badge')
            tier = tier_elem.text.strip() if tier_elem else ''

            specs = [s.text.strip() for s in it.select('.stream-row-spec')]
            resolution = specs[0] if len(specs) > 0 else '720p'
            fps = f"{specs[1]}fps" if len(specs) > 1 and specs[1].isdigit() else ''
            bitrate = f"{specs[2]}kbps" if len(specs) > 2 and specs[2].isdigit() else ''
            language = specs[3] if len(specs) > 3 else 'English'
            ads_rating = f"{specs[5]} ads" if len(specs) > 5 else ''

            qual_fps = f"{resolution} {fps}".strip()
            label_parts = [f"[{qual_fps}]" if qual_fps else "[HD]", site_name]
            if tier:
                label_parts.append(f"({tier})")
            if language and language != 'English':
                label_parts.append(f"[{language}]")
            if bitrate:
                label_parts.append(f"- {bitrate}")

            display_title = ' '.join(label_parts)

            streams.append({
                'title': display_title,
                'site_name': site_name,
                'tier': tier,
                'resolution': resolution,
                'fps': fps,
                'bitrate': bitrate,
                'language': language,
                'ads': ads_rating,
                'url': href,
                'match_url': match_url
            })

        return streams

    def get_match_streams(self, match_url):
        """
        Scrapes all stream providers for a specific match.
        Supports standard Sportsurge matches, unblocked league matches, and StreamEast feeds.
        Can handle composite URLs (primary@@se=...).
        """
        se_url = None
        if '@@se=' in match_url:
            primary_part, se_part = match_url.split('@@se=', 1)
            se_url = urllib.parse.unquote(se_part)
            match_url = primary_part

        streams = []

        if match_url.startswith('streameast://'):
            se_url = match_url
            match_url = ''

        if match_url.startswith('league://'):
            streams = self._get_league_streams(match_url)
        elif match_url:
            try:
                streams = self._get_sportsurge_streams(match_url)
            except Exception:
                streams = []

        # Scrape and merge StreamEast streams
        if se_url:
            try:
                se_streams = self.streameast.get_match_streams(se_url)
                streams.extend(se_streams)
            except Exception:
                pass

        return streams

