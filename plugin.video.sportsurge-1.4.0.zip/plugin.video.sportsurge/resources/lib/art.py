# -*- coding: utf-8 -*-
"""
Artwork helper for Sportsurge Kodi Add-on.
Resolves custom icon and fanart paths for categories, channels, and tools.
"""

import os

try:
    import xbmcaddon
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

ADDON_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
ART_DIR = os.path.join(ADDON_DIR, 'resources', 'art')

DEFAULT_ICON = os.path.join(ADDON_DIR, 'icon.png')
DEFAULT_FANART = os.path.join(ADDON_DIR, 'fanart.jpg')

ART_MAP = {
    'live_now': 'live_now.png',
    'all': 'all_sports.png',
    '14': 'football.png',
    'football': 'football.png',
    'nfl': 'football.png',
    'cfb': 'football.png',
    'basketball': 'basketball.png',
    'nba': 'basketball.png',
    'wnba': 'basketball.png',
    '2': 'baseball.png',
    'baseball': 'baseball.png',
    'mlb': 'baseball.png',
    'hockey': 'hockey.png',
    'nhl': 'hockey.png',
    'mma': 'mma_ufc.png',
    'ufc': 'mma_ufc.png',
    'boxing': 'boxing.png',
    '26': 'soccer.png',
    'soccer': 'soccer.png',
    'motorsports': 'motorsports.png',
    'f1': 'motorsports.png',
    'wwe': 'wwe.png',
    'channels': 'channels.png',
    'channels_groups': 'channels.png',
    'replays': 'replays.png',
    'replays_menu': 'replays.png',
    'favorites': 'favorites.png',
    'favorites_menu': 'favorites.png',
    'search': 'search.png',
    'optimizer': 'optimizer.png',
    'patch_notes': 'patch_notes.png',
    'about_dev': 'about_dev.png',
    'settings': 'settings.png',
}


def get_art(key, default=None):
    """Returns absolute path to category icon PNG or default."""
    filename = ART_MAP.get(str(key).lower())
    if filename:
        path = os.path.join(ART_DIR, filename)
        if os.path.exists(path):
            return path
    return default or DEFAULT_ICON


def get_art_dict(key):
    """Returns a dict ready for listitem.setArt()."""
    icon_path = get_art(key)
    return {
        'icon': icon_path,
        'thumb': icon_path,
        'poster': icon_path,
        'fanart': DEFAULT_FANART
    }
