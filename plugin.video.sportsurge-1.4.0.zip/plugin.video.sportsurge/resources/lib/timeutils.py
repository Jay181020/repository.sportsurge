# -*- coding: utf-8 -*-
"""
Time and status utilities for Sportsurge.
Handles Kodi/OS timezone detection, converts match times to local clock,
and formats color-coded live/upcoming/finished badges with Unix timestamp precision.
"""

import re
import json
import time
from datetime import datetime, timedelta, timezone

try:
    import xbmc
    KODI_ENV = True
except ImportError:
    KODI_ENV = False


def get_local_utc_offset():
    """
    Returns the user's local timezone offset in hours from UTC.
    First tries Kodi's locale.timezone setting via JSON-RPC,
    then falls back to the host operating system's local clock offset.
    """
    if KODI_ENV:
        try:
            resp_str = xbmc.executeJSONRPC(
                '{"jsonrpc": "2.0", "method": "Settings.GetSettingValue", "params": {"setting": "locale.timezone"}, "id": 1}'
            )
            data = json.loads(resp_str)
            tz_name = data.get('result', {}).get('value', '')
            if tz_name:
                try:
                    import zoneinfo
                    tz = zoneinfo.ZoneInfo(tz_name)
                    offset_sec = datetime.now(tz).utcoffset().total_seconds()
                    return offset_sec / 3600.0
                except Exception:
                    pass
        except Exception:
            pass

    local_offset = datetime.now().astimezone().utcoffset()
    if local_offset is not None:
        return local_offset.total_seconds() / 3600.0
    return 0.0


def parse_event_start(time_str='', start_timestamp=None, is_live=False, category_name=''):
    """
    Parses start time from a Unix timestamp or time string.
    Returns (local_time_str, status_code, delta_minutes)
    status_code: 'live' | 'soon' | 'done' | 'unknown'
    """
    now_ts = time.time()
    sport = str(category_name or '').lower()

    # Estimate realistic duration based on sport type
    if any(s in sport for s in ['football', 'nfl', 'cfb', 'baseball', 'mlb', 'cricket']):
        duration_min = 210
    elif any(s in sport for s in ['motorsports', 'f1', 'nascar', 'wwe', 'boxing', 'mma', 'ufc']):
        duration_min = 180
    else:
        duration_min = 150  # Basketball, Soccer, Hockey, etc.

    # 1. Explicit live flag from scraper card class
    if is_live:
        local_str = 'LIVE NOW'
        if start_timestamp:
            try:
                ts = start_timestamp / 1000.0 if start_timestamp > 1e11 else float(start_timestamp)
                local_dt = datetime.fromtimestamp(ts)
                local_str = local_dt.strftime('%I:%M %p').lstrip('0')
            except Exception:
                pass
        return local_str, 'live', 0

    # 2. Check if time_str explicitly contains 'LIVE'
    if time_str and 'live' in str(time_str).lower():
        return 'LIVE NOW', 'live', 0

    # 3. Process accurate Unix timestamp if available
    if start_timestamp:
        try:
            ts = start_timestamp / 1000.0 if start_timestamp > 1e11 else float(start_timestamp)
            diff_sec = ts - now_ts
            diff_min = int(round(diff_sec / 60.0))
            local_dt = datetime.fromtimestamp(ts)
            local_str = local_dt.strftime('%I:%M %p').lstrip('0')

            if -duration_min <= diff_min <= 0:
                return local_str, 'live', diff_min
            elif diff_min > 0:
                return local_str, 'soon', diff_min
            else:
                return local_str, 'done', diff_min
        except Exception:
            pass

    # 4. Fallback string parsing for HH:MM format
    if not time_str:
        return '', 'unknown', 0

    now = datetime.now(timezone.utc)
    offset_hours = get_local_utc_offset()

    hm_match = re.search(r'\b(\d{1,2}):(\d{2})\b', str(time_str))
    if hm_match:
        hour = int(hm_match.group(1))
        minute = int(hm_match.group(2))

        event_utc = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
        if (event_utc - now).total_seconds() < -12 * 3600:
            event_utc += timedelta(days=1)
        elif (event_utc - now).total_seconds() > 12 * 3600:
            event_utc -= timedelta(days=1)

        event_local = event_utc + timedelta(hours=offset_hours)
        diff_sec = (event_utc - now).total_seconds()
        diff_min = int(round(diff_sec / 60.0))

        local_str = event_local.strftime('%I:%M %p').lstrip('0')

        if -duration_min <= diff_min <= 0:
            status = 'live'
        elif diff_min > 0:
            status = 'soon'
        else:
            status = 'done'

        return local_str, status, diff_min

    return str(time_str), 'unknown', 0


def format_status_badge(time_val='', stream_count=0, start_timestamp=None, is_live=False, category_name=''):
    """
    Formats a user-friendly color badge for Kodi list items:
    - [B][COLOR lime]● LIVE[/COLOR][/B]
    - [COLOR yellow]Starts in 25m (7:30 PM)[/COLOR]
    - [COLOR gray]Ended (5:00 PM)[/COLOR]

    Accepts either an event dictionary as first arg or individual parameters.
    """
    if isinstance(time_val, dict):
        ev = time_val
        time_str = ev.get('time_text', '')
        start_timestamp = ev.get('start_timestamp') or ev.get('startTimestamp')
        is_live = ev.get('is_live', False)
        category_name = ev.get('category_name', '')
    else:
        time_str = str(time_val or '')

    local_str, status, diff_min = parse_event_start(
        time_str=time_str,
        start_timestamp=start_timestamp,
        is_live=is_live,
        category_name=category_name
    )

    if status == 'live':
        time_tag = f" ({local_str})" if local_str and local_str != 'LIVE NOW' else ""
        badge = f"[B][COLOR lime]● LIVE{time_tag}[/COLOR][/B]"
    elif status == 'soon':
        if diff_min < 60:
            badge = f"[COLOR yellow]Starts in {diff_min}m ({local_str})[/COLOR]"
        else:
            hours = diff_min // 60
            mins = diff_min % 60
            badge = f"[COLOR yellow]Starts in {hours}h {mins}m ({local_str})[/COLOR]"
    elif status == 'done':
        badge = f"[COLOR gray]Ended ({local_str})[/COLOR]"
    else:
        badge = f"[COLOR lightblue]{time_str}[/COLOR]" if time_str else ""

    return badge, status

