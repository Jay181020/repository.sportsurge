# -*- coding: utf-8 -*-
"""
Kodi player integration for Sportsurge.
Configures inputstream.adaptive for HLS streams and sets resolved URL for playback.
"""

import sys
import urllib.parse

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False

from resolvers import StreamResolver


class SportsurgePlayer:
    def __init__(self, handle, user_agent='', timeout=10, use_proxy=False, proxy_url=''):
        self.handle = handle
        self.user_agent = user_agent
        self.timeout = timeout
        self.use_proxy = use_proxy
        self.proxy_url = proxy_url
        self.resolver = StreamResolver(
            user_agent=user_agent,
            timeout=timeout,
            use_proxy=use_proxy,
            proxy_url=proxy_url
        )


    def play(self, stream_url, title='Live Stream', icon='', referer='https://v2.sportsurge.net/'):
        """
        Resolves stream URL to playable .m3u8 and passes to Kodi's player.
        """
        if not KODI_AVAILABLE:
            print(f"[SportsurgePlayer] Resolving: {stream_url}")
            resolved_url, headers = self.resolver.resolve(stream_url, referer=referer)
            print(f"[SportsurgePlayer] Resolved URL: {resolved_url}")
            return resolved_url

        progress = xbmcgui.DialogProgress()
        progress.create('Sportsurge', 'Resolving stream link...')

        try:
            progress.update(25, 'Connecting to provider...')
            resolved_url, headers = self.resolver.resolve(stream_url, referer=referer)
            progress.update(80, 'Configuring player...')

            if not resolved_url:
                progress.close()
                xbmcgui.Dialog().notification('Sportsurge', 'Failed to resolve stream. Try another link.', xbmcgui.NOTIFICATION_WARNING, 3500)
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return False

            # Build Kodi ListItem
            listitem = xbmcgui.ListItem(path=resolved_url)
            listitem.setInfo('video', {
                'title': title,
                'mediatype': 'video',
                'playcount': 0
            })

            if icon:
                listitem.setArt({'icon': icon, 'thumb': icon})

            # Configure inputstream.adaptive for HLS playback
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setProperty('mimetype', 'application/vnd.apple.mpegurl')
            listitem.setContentLookup(False)

            if headers:
                header_str = '&'.join(f"{k}={urllib.parse.quote(str(v))}" for k, v in headers.items())
                listitem.setProperty('inputstream.adaptive.stream_headers', header_str)

            progress.update(100, 'Starting playback...')
            progress.close()

            xbmcplugin.setResolvedUrl(self.handle, True, listitem)
            return True

        except Exception as e:
            if progress:
                progress.close()
            xbmcgui.Dialog().notification('Sportsurge', f'Playback error: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return False
