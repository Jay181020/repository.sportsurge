# -*- coding: utf-8 -*-
"""
Main Kodi entry point for Sportsurge add-on (v1.2.4).
Routes incoming plugin URLs to categories, live events, 24/7 channels, replays, streams,
favorites, search, and resilient playback with stream health verification, preferred host scoring, and auto-failover.
"""

import os
import sys
import json
import urllib.parse

# Ensure resources/lib is in python path
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

from scraper import SportsurgeScraper
from player import SportsurgePlayer
from resolvers import StreamResolver
from channels import SportsChannelsManager
from replays import ReplaysScraper
from favorites import FavoritesManager
from timeutils import format_status_badge, parse_event_start
import debrid
import updater
import art
import optimizer
import iptv_server


def get_settings():
    """Retrieves user settings from Kodi or defaults."""
    if not KODI_ENV:
        return {
            'base_url': 'https://v2.sportsurge.net',
            'timeout': 10,
            'preferred_quality': 0,
            'use_flaresolverr': False,
            'flaresolverr_url': 'http://127.0.0.1:8191/v1',
            'custom_user_agent': '',
            'cf_clearance': '',
            'use_proxy': False,
            'proxy_url': '',
            'auto_update_check': True,
            'github_repo': 'Jay181020/plugin.video.sportsurge',
            'github_token': '',
            'autoplay_stream': True,
            'autoplay_timeout': 4,
            'preferred_host': 0,
            'preferred_host_prompted': False,
            'hide_finished_events': False,
            'show_welcome': True,
            'welcome_shown': False,
            'last_version_seen': '',
            'enable_debrid': False,
            'debrid_service': '0',
            'rd_token': '',
            'ad_token': '',
        }

    addon = xbmcaddon.Addon()
    return {
        'base_url': addon.getSetting('base_url') or 'https://v2.sportsurge.net',
        'timeout': int(addon.getSetting('timeout') or 10),
        'preferred_quality': int(addon.getSetting('preferred_quality') or 0),
        'use_flaresolverr': addon.getSetting('use_flaresolverr') == 'true',
        'flaresolverr_url': addon.getSetting('flaresolverr_url') or 'http://127.0.0.1:8191/v1',
        'custom_user_agent': addon.getSetting('custom_user_agent') or '',
        'cf_clearance': addon.getSetting('cf_clearance') or '',
        'use_proxy': addon.getSetting('use_proxy') == 'true',
        'proxy_url': addon.getSetting('proxy_url') or '',
        'auto_update_check': addon.getSetting('auto_update_check') != 'false',
        'github_repo': addon.getSetting('github_repo') or 'Jay181020/plugin.video.sportsurge',
        'github_token': addon.getSetting('github_token') or '',
        'autoplay_stream': addon.getSetting('autoplay_stream') != 'false',
        'autoplay_timeout': int(addon.getSetting('autoplay_timeout') or 4),
        'preferred_host': int(addon.getSetting('preferred_host') or 0),
        'preferred_host_prompted': addon.getSetting('preferred_host_prompted') == 'true',
        'hide_finished_events': addon.getSetting('hide_finished_events') == 'true',
        'show_welcome': addon.getSetting('show_welcome') != 'false',
        'welcome_shown': addon.getSetting('welcome_shown') == 'true',
        'last_version_seen': addon.getSetting('last_version_seen') or '',
        'enable_debrid': addon.getSetting('enable_debrid') == 'true',
        'debrid_service': addon.getSetting('debrid_service') or '0',
        'rd_token': addon.getSetting('rd_token') or '',
        'ad_token': addon.getSetting('ad_token') or '',
    }


def build_url(base, **params):
    """Builds plugin:// URL with trailing slash before query parameters."""
    clean_base = base.rstrip('/') + '/'
    return f"{clean_base}?{urllib.parse.urlencode(params)}"


def set_video_metadata(listitem, title, plot='', genre=''):
    """Sets video metadata using InfoTagVideo on Kodi 20+ with fallback."""
    if hasattr(listitem, 'getVideoInfoTag'):
        try:
            tag = listitem.getVideoInfoTag()
            tag.setTitle(title)
            if plot:
                tag.setPlot(plot)
            if genre:
                tag.setGenres([genre])
            return
        except Exception:
            pass
    listitem.setInfo('video', {'title': title, 'plot': plot, 'genre': genre})


WELCOME_TITLE = "Sportsurge v1.4.0 - Welcome & What's New"
WELCOME_MESSAGE = (
    "Thanks for using my add-on!\n"
    "If you need any help, contact dev (your brother).\n"
    "Enjoy the games! 🏈⚽🏀\n\n"
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    "🔥 [B]WHAT'S NEW IN v1.4.0[/B]\n"
    "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    "📺 [B]TiviMate Multi-View & PiP Integration[/B]:\n"
    "• Watch 2, 3, or 4 live games on screen simultaneously (split-screen / quad-box) on Firestick & Android TV!\n"
    "• Instant 1-click audio switching between games using remote control directional pad.\n\n"
    "⚡ [B]Built-In Kodi IPTV Proxy Server[/B]:\n"
    "• Background streaming server runs locally on port 8899 with zero-latency loopback.\n"
    "• Manifest & TS chunk rewriting with automated Referer injection eliminates 403 Forbidden CDN errors.\n\n"
    "📥 [B]1-Click M3U Playlist Export[/B]:\n"
    "• Export full 140+ channel playlist directly to Firestick internal storage (/sdcard/Download/) or load via local IP.\n\n"
    "🎨 [B]Visual Category Artwork & Posters[/B]:\n"
    "• Custom 512x512 icons for all sports & tools in Wall, Poster, and Card view modes.\n\n"
    "🔥 [B]LIVE NOW Instant Filter & League Sub-Filters[/B]:\n"
    "• Real-time match filter + dedicated league sub-categories for NFL, NBA, EPL, F1, NASCAR."
)

PATCH_NOTES = {
    '1.4.0': WELCOME_MESSAGE,
    '1.3.0': (
        "🎨 Custom category artwork & icons for Wall/Poster view modes.\n"
        "🔥 Dedicated 'LIVE NOW' section.\n"
        "🏆 League sub-filters (NFL, CFB, NBA, EPL, F1).\n"
        "🚀 One-Click Buffer & Speed Optimizer for Kodi 21.\n"
        "⚡ Quick Channel Zapping & Multi-Game Switching."
    ),
    '1.2.4': (
        "⚡ Real-Time Match Status Fix.\n"
        "🎯 Auto-Play Preferred Host selection.\n"
        "🔄 Auto-Update on Kodi Startup."
    ),
}



def check_and_show_welcome(settings):
    """Displays opening welcome greeting and patch notes strictly ONCE per version upgrade."""
    if not KODI_ENV:
        return
    if not settings.get('show_welcome', True):
        return
    current_ver = updater.get_current_version()
    last_seen = settings.get('last_version_seen', '')
    if last_seen != current_ver:
        addon = xbmcaddon.Addon()
        addon.setSetting('last_version_seen', current_ver)
        addon.setSetting('welcome_shown', 'true')
        settings['last_version_seen'] = current_ver
        settings['welcome_shown'] = True
        dialog = xbmcgui.Dialog()
        dialog.ok(WELCOME_TITLE, WELCOME_MESSAGE)


def check_and_show_patch_notes(settings):
    """Displays What's New / Patch Notes dialog once per version upgrade if welcome was disabled."""
    pass


def show_main_menu(base_url, handle, scraper, settings=None):
    """Displays top-level categories and tools in Kodi with custom high-res icons."""
    if settings:
        check_and_show_welcome(settings)

    xbmcplugin.setContent(handle, 'videos')

    # 1. 🔥 LIVE NOW (Happening Right Now)
    live_now_url = build_url(base_url, action='live_now')
    ln_item = xbmcgui.ListItem(label="🔥 LIVE NOW (Happening Right Now)")
    ln_item.setContentLookup(False)
    set_video_metadata(ln_item, title="LIVE NOW (Happening Right Now)", plot="Browse all matches currently playing live right now across all sports.")
    ln_item.setArt(art.get_art_dict('live_now'))
    xbmcplugin.addDirectoryItem(handle, live_now_url, ln_item, isFolder=True)

    # 2. 📺 24/7 Live Sports Channels
    channels_url = build_url(base_url, action='channels_groups')
    ch_item = xbmcgui.ListItem(label="📺 24/7 Live Sports Channels")
    ch_item.setContentLookup(False)
    set_video_metadata(ch_item, title="24/7 Live Sports Channels", plot="Stream 120+ live sports networks (ESPN, FS1, CBS Sports, Sky Sports, TNT, DAZN, TSN)")
    ch_item.setArt(art.get_art_dict('channels'))
    xbmcplugin.addDirectoryItem(handle, channels_url, ch_item, isFolder=True)

    # 3. 📺 TiviMate Multi-View (Split-Screen & Quad-Box)
    tivimate_url = build_url(base_url, action='tivimate_menu')
    tvm_item = xbmcgui.ListItem(label="📺 TiviMate Multi-View (Split-Screen & Quad-Box)")
    tvm_item.setContentLookup(False)
    set_video_metadata(tvm_item, title="TiviMate Multi-View (Split-Screen & Quad-Box)", plot="Watch 2 to 4 live games at once on Firestick / Android TV with 1-click audio switching")
    tvm_item.setArt(art.get_art_dict('channels'))
    xbmcplugin.addDirectoryItem(handle, tivimate_url, tvm_item, isFolder=True)

    # 4. 🎬 Match Replays & Archives (Debrid)
    replays_url = build_url(base_url, action='replays_menu')

    rep_item = xbmcgui.ListItem(label="🎬 Match Replays & Archives (Debrid)")
    rep_item.setContentLookup(False)
    set_video_metadata(rep_item, title="Match Replays & Archives", plot="Watch full game replays in 1080p/4K with AllDebrid & Real-Debrid (NFL, F1, UFC, Premier League)")
    rep_item.setArt(art.get_art_dict('replays'))
    xbmcplugin.addDirectoryItem(handle, replays_url, rep_item, isFolder=True)

    # 4. ⭐ My Favorite Teams
    fav_url = build_url(base_url, action='favorites_menu')
    fav_item = xbmcgui.ListItem(label="⭐ My Favorite Teams")
    fav_item.setContentLookup(False)
    set_video_metadata(fav_item, title="My Favorite Teams", plot="Quick access to all upcoming and live games for your bookmarked teams")
    fav_item.setArt(art.get_art_dict('favorites'))
    xbmcplugin.addDirectoryItem(handle, fav_url, fav_item, isFolder=True)

    # 5. 🔍 Search Matches & Channels
    search_url = build_url(base_url, action='search')
    search_item = xbmcgui.ListItem(label="🔍 Search Matches & Channels")
    search_item.setContentLookup(False)
    set_video_metadata(search_item, title="Search", plot="Search live matches, teams, fighters, and channels")
    search_item.setArt(art.get_art_dict('search'))
    xbmcplugin.addDirectoryItem(handle, search_url, search_item, isFolder=False)

    # 6. Live Sports Categories (with Sub-Leagues routing)
    categories = scraper.get_categories()
    for cat in categories:
        has_subs = bool(cat.get('sub_leagues'))
        if has_subs:
            url = build_url(base_url, action='sub_category', cat_id=cat['id'], cat_name=cat['name'])
        else:
            url = build_url(base_url, action='category', cat_id=cat['id'], cat_name=cat['name'])
        listitem = xbmcgui.ListItem(label=cat['name'])
        listitem.setContentLookup(False)
        set_video_metadata(listitem, title=cat['name'], plot=f"Browse {cat['name']} live events")
        listitem.setArt(art.get_art_dict(cat.get('key', cat['id'])))
        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=True)

    # 7. 🚀 One-Click Buffer & Speed Optimizer
    opt_url = build_url(base_url, action='optimize_buffer')
    opt_item = xbmcgui.ListItem(label="🚀 One-Click Buffer & Speed Optimizer")
    opt_item.setContentLookup(False)
    set_video_metadata(opt_item, title="One-Click Buffer Optimizer", plot="Auto-tunes Kodi 21 RAM buffer cache for Firestick (128MB) or PC/Shield (256MB)")
    opt_item.setArt(art.get_art_dict('optimizer'))
    xbmcplugin.addDirectoryItem(handle, opt_url, opt_item, isFolder=False)

    # 8. 📋 What's New & Patch Notes
    patch_url = build_url(base_url, action='patch_notes')
    patch_item = xbmcgui.ListItem(label="📋 What's New & Patch Notes")
    patch_item.setContentLookup(False)
    set_video_metadata(patch_item, title="What's New & Patch Notes", plot="View latest features, updates, and hot-fixes for Sportsurge")
    patch_item.setArt(art.get_art_dict('patch_notes'))
    xbmcplugin.addDirectoryItem(handle, patch_url, patch_item, isFolder=False)

    # 9. 💬 Developer Note & Help
    about_url = build_url(base_url, action='about_dev')
    about_item = xbmcgui.ListItem(label="💬 Developer Note & Help")
    about_item.setContentLookup(False)
    set_video_metadata(about_item, title='Developer Note & Help', plot='Thanks for using my add-on! If you need any help, contact dev (your brother).')
    about_item.setArt(art.get_art_dict('about_dev'))
    xbmcplugin.addDirectoryItem(handle, about_url, about_item, isFolder=False)

    # 10. 🔄 Check for Updates
    update_url = build_url(base_url, action='check_update')
    update_item = xbmcgui.ListItem(label="🔄 Check for Updates")
    update_item.setContentLookup(False)
    set_video_metadata(update_item, title='Check for Updates', plot='Check GitHub for newer releases and update automatically')
    update_item.setArt(art.get_art_dict('patch_notes'))
    xbmcplugin.addDirectoryItem(handle, update_url, update_item, isFolder=False)

    # 11. ⚙️ Settings
    settings_url = build_url(base_url, action='settings')
    settings_item = xbmcgui.ListItem(label="⚙️ Settings")
    settings_item.setContentLookup(False)
    set_video_metadata(settings_item, title='Settings', plot='Configure Auto-Play, Debrid, timezone, proxy, and quality')
    settings_item.setArt(art.get_art_dict('settings'))
    xbmcplugin.addDirectoryItem(handle, settings_url, settings_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_live_now(base_url, handle, scraper, settings):
    """Displays only matches currently live right now across all sports."""
    xbmcplugin.setContent(handle, 'videos')
    try:
        events = scraper.get_live_now_events()
    except Exception:
        events = []

    fav_mgr = FavoritesManager()
    autoplay = settings.get('autoplay_stream', True)

    if not events:
        empty_item = xbmcgui.ListItem(label="No live matches currently in progress. Check back soon!")
        empty_item.setContentLookup(False)
        empty_item.setArt(art.get_art_dict('live_now'))
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(events)
    for ev in events:
        matched_fav = fav_mgr.is_favorite_match(ev)
        star_prefix = "[B][COLOR gold]★[/COLOR][/B] " if matched_fav else ""
        badge = ev.get('_badge', '[COLOR lime]● LIVE[/COLOR]')
        cat_badge = f" [COLOR gold][{ev.get('category_name', 'Live')}][/COLOR]" if ev.get('category_name') else ""
        stream_tag = f"  [COLOR gray]({ev['stream_count']} streams)[/COLOR]" if ev.get('stream_count') else ""
        label = f"{star_prefix}{badge} {ev['title']}{cat_badge}{stream_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', '')) if autoplay else manual_url

        item = xbmcgui.ListItem(label=label)
        if autoplay:
            item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(
            item,
            title=ev['title'],
            genre=ev.get('category_name', ''),
            plot=f"Sport: {ev.get('category_name', '')}\nStatus: {ev.get('time_text', 'LIVE NOW')}\nAvailable Streams: {ev.get('stream_count', 0)}"
        )

        item_art = art.get_art_dict(ev.get('category_id') or 'live_now')
        if ev.get('icon'):
            item_art['icon'] = ev['icon']
            item_art['thumb'] = ev['icon']
        if ev.get('fanart'):
            item_art['fanart'] = ev['fanart']
        item.setArt(item_art)

        switch_url = build_url(base_url, action='quick_switch')
        context_items = [
            ("Select Server Manually...", f"Container.Update({manual_url})"),
            ("⚡ Quick Game Switcher...", f"RunPlugin({switch_url})")
        ]

        if matched_fav:
            rem_url = build_url(base_url, action='remove_fav', team=matched_fav)
            context_items.append((f"❌ Remove '{matched_fav}' from Favorites", f"RunPlugin({rem_url})"))
        else:
            teams = ev.get('teams', [])
            if teams:
                for t in teams[:2]:
                    if t:
                        add_url = build_url(base_url, action='add_fav', team=t)
                        context_items.append((f"⭐ Add '{t}' to Favorites", f"RunPlugin({add_url})"))
            else:
                add_url = build_url(base_url, action='add_fav', team=ev['title'])
                context_items.append(("⭐ Add to Favorite Teams", f"RunPlugin({add_url})"))

        item.addContextMenuItems(context_items)
        xbmcplugin.addDirectoryItem(handle, click_url, item, isFolder=not autoplay, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_sub_leagues(base_url, handle, scraper, cat_id, cat_name, settings):
    """Displays sub-leagues/competitions for a sport category (e.g. NFL/CFB, EPL/UCL, F1/NASCAR)."""
    xbmcplugin.setContent(handle, 'videos')
    categories = scraper.get_categories()
    cat_data = next((c for c in categories if c['id'] == cat_id), None)
    sub_leagues = cat_data.get('sub_leagues', []) if cat_data else []

    if not sub_leagues:
        show_events(base_url, handle, scraper, cat_id, cat_name, settings)
        return

    for sub in sub_leagues:
        url = build_url(base_url, action='category', cat_id=cat_id, cat_name=sub['name'], filter_league=sub['id'])
        item = xbmcgui.ListItem(label=sub['name'])
        item.setContentLookup(False)
        set_video_metadata(item, title=sub['name'], plot=f"Browse live and upcoming matches for {sub['name']}")
        item.setArt(art.get_art_dict(sub['id']))
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_quick_switcher(base_url, scraper, settings):
    """In-playback or in-menu quick switcher modal to jump directly to any active live match."""
    if not KODI_ENV:
        return
    try:
        live_events = scraper.get_live_now_events()
    except Exception:
        live_events = []
    if not live_events:
        try:
            live_events = [ev for ev in scraper.get_live_events('all') if ev.get('is_live')]
        except Exception:
            live_events = []

    if not live_events:
        xbmcgui.Dialog().notification('Quick Switch', 'No live games currently playing', xbmcgui.NOTIFICATION_INFO, 2500)
        return

    labels = []
    for ev in live_events:
        cat = f"[{ev.get('category_name', 'Live')}]" if ev.get('category_name') else ""
        labels.append(f"🔴 {ev['title']}  {cat}")

    dialog = xbmcgui.Dialog()
    sel = dialog.select("⚡ Quick Switch: Jump to Live Game", labels)
    if sel >= 0:
        ev = live_events[sel]
        url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        xbmc.executebuiltin(f"PlayMedia({url})")


def populate_zapping_playlist(base_url, current_match_url, scraper):
    """Queues live matches into Kodi video playlist so remote Next/Prev buttons cycle live games."""
    if not KODI_ENV:
        return
    try:
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        live_events = scraper.get_live_now_events()
        if not live_events:
            live_events = [ev for ev in scraper.get_live_events('all') if ev.get('is_live')]
        other_events = [ev for ev in live_events if ev.get('url') != current_match_url]
        for ev in other_events[:10]:
            zap_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
            item = xbmcgui.ListItem(label=ev['title'])
            item.setPath(zap_url)
            item.setProperty('IsPlayable', 'true')
            set_video_metadata(item, title=ev['title'], genre=ev.get('category_name', ''))
            item.setArt(art.get_art_dict(ev.get('category_id', 'live_now')))
            playlist.add(url=zap_url, listitem=item)
    except Exception:
        pass


def show_events(base_url, handle, scraper, cat_id, cat_name, settings, filter_team=None, filter_league=None):
    """Lists live matches for the selected sport category with Auto-Play, Favorites, and Live Status ordering."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        events = scraper.get_live_events(category_id=cat_id, filter_league=filter_league)
    except Exception as e:
        err_msg = str(e)
        xbmcgui.Dialog().notification('Sportsurge', f"Error: {err_msg[:60]}", xbmcgui.NOTIFICATION_ERROR, 4000)
        events = []

    fav_mgr = FavoritesManager()
    hide_finished = settings.get('hide_finished_events', False)

    # Filter events if specific team was requested
    if filter_team:
        events = [ev for ev in events if filter_team.lower() in ev.get('title', '').lower() or any(filter_team.lower() in t.lower() for t in ev.get('teams', []))]

    filtered_events = []
    for ev in events:
        badge, status = format_status_badge(ev)
        if hide_finished and status == 'done':
            continue
        ev['_badge'] = badge
        ev['_status'] = status
        filtered_events.append(ev)

    if not filtered_events:
        empty_item = xbmcgui.ListItem(label="No live matches currently available")
        empty_item.setContentLookup(False)
        empty_item.setArt(art.get_art_dict(filter_league or cat_id))
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    # Sort matches: Favorites + Live first, then upcoming by start time, then completed
    def event_sort_key(ev):
        status = ev.get('_status', 'unknown')
        matched_fav = fav_mgr.is_favorite_match(ev)
        fav_boost = 10 if matched_fav else 0
        status_rank = 3 if status == 'live' else (2 if status == 'soon' else (0 if status == 'done' else 1))
        # Negative start_ts for chronological order
        ts = ev.get('start_timestamp') or 0
        return (fav_boost + status_rank, -ts if status == 'live' else ts)

    filtered_events.sort(key=event_sort_key, reverse=True)

    if not filtered_events:
        empty_item = xbmcgui.ListItem(label="No live matches currently available")
        empty_item.setContentLookup(False)
        empty_item.setArt(art.get_art_dict(filter_league or cat_id))
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(filtered_events)
    autoplay = settings.get('autoplay_stream', True)

    for ev in filtered_events:
        matched_fav = fav_mgr.is_favorite_match(ev)
        star_prefix = "[B][COLOR gold]★[/COLOR][/B] " if matched_fav else ""

        badge = ev.get('_badge', '')
        status_tag = f"  {badge}" if badge else ""
        stream_tag = f"  [COLOR gray]({ev['stream_count']} streams)[/COLOR]" if ev.get('stream_count') else ""
        label = f"{star_prefix}{ev['title']}{status_tag}{stream_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        if autoplay:
            click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        else:
            click_url = manual_url

        listitem = xbmcgui.ListItem(label=label)
        if autoplay:
            listitem.setProperty('IsPlayable', 'true')
        listitem.setContentLookup(False)
        set_video_metadata(
            listitem,
            title=ev['title'],
            genre=ev.get('category_name', ''),
            plot=f"Category: {ev.get('category_name', '')}\nStatus: {ev.get('time_text', '')}\nAvailable Streams: {ev.get('stream_count', 0)}\n[B]Tip:[/B] Context Menu > 'Select Server Manually' to choose provider."
        )

        item_art = art.get_art_dict(filter_league or ev.get('category_id') or cat_id)
        if ev.get('icon'):
            item_art['icon'] = ev['icon']
            item_art['thumb'] = ev['icon']
        if ev.get('fanart'):
            item_art['fanart'] = ev['fanart']
        listitem.setArt(item_art)

        # Context menu items
        switch_url = build_url(base_url, action='quick_switch')
        context_items = [
            ("Select Server Manually...", f"Container.Update({manual_url})"),
            ("⚡ Quick Game Switcher...", f"RunPlugin({switch_url})")
        ]

        if matched_fav:
            rem_url = build_url(base_url, action='remove_fav', team=matched_fav)
            context_items.append((f"❌ Remove '{matched_fav}' from Favorites", f"RunPlugin({rem_url})"))
        else:
            teams = ev.get('teams', [])
            if teams:
                for t in teams[:2]:
                    if t:
                        add_url = build_url(base_url, action='add_fav', team=t)
                        context_items.append((f"⭐ Add '{t}' to Favorites", f"RunPlugin({add_url})"))
            else:
                add_url = build_url(base_url, action='add_fav', team=ev['title'])
                context_items.append(("⭐ Add to Favorite Teams", f"RunPlugin({add_url})"))

        listitem.addContextMenuItems(context_items)
        xbmcplugin.addDirectoryItem(handle, click_url, listitem, isFolder=not autoplay, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def handle_match_autoplay(base_url, handle, scraper, match_url, match_title, icon, settings):
    """
    Smart Auto-Play with Live Stream Verification, Preferred Host Scoring, and Failover:
    Probes servers with an HTTP Range/HEAD live health check, prioritizes user's preferred host,
    skips dead feeds, and seamlessly launches the best responding 1080p/720p stream.
    """
    # 1. One-time prompt for Preferred Host if not configured yet
    if KODI_ENV and not settings.get('preferred_host_prompted', False):
        dialog = xbmcgui.Dialog()
        host_options = [
            "⭐ Auto / Best Quality (1080p 60fps)",
            "🔥 StreamEast HD (1080p 60fps Multi-Source)",
            "⚡ Sportsurge Top Providers (Nexa / SportHD / Crack)",
            "📺 TV & League Networks (ESPN / Sky / NBC / TSN)",
            "🌐 Embedme / Web Players"
        ]
        sel_idx = dialog.select("Select Preferred Stream Host for Auto-Play", host_options)
        if sel_idx < 0:
            sel_idx = 0  # Default to Auto if dismissed
        
        addon = xbmcaddon.Addon()
        addon.setSetting('preferred_host', str(sel_idx))
        addon.setSetting('preferred_host_prompted', 'true')
        settings['preferred_host'] = sel_idx
        settings['preferred_host_prompted'] = True

    try:
        streams = scraper.get_match_streams(match_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Sportsurge', f"Error fetching streams: {e}", xbmcgui.NOTIFICATION_ERROR)
        streams = []

    if not streams:
        xbmcgui.Dialog().notification('Sportsurge', 'No active stream servers found', xbmcgui.NOTIFICATION_WARNING)
        return

    pref_host = int(settings.get('preferred_host', 0))

    # Sort streams by preferred host preference + quality: 1080p > 720p, Gold > Silver > Bronze
    def sort_key(s):
        score = 0
        site = (s.get('site_name', '') + ' ' + s.get('title', '')).lower()

        # Preferred host bonus (+50 points to guarantee top candidate order)
        if pref_host == 1:  # StreamEast HD
            if 'streameast' in site:
                score += 50
        elif pref_host == 2:  # Sportsurge Top Providers
            if any(h in site for h in ['nexa', 'sporthd', 'crack', 'bila', 'markky', 'buff', 'weak', 'topstream', 'meth', 'strikeout', 'viprow']):
                score += 50
        elif pref_host == 3:  # TV & League Networks
            if any(h in site for h in ['espn', 'sky', 'tnt', 'nbc', 'tsn', 'cbs', 'dazn', 'fox', 'abc', 'league', 'network', 'bt sport', 'premier']):
                score += 50
        elif pref_host == 4:  # Embedme / Web Players
            if 'embed' in site:
                score += 50

        if '1080' in s.get('resolution', ''): score += 10
        if '60fps' in s.get('fps', ''): score += 5
        if s.get('tier') in ('HD', 'Gold'): score += 10
        return score

    sorted_streams = sorted(streams, key=sort_key, reverse=True)
    probe_timeout = settings.get('autoplay_timeout', 4)

    resolver = StreamResolver(
        user_agent=settings['custom_user_agent'],
        timeout=probe_timeout,
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url']
    )

    xbmcgui.Dialog().notification('Sportsurge Auto-Play', f"Testing streams for: {match_title[:28]}...", icon or xbmcgui.NOTIFICATION_INFO, 2500)

    candidates = sorted_streams[:8]
    verified_streams = []

    for idx, s in enumerate(candidates):
        res_url, headers = resolver.resolve(s['url'])
        if res_url and ('.m3u8' in res_url or '.mpd' in res_url):
            # Stream health check: ensure it actually returns HTTP 200 / #EXTM3U
            is_alive = resolver.verify_stream_live(res_url, headers=headers, timeout=2.0)
            if is_alive:
                verified_streams.append({
                    'url': res_url,
                    'headers': headers,
                    'site_name': s['site_name']
                })
                # Top quality working stream confirmed, launch immediately!
                break

    player = SportsurgePlayer(
        handle=handle,
        user_agent=settings['custom_user_agent'],
        timeout=settings['timeout'],
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url']
    )

    if verified_streams:
        primary = verified_streams[0]
        xbmcgui.Dialog().notification('Sportsurge', f"Auto-Playing: {primary['site_name']}", icon or xbmcgui.NOTIFICATION_INFO, 2000)

        # Queue other live games for seamless remote Next/Prev zapping
        populate_zapping_playlist(base_url, match_url, scraper)

        success = player.play_resolved(
            primary['url'],
            headers=primary['headers'],
            title=f"{match_title} ({primary['site_name']})",
            icon=icon,
            referer=match_url
        )

        # If primary stream failed during Kodi player handoff, trigger instant failover to backup
        if not success and len(verified_streams) > 1:
            backup = verified_streams[1]
            xbmcgui.Dialog().notification('Sportsurge', f"Server 1 dropped. Switching to {backup['site_name']}...", icon or xbmcgui.NOTIFICATION_WARNING, 3000)
            player.play_resolved(
                backup['url'],
                headers=backup['headers'],
                title=f"{match_title} ({backup['site_name']})",
                icon=icon,
                referer=match_url
            )
    else:
        # Fall back to manual server selection if no stream passed probe
        xbmcgui.Dialog().notification('Sportsurge', 'No stream passed health check. Showing server list.', xbmcgui.NOTIFICATION_INFO, 2500)
        show_streams(base_url, handle, scraper, match_url, match_title, icon)


def show_streams(base_url, handle, scraper, match_url, match_title, icon):
    """Lists all available stream links for a specific match."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        streams = scraper.get_match_streams(match_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Sportsurge', f"Error fetching streams: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        streams = []

    if not streams:
        empty_item = xbmcgui.ListItem(label="No streams found for this match")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(streams)
    for s in streams:
        url = build_url(
            base_url,
            action='play',
            stream_url=s['url'],
            title=f"{match_title} - {s['site_name']}",
            icon=icon,
            referer=match_url
        )

        tier = s.get('tier', '')
        res = s.get('resolution', '')
        fps = s.get('fps', '')
        ads = s.get('ads', '')
        lang = s.get('language', '')

        tier_color = 'gold' if tier == 'Gold' else ('silver' if tier == 'Silver' else 'lightblue')
        tier_tag = f"[COLOR {tier_color}][{tier}][/COLOR] " if tier else ""
        res_tag = f"[B]{res}[/B]" if res else "HD"
        fps_tag = f" {fps}" if fps and '60' in fps else ""
        ads_tag = f" | [COLOR green]{ads}[/COLOR]" if ads else ""
        lang_tag = f" | {lang}" if lang and lang != 'EN' else ""

        label = f"{tier_tag}{s['site_name']} - {res_tag}{fps_tag}{ads_tag}{lang_tag}"

        listitem = xbmcgui.ListItem(label=label)
        listitem.setProperty('IsPlayable', 'true')
        listitem.setContentLookup(False)
        set_video_metadata(
            listitem,
            title=f"{match_title} - {s['site_name']}",
            plot=f"Provider: {s['site_name']}\nQuality: {res} {fps}\nLanguage: {lang}\nAds: {ads}"
        )

        if icon:
            listitem.setArt({'icon': icon, 'thumb': icon})

        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_favorites_menu(base_url, handle, scraper):
    """Displays the Favorites top-level menu."""
    xbmcplugin.setContent(handle, 'videos')
    fav_mgr = FavoritesManager()
    favs = fav_mgr.get_favorites()

    # 1. View All Favorite Games
    all_url = build_url(base_url, action='favorites_all')
    all_item = xbmcgui.ListItem(label="⭐ View All Matches for Favorited Teams")
    all_item.setContentLookup(False)
    set_video_metadata(all_item, title="All Favorite Matches", plot="Shows all live and upcoming games involving any of your saved favorite teams.")
    all_item.setArt(art.get_art_dict('favorites'))
    xbmcplugin.addDirectoryItem(handle, all_url, all_item, isFolder=True)

    # 2. List each team individually
    for team in favs:
        team_url = build_url(base_url, action='favorites_team', team=team)
        item = xbmcgui.ListItem(label=f"★ {team}")
        item.setContentLookup(False)
        set_video_metadata(item, title=team, plot=f"View upcoming and live games for {team}")
        item.setArt(art.get_art_dict('favorites'))

        rem_url = build_url(base_url, action='remove_fav', team=team)
        item.addContextMenuItems([
            (f"❌ Remove '{team}' from Favorites", f"RunPlugin({rem_url})")
        ])
        xbmcplugin.addDirectoryItem(handle, team_url, item, isFolder=True)

    # 3. Add Team Manually
    add_url = build_url(base_url, action='add_fav_prompt')
    add_item = xbmcgui.ListItem(label="➕ Add New Team to Favorites...")
    add_item.setContentLookup(False)
    set_video_metadata(add_item, title="Add Team", plot="Type the name of any sports team or athlete to add to favorites.")
    add_item.setArt(art.get_art_dict('favorites'))
    xbmcplugin.addDirectoryItem(handle, add_url, add_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_all_favorite_events(base_url, handle, scraper, settings):
    """Lists all upcoming & live events for all favorited teams."""
    fav_mgr = FavoritesManager()
    favs = fav_mgr.get_favorites()

    if not favs:
        empty_item = xbmcgui.ListItem(label="No favorite teams added yet. Right-click any match to bookmark your team!")
        empty_item.setContentLookup(False)
        empty_item.setArt(art.get_art_dict('favorites'))
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    xbmcplugin.setContent(handle, 'videos')
    try:
        events = scraper.get_live_events('all')
    except Exception:
        events = []

    matched = []
    for ev in events:
        if fav_mgr.is_favorite_match(ev):
            matched.append(ev)

    if not matched:
        empty_item = xbmcgui.ListItem(label="No upcoming or live matches found for your favorite teams.")
        empty_item.setContentLookup(False)
        empty_item.setArt(art.get_art_dict('favorites'))
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    # Reuse show_events rendering
    autoplay = settings.get('autoplay_stream', True)
    for ev in matched:
        badge, _ = format_status_badge(ev.get('time_text', ''))
        status_tag = f"  {badge}" if badge else ""
        label = f"[B][COLOR gold]★[/COLOR][/B] {ev['title']}{status_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', '')) if autoplay else manual_url

        item = xbmcgui.ListItem(label=label)
        if autoplay:
            item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ev['title'], genre=ev.get('category_name', ''), plot=f"Category: {ev.get('category_name', '')}")
        item.setArt(art.get_art_dict(ev.get('category_id') or 'favorites'))
        item.addContextMenuItems([("Select Server Manually...", f"Container.Update({manual_url})")])
        xbmcplugin.addDirectoryItem(handle, click_url, item, isFolder=not autoplay, totalItems=len(matched))

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def handle_search(base_url, handle, scraper, settings):
    """Prompts for search query and displays matching live events & channels."""
    dialog = xbmcgui.Dialog()
    query = dialog.input("Search Sportsurge (e.g. Chiefs, Arsenal, F1, ESPN)...")
    if not query:
        return

    q_lower = query.lower().strip()
    xbmcplugin.setContent(handle, 'videos')

    # 1. Search live events
    try:
        events = scraper.get_live_events('all')
    except Exception:
        events = []

    matched_events = [
        ev for ev in events
        if q_lower in ev.get('title', '').lower()
        or any(q_lower in t.lower() for t in ev.get('teams', []))
        or q_lower in ev.get('category_name', '').lower()
    ]

    # 2. Search 24/7 channels
    channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
    all_channels = channels_mgr.get_all_channels()
    matched_channels = [
        ch for ch in all_channels.values()
        if q_lower in ch['name'].lower()
    ]

    total_results = len(matched_events) + len(matched_channels)
    if total_results == 0:
        empty_item = xbmcgui.ListItem(label=f"No results found for '{query}'")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    autoplay = settings.get('autoplay_stream', True)

    # Render channels first
    for ch in matched_channels:
        ch_url = build_url(
            base_url,
            action='play_channel',
            ch_name=ch['name'],
            ch_links=json.dumps(ch['links']),
            icon=ch.get('icon', '')
        )
        item = xbmcgui.ListItem(label=f"📺 [B]{ch['name']}[/B] [COLOR gold](Live Channel)[/COLOR]")
        item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ch['name'], plot="24/7 Live Sports Channel")
        if ch.get('icon'):
            item.setArt({'icon': ch['icon'], 'thumb': ch['icon']})
        xbmcplugin.addDirectoryItem(handle, ch_url, item, isFolder=False, totalItems=total_results)

    # Render events
    for ev in matched_events:
        badge, _ = format_status_badge(ev.get('time_text', ''))
        status_tag = f"  {badge}" if badge else ""
        label = f"🔴 {ev['title']}{status_tag}"

        manual_url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', ''))
        click_url = build_url(base_url, action='match_autoplay', match_url=ev['url'], match_title=ev['title'], icon=ev.get('icon', '')) if autoplay else manual_url

        item = xbmcgui.ListItem(label=label)
        if autoplay:
            item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ev['title'], genre=ev.get('category_name', ''), plot=f"Category: {ev.get('category_name', '')}")
        item.addContextMenuItems([("Select Server Manually...", f"Container.Update({manual_url})")])
        xbmcplugin.addDirectoryItem(handle, click_url, item, isFolder=not autoplay, totalItems=total_results)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_channels_groups(base_url, handle, channels_mgr):
    """Displays channel regional groups (US/CA, UK/EU, All A-Z)."""
    xbmcplugin.setContent(handle, 'videos')
    groups = channels_mgr.get_channel_groups()
    for g in groups:
        url = build_url(base_url, action='channels_list', group_id=g['id'], group_name=g['name'])
        item = xbmcgui.ListItem(label=g['name'])
        item.setContentLookup(False)
        set_video_metadata(item, title=g['name'], plot=f"Browse {g['name']}")
        item.setArt(art.get_art_dict('channels'))
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)

    # 4. Export M3U for IPTV Simple Client
    export_url = build_url(base_url, action='export_m3u')
    export_item = xbmcgui.ListItem(label="📋 Export Channels to IPTV Simple Client (.m3u)")
    export_item.setContentLookup(False)
    set_video_metadata(export_item, title="Export Channels to M3U", plot="Exports all 120+ live sports networks to an M3U playlist file for IPTV Simple Client / Live TV guide.")
    export_item.setArt(art.get_art_dict('channels'))
    xbmcplugin.addDirectoryItem(handle, export_url, export_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_channels_list(base_url, handle, channels_mgr, group_id):
    """Lists individual 24/7 channels for a specific group."""
    xbmcplugin.setContent(handle, 'videos')
    channels = channels_mgr.get_channels_by_group(group_id)

    if not channels:
        empty_item = xbmcgui.ListItem(label="No channels available at this time")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(channels)
    for ch in channels:
        ch_links_json = json.dumps(ch['links'])
        url = build_url(
            base_url,
            action='play_channel',
            ch_name=ch['name'],
            ch_links=ch_links_json,
            icon=ch.get('icon', '')
        )
        lang_tag = f" [{ch['language']}]" if ch.get('language') else ""
        mirror_tag = f" ({len(ch['links'])} mirrors)" if len(ch['links']) > 1 else ""
        label = f"{ch['name']}{lang_tag}{mirror_tag}"

        item = xbmcgui.ListItem(label=label)
        item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=ch['name'], plot=f"24/7 Live Stream for {ch['name']}\nAvailable Mirrors: {len(ch['links'])}")

        if ch.get('icon'):
            item.setArt({'icon': ch['icon'], 'thumb': ch['icon']})

        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def play_channel(base_url, handle, ch_name, ch_links_json, icon, settings):
    """Plays a 24/7 channel with automatic mirror failover."""
    try:
        links = json.loads(ch_links_json)
    except Exception:
        links = []

    if not links:
        xbmcgui.Dialog().notification('Sportsurge', 'No stream links found for channel', xbmcgui.NOTIFICATION_WARNING)
        return

    resolver = StreamResolver(user_agent=settings['custom_user_agent'], timeout=settings['timeout'], use_proxy=settings['use_proxy'], proxy_url=settings['proxy_url'])
    p_dialog = xbmcgui.DialogProgress()
    p_dialog.create("Sportsurge Channels", f"Connecting to {ch_name}...")

    resolved_url = None
    final_headers = None

    for idx, lnk in enumerate(links):
        if p_dialog.iscanceled():
            break
        p_dialog.update(int(((idx + 1) / len(links)) * 100), f"Connecting to mirror {idx + 1}/{len(links)}...")
        res_url, headers = resolver.resolve(lnk)
        if res_url and ('.m3u8' in res_url or '.mpd' in res_url):
            if resolver.verify_stream_live(res_url, headers=headers, timeout=2.0):
                resolved_url = res_url
                final_headers = headers
                break

    p_dialog.close()

    if resolved_url:
        player = SportsurgePlayer(handle=handle, user_agent=settings['custom_user_agent'], timeout=settings['timeout'], use_proxy=settings['use_proxy'], proxy_url=settings['proxy_url'])
        player.play_resolved(resolved_url, headers=final_headers, title=ch_name, icon=icon)
    else:
        xbmcgui.Dialog().notification('Sportsurge', f"All mirrors offline for {ch_name}", xbmcgui.NOTIFICATION_ERROR)


def show_tivimate_menu(base_url, handle):
    """Displays TiviMate integration menu with remote control guide and M3U tools."""
    xbmcplugin.setContent(handle, 'videos')

    # 1. Remote Control Setup Guide
    guide_url = build_url(base_url, action='tivimate_guide')
    item1 = xbmcgui.ListItem(label="🚀 TiviMate Multi-View Remote Control Guide")
    item1.setContentLookup(False)
    set_video_metadata(item1, title="Remote Control Guide", plot="Step-by-step instructions for 2-screen, 3-screen, and 4-screen quad-box multi-game watching.")
    item1.setArt(art.get_art_dict('about_dev'))
    xbmcplugin.addDirectoryItem(handle, guide_url, item1, isFolder=False)

    # 2. View Playlist URLs
    urls_url = build_url(base_url, action='tivimate_urls')
    item2 = xbmcgui.ListItem(label="📋 View M3U Playlist URLs & LAN Address")
    item2.setContentLookup(False)
    set_video_metadata(item2, title="View Playlist URLs", plot="Display local loopback, LAN network IP, and GitHub Pages playlist links.")
    item2.setArt(art.get_art_dict('channels'))
    xbmcplugin.addDirectoryItem(handle, urls_url, item2, isFolder=False)

    # 3. Export M3U Playlist to Storage
    export_url = build_url(base_url, action='tivimate_export')
    item3 = xbmcgui.ListItem(label="📥 Export M3U Playlist to Firestick Storage (/sdcard/Download/)")
    item3.setContentLookup(False)
    set_video_metadata(item3, title="Export M3U to Storage", plot="Saves sportsurge_tivimate.m3u directly into your Downloads folder for 1-click import in TiviMate.")
    item3.setArt(art.get_art_dict('optimizer'))
    xbmcplugin.addDirectoryItem(handle, export_url, item3, isFolder=False)

    # 4. Server Status & Diagnostics
    diag_url = build_url(base_url, action='tivimate_diagnostics')
    item4 = xbmcgui.ListItem(label="🔄 IPTV Proxy Server Status & Health Check")
    item4.setContentLookup(False)
    set_video_metadata(item4, title="Server Health Check", plot="Verify that the local Kodi IPTV Proxy Server is active and streams are resolving.")
    item4.setArt(art.get_art_dict('patch_notes'))
    xbmcplugin.addDirectoryItem(handle, diag_url, item4, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_tivimate_guide():
    """Displays comprehensive interactive Multi-View setup guide for Firestick / Android TV remote controls."""
    guide_text = (
        "[B][COLOR skyblue]TiviMate Multi-View & Split-Screen Master Guide[/COLOR][/B]\n\n"
        "[B]1. Add the Sportsurge Playlist to TiviMate:[/B]\n"
        "• Open TiviMate on your Firestick / Android TV.\n"
        "• Go to [B]Settings[/B] > [B]Playlists[/B] > [B]Add playlist[/B] > [B]M3U playlist[/B].\n"
        "• Enter either:\n"
        "   - URL: [COLOR lime]http://127.0.0.1:8899/playlist.m3u[/COLOR]\n"
        "   - Or select local file: [COLOR yellow]/sdcard/Download/sportsurge_tivimate.m3u[/COLOR]\n"
        "• Click [B]Done[/B]. 140+ sports networks and active games will load instantly!\n\n"
        "[B]2. Launch Multi-View (Split-Screen / Quad-Box):[/B]\n"
        "• Select any game or sports channel and play it in full screen.\n"
        "• [B]Press and hold (long-press) the Select / OK button[/B] on your Fire TV remote.\n"
        "• From the bottom control bar that pops up, click the [B]Multi-View[/B] grid icon (4 squares).\n"
        "• Click [B]Add Screen[/B] to choose your 2nd, 3rd, or 4th simultaneous game!\n\n"
        "[B]3. 1-Click Audio Switching & Controls:[/B]\n"
        "• [B]Directional Arrows (Up/Down/Left/Right)[/B]: Moves the blue focus box to switch active game audio immediately.\n"
        "• [B]Select / OK Button[/B]: Zooms the highlighted game into full screen.\n"
        "• [B]Long-press OK[/B]: Opens individual screen controls (Change channel, Mute, or Close screen).\n"
        "• [B]Long-press Back[/B]: Exits Multi-View back to single-screen."
    )
    xbmcgui.Dialog().textviewer("TiviMate Multi-View Guide", guide_text)


def show_tivimate_urls():
    """Displays local and network streaming URLs for TiviMate."""
    local_ip = iptv_server.get_local_ip()
    port = iptv_server.get_server_port()
    is_running = iptv_server.is_server_running()
    status_str = "[COLOR lime]ONLINE (Active)[/COLOR]" if is_running else "[COLOR red]OFFLINE[/COLOR]"

    urls_text = (
        f"[B]Sportsurge IPTV Proxy Server Status:[/B] {status_str}\n\n"
        f"[B]1. Same-Device Loopback (Recommended for Firestick):[/B]\n"
        f"[COLOR lime]http://127.0.0.1:{port}/playlist.m3u[/COLOR]\n"
        f"• Use this if TiviMate and Kodi are on the SAME Firestick.\n\n"
        f"[B]2. Local Home Network (LAN Sharing):[/B]\n"
        f"[COLOR skyblue]http://{local_ip}:{port}/playlist.m3u[/COLOR]\n"
        f"• Use this to stream from another TV, iPad, tablet, or phone on your Wi-Fi.\n\n"
        f"[B]3. Cloud Standalone Playlist (Direct FAST Channels):[/B]\n"
        f"[COLOR yellow]https://jay181020.github.io/repository.sportsurge/sportsurge.m3u[/COLOR]\n"
        f"• Direct HLS sports channels accessible anywhere without Kodi running."
    )
    xbmcgui.Dialog().textviewer("TiviMate Playlist URLs", urls_text)


def export_tivimate_m3u():
    """Exports M3U playlist directly to Firestick internal storage."""
    was_running = iptv_server.is_server_running()
    if not was_running:
        iptv_server.start_iptv_server()

    export_paths = []
    # 1. Android Downloads folder
    android_download = '/sdcard/Download/sportsurge_tivimate.m3u'
    try:
        os.makedirs('/sdcard/Download', exist_ok=True)
        export_paths.append(android_download)
    except Exception:
        pass

    # 2. Kodi userdata playlists
    try:
        ud_path = xbmcvfs.translatePath('special://userdata/playlists/sportsurge_tivimate.m3u')
        export_paths.append(ud_path)
    except Exception:
        pass

    # 3. Kodi home
    try:
        home_path = xbmcvfs.translatePath('special://home/sportsurge_tivimate.m3u')
        export_paths.append(home_path)
    except Exception:
        pass

    total_exported = 0
    saved_locations = []
    for p in export_paths:
        succ, count, err = iptv_server.export_m3u_file(p)
        if succ:
            total_exported = count
            saved_locations.append(p)

    if saved_locations:
        loc_display = "\n• ".join(saved_locations)
        msg = (
            f"Successfully exported {total_exported} sports channels and active games!\n\n"
            f"Saved to:\n• {loc_display}\n\n"
            "In TiviMate, go to Add Playlist > M3U playlist > Select local file, and pick this file."
        )
        xbmcgui.Dialog().ok("Export Successful", msg)
    else:
        xbmcgui.Dialog().notification("Sportsurge", "Failed to export M3U playlist", xbmcgui.NOTIFICATION_ERROR, 3500)


def show_tivimate_diagnostics():
    """Checks server responsiveness and stream resolution health."""
    is_running = iptv_server.is_server_running()
    port = iptv_server.get_server_port()
    local_ip = iptv_server.get_local_ip()

    if not is_running:
        ok, res = iptv_server.start_iptv_server(port=port)
        is_running = ok

    status = "Active & Ready" if is_running else "Failed to start"
    dialog_text = (
        f"[B]Server Status:[/B] {status}\n"
        f"[B]Server Port:[/B] {port}\n"
        f"[B]Local Device IP:[/B] {local_ip}\n"
        f"[B]Loopback URL:[/B] http://127.0.0.1:{port}/playlist.m3u\n"
        f"[B]Multi-Threading:[/B] Enabled (ExoPlayer Multi-View Quad-Stream)\n"
        f"[B]Anti-403 Chunk Relayer:[/B] Active (Referer & User-Agent Auto-Injection)\n\n"
        "Your Kodi background IPTV engine is ready for 2-screen, 3-screen, and 4-screen multi-view playback in TiviMate!"
    )
    xbmcgui.Dialog().ok("IPTV Server Diagnostics", dialog_text)


def show_replays_menu(base_url, handle, replays_scraper):
    """Displays replay sports categories (F1, Premier League, UFC, NFL, NBA)."""
    xbmcplugin.setContent(handle, 'videos')
    categories = replays_scraper.get_categories()
    for cat in categories:
        url = build_url(base_url, action='replays_category', cat_id=cat['id'], cat_name=cat['name'])
        item = xbmcgui.ListItem(label=cat['name'])
        item.setContentLookup(False)
        set_video_metadata(item, title=cat['name'], plot=f"Browse {cat['name']}")
        item.setArt(art.get_art_dict(cat.get('id') or 'replays'))
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True)
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_replays_list(base_url, handle, replays_scraper, cat_id, cat_name):
    """Lists match replays available for category."""
    xbmcplugin.setContent(handle, 'videos')
    replays = replays_scraper.get_replays_for_category(cat_id)

    if not replays:
        empty_item = xbmcgui.ListItem(label=f"No replays found for {cat_name}")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(replays)
    for r in replays:
        url = build_url(base_url, action='replay_sources', article_url=r['url'], title=r['title'], icon=r.get('icon', ''))
        label = f"{r['title']} [COLOR lightblue]({r.get('date', '')})[/COLOR]" if r.get('date') else r['title']

        item = xbmcgui.ListItem(label=label)
        item.setContentLookup(False)
        set_video_metadata(item, title=r['title'], plot=f"Category: {r.get('category', '')}\nDate: {r.get('date', '')}")

        if r.get('icon'):
            item.setArt({'icon': r['icon'], 'thumb': r['icon']})

        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=True, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_replay_sources(base_url, handle, replays_scraper, article_url, title, icon):
    """Lists video download/stream sources for replay article."""
    xbmcplugin.setContent(handle, 'videos')
    sources = replays_scraper.get_replay_video_sources(article_url)

    if not sources:
        empty_item = xbmcgui.ListItem(label="No stream sources found for this replay")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(sources)
    for s in sources:
        url = build_url(base_url, action='play_replay', source_url=s['url'], title=f"{title} - {s['title']}", icon=icon)
        item = xbmcgui.ListItem(label=s['title'])
        item.setProperty('IsPlayable', 'true')
        item.setContentLookup(False)
        set_video_metadata(item, title=s['title'], plot=f"Hoster: {s['hoster']}\nURL: {s['url']}")
        if icon:
            item.setArt({'icon': icon, 'thumb': icon})
        xbmcplugin.addDirectoryItem(handle, url, item, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def play_replay(base_url, handle, source_url, title, icon, settings):
    """Resolves and plays replay via Debrid, ResolveURL, or direct link."""
    replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
    stream_url = replays_scraper.resolve_replay_stream(
        source_url,
        debrid_enabled=settings['enable_debrid'],
        debrid_service=settings['debrid_service'],
        rd_token=settings['rd_token'],
        ad_token=settings['ad_token']
    )

    if stream_url:
        player = SportsurgePlayer(handle=handle, user_agent=settings['custom_user_agent'], timeout=settings['timeout'], use_proxy=settings['use_proxy'], proxy_url=settings['proxy_url'])
        player.play_resolved(stream_url, title=title, icon=icon)
    else:
        xbmcgui.Dialog().notification('Sportsurge', 'Unable to resolve replay stream link', xbmcgui.NOTIFICATION_ERROR)


# ==========================================
# Main Router
# ==========================================

def router(argv):
    """Parses Kodi command line and routes to appropriate handler."""
    base_url = argv[0]
    handle = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else -1
    query = argv[2][1:] if len(argv) > 2 and argv[2].startswith('?') else ''
    params = dict(urllib.parse.parse_qsl(query))

    settings = get_settings()
    scraper = SportsurgeScraper(
        base_url=settings['base_url'],
        user_agent=settings['custom_user_agent'],
        cf_clearance=settings['cf_clearance'],
        use_flaresolverr=settings['use_flaresolverr'],
        flaresolverr_url=settings['flaresolverr_url'],
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url'],
        timeout=settings['timeout']
    )

    action = params.get('action')

    if not action or action == 'root':
        show_main_menu(base_url, handle, scraper, settings)
    elif action == 'live_now':
        show_live_now(base_url, handle, scraper, settings)
    elif action == 'sub_category':
        cat_id = params.get('cat_id', 'all')
        cat_name = params.get('cat_name', 'Live Sports')
        show_sub_leagues(base_url, handle, scraper, cat_id, cat_name, settings)
    elif action == 'optimize_buffer':
        optimizer.show_optimizer_dialog()
    elif action == 'quick_switch':
        show_quick_switcher(base_url, scraper, settings)
    elif action == 'patch_notes':
        if KODI_ENV:
            dialog = xbmcgui.Dialog()
            cur_v = updater.get_current_version()
            notes = PATCH_NOTES.get(cur_v, PATCH_NOTES.get('1.3.0', ''))
            dialog.ok(f"Sportsurge v{cur_v} - What's New & Hot-Fixes", notes)
    elif action == 'about_dev':
        if KODI_ENV:
            dialog = xbmcgui.Dialog()
            dialog.ok(WELCOME_TITLE, WELCOME_MESSAGE)
    elif action == 'category':
        cat_id = params.get('cat_id', 'all')
        cat_name = params.get('cat_name', 'Live Sports')
        filter_league = params.get('filter_league')
        show_events(base_url, handle, scraper, cat_id, cat_name, settings, filter_league=filter_league)
    elif action == 'match':
        match_url = params.get('match_url', '')
        match_title = params.get('match_title', 'Match Streams')
        icon = params.get('icon', '')
        show_streams(base_url, handle, scraper, match_url, match_title, icon)
    elif action == 'match_autoplay':
        match_url = params.get('match_url', '')
        match_title = params.get('match_title', 'Match Streams')
        icon = params.get('icon', '')
        handle_match_autoplay(base_url, handle, scraper, match_url, match_title, icon, settings)
    elif action == 'favorites_menu':
        show_favorites_menu(base_url, handle, scraper)
    elif action == 'favorites_all':
        show_all_favorite_events(base_url, handle, scraper, settings)
    elif action == 'favorites_team':
        team = params.get('team', '')
        show_events(base_url, handle, scraper, 'all', team, settings, filter_team=team)
    elif action == 'add_fav':
        team = params.get('team', '')
        fav_mgr = FavoritesManager()
        if fav_mgr.add_favorite(team):
            xbmcgui.Dialog().notification('Sportsurge', f"Added '{team}' to Favorite Teams ⭐", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'remove_fav':
        team = params.get('team', '')
        fav_mgr = FavoritesManager()
        if fav_mgr.remove_favorite(team):
            xbmcgui.Dialog().notification('Sportsurge', f"Removed '{team}' from Favorites", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'add_fav_prompt':
        dialog = xbmcgui.Dialog()
        team = dialog.input("Enter Team or Fighter Name:")
        if team:
            fav_mgr = FavoritesManager()
            fav_mgr.add_favorite(team)
            xbmcgui.Dialog().notification('Sportsurge', f"Added '{team}' to Favorites ⭐", xbmcgui.NOTIFICATION_INFO, 2500)
            xbmc.executebuiltin("Container.Refresh")
    elif action == 'search':
        handle_search(base_url, handle, scraper, settings)
    elif action == 'channels_groups':
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_channels_groups(base_url, handle, channels_mgr)
    elif action == 'channels_list':
        group_id = params.get('group_id', 'all')
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_channels_list(base_url, handle, channels_mgr, group_id)
    elif action == 'export_m3u':
        channels_mgr = SportsChannelsManager(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        playlists_dir = ''
        try:
            playlists_dir = xbmcvfs.translatePath('special://userdata/playlists')
        except Exception:
            try:
                playlists_dir = xbmc.translatePath('special://userdata/playlists')
            except Exception:
                pass
        if not playlists_dir:
            playlists_dir = os.path.join(os.path.expanduser('~'), 'AppData', 'Roaming', 'Kodi', 'userdata', 'playlists')
        os.makedirs(playlists_dir, exist_ok=True)
        m3u_path = os.path.join(playlists_dir, 'sportsurge_channels.m3u')
        count = channels_mgr.export_m3u_playlist(m3u_path)
        xbmcgui.Dialog().notification('Sportsurge', f"Exported {count} channels to IPTV playlist!", xbmcgui.NOTIFICATION_INFO, 4000)
    elif action == 'tivimate_menu':
        show_tivimate_menu(base_url, handle)
    elif action == 'tivimate_guide':
        show_tivimate_guide()
    elif action == 'tivimate_urls':
        show_tivimate_urls()
    elif action == 'tivimate_export':
        export_tivimate_m3u()
    elif action == 'tivimate_diagnostics':
        show_tivimate_diagnostics()
    elif action == 'play_channel':
        ch_name = params.get('ch_name', 'Live Channel')
        ch_links = params.get('ch_links', '[]')
        icon = params.get('icon', '')
        play_channel(base_url, handle, ch_name, ch_links, icon, settings)
    elif action == 'replays_menu':
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replays_menu(base_url, handle, replays_scraper)
    elif action == 'replays_category':
        cat_id = params.get('cat_id', 'f1')
        cat_name = params.get('cat_name', 'Replays')
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replays_list(base_url, handle, replays_scraper, cat_id, cat_name)
    elif action == 'replay_sources':
        article_url = params.get('article_url', '')
        title = params.get('title', 'Replay')
        icon = params.get('icon', '')
        replays_scraper = ReplaysScraper(user_agent=settings['custom_user_agent'], timeout=settings['timeout'])
        show_replay_sources(base_url, handle, replays_scraper, article_url, title, icon)
    elif action == 'play_replay':
        source_url = params.get('source_url', '')
        title = params.get('title', 'Replay Video')
        icon = params.get('icon', '')
        play_replay(base_url, handle, source_url, title, icon, settings)
    elif action == 'auth_rd':
        debrid.authorize_real_debrid()
    elif action == 'auth_ad':
        debrid.authorize_alldebrid()
    elif action == 'sync_debrid':
        debrid.sync_debrid_from_system()
    elif action == 'play':
        stream_url = params.get('stream_url', '')
        title = params.get('title', 'Live Stream')
        icon = params.get('icon', '')
        referer = params.get('referer', settings['base_url'])
        player = SportsurgePlayer(
            handle=handle,
            user_agent=settings['custom_user_agent'],
            timeout=settings['timeout'],
            use_proxy=settings['use_proxy'],
            proxy_url=settings['proxy_url']
        )
        player.play(stream_url, title=title, icon=icon, referer=referer)
    elif action == 'check_update':
        updater.check_and_apply_update(manual=True)
    elif action == 'settings':
        if KODI_ENV:
            xbmcaddon.Addon().openSettings()


if __name__ == '__main__':
    router(sys.argv)
