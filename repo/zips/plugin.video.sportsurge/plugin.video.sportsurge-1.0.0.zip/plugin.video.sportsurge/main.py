# -*- coding: utf-8 -*-
"""
Main Kodi entry point for Sportsurge add-on.
Routes incoming plugin URLs to categories, live events, streams, and playback.
"""

import os
import sys
import urllib.parse

# Ensure resources/lib is in python path
ADDON_DIR = os.path.dirname(os.path.abspath(__file__))
LIB_PATH = os.path.join(ADDON_DIR, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.insert(0, LIB_PATH)

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcaddon
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

from scraper import SportsurgeScraper
from player import SportsurgePlayer
import updater


def get_settings():
    """Retrieves user settings from Kodi or defaults."""
    if not KODI_ENV:
        return {
            'base_url': 'https://v2.sportsurge.net',
            'timeout': 10,
            'preferred_quality': 0,
            'use_flaresolverr': False,
            'flaresolverr_url': 'http://127.0.0.1:8191/v1',
            'custom_user_agent': '',
            'cf_clearance': '',
            'use_proxy': False,
            'proxy_url': '',
            'auto_update_check': True,
            'github_repo': 'Jay181020/plugin.video.sportsurge',
            'github_token': '',
        }

    addon = xbmcaddon.Addon()
    return {
        'base_url': addon.getSetting('base_url') or 'https://v2.sportsurge.net',
        'timeout': int(addon.getSetting('timeout') or 10),
        'preferred_quality': int(addon.getSetting('preferred_quality') or 0),
        'use_flaresolverr': addon.getSetting('use_flaresolverr') == 'true',
        'flaresolverr_url': addon.getSetting('flaresolverr_url') or 'http://127.0.0.1:8191/v1',
        'custom_user_agent': addon.getSetting('custom_user_agent') or '',
        'cf_clearance': addon.getSetting('cf_clearance') or '',
        'use_proxy': addon.getSetting('use_proxy') == 'true',
        'proxy_url': addon.getSetting('proxy_url') or '',
        'auto_update_check': addon.getSetting('auto_update_check') != 'false',
        'github_repo': addon.getSetting('github_repo') or 'Jay181020/plugin.video.sportsurge',
        'github_token': addon.getSetting('github_token') or '',
    }


def build_url(base, **params):
    """Builds plugin:// URL with trailing slash before query parameters."""
    clean_base = base.rstrip('/') + '/'
    return f"{clean_base}?{urllib.parse.urlencode(params)}"


def set_video_metadata(listitem, title, plot='', genre=''):
    """Sets video metadata using InfoTagVideo on Kodi 20+ with fallback."""
    if hasattr(listitem, 'getVideoInfoTag'):
        try:
            tag = listitem.getVideoInfoTag()
            tag.setTitle(title)
            if plot:
                tag.setPlot(plot)
            if genre:
                tag.setGenres([genre])
            return
        except Exception:
            pass
    listitem.setInfo('video', {'title': title, 'plot': plot, 'genre': genre})


def show_main_menu(base_url, handle, scraper):
    """Displays top-level categories in Kodi."""
    xbmcplugin.setContent(handle, 'videos')
    categories = scraper.get_categories()

    for cat in categories:
        url = build_url(base_url, action='category', cat_id=cat['id'], cat_name=cat['name'])
        listitem = xbmcgui.ListItem(label=cat['name'])
        listitem.setContentLookup(False)
        set_video_metadata(listitem, title=cat['name'], plot=f"Browse {cat['name']} live events")
        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=True)

    # Check for Updates item
    update_url = build_url(base_url, action='check_update')
    update_item = xbmcgui.ListItem(label="🔄 Check for Updates")
    update_item.setContentLookup(False)
    set_video_metadata(update_item, title='Check for Updates', plot='Check GitHub for newer releases and update automatically')
    xbmcplugin.addDirectoryItem(handle, update_url, update_item, isFolder=False)

    # Settings item
    settings_url = build_url(base_url, action='settings')
    settings_item = xbmcgui.ListItem(label="⚙️ Settings")
    settings_item.setContentLookup(False)
    set_video_metadata(settings_item, title='Settings', plot='Configure domain, FlareSolverr, proxy, and quality')
    xbmcplugin.addDirectoryItem(handle, settings_url, settings_item, isFolder=False)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_events(base_url, handle, scraper, cat_id, cat_name):
    """Lists live matches for the selected sport category."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        events = scraper.get_live_events(category_id=cat_id)
    except Exception as e:
        err_msg = str(e)
        if '10061' in err_msg or 'refused' in err_msg.lower():
            xbmcgui.Dialog().ok(
                'Sportsurge - Connection Refused (Win10061)',
                'FlareSolverr is turned ON, but is not running on 127.0.0.1:8191.\n\n'
                'Fix:\n'
                '1. If using FlareSolverr, start flaresolverr.exe first.\n'
                '2. Or go to Sportsurge Settings > Cloudflare & Solver and turn FlareSolverr OFF.\n'
                '3. Or configure a proxy in Sportsurge Settings > Proxy.'
            )
        elif '403' in err_msg or 'turnstile' in err_msg.lower():
            xbmcgui.Dialog().ok(
                'Sportsurge - Cloudflare 403 Challenge',
                'Sportsurge is currently protected by Cloudflare Turnstile.\n\n'
                'How to bypass:\n'
                '1. Use a proxy in Sportsurge Settings > Proxy.\n'
                '2. Run FlareSolverr on port 8191 and enable it in settings.\n'
                '3. Or paste your browser cf_clearance cookie into settings.'
            )
        else:
            xbmcgui.Dialog().notification('Sportsurge', f"Error: {err_msg[:60]}", xbmcgui.NOTIFICATION_ERROR, 4000)
        events = []

    if not events:
        empty_item = xbmcgui.ListItem(label="No live matches currently available")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(events)
    for ev in events:
        # Title formatting: Team 1 vs Team 2 [Status] (X Streams)
        status_tag = f" [{ev['time_text']}]" if ev['time_text'] else ""
        stream_tag = f" ({ev['stream_count']} streams)" if ev['stream_count'] else ""
        label = f"{ev['title']}{status_tag}{stream_tag}"

        url = build_url(base_url, action='match', match_url=ev['url'], match_title=ev['title'], icon=ev['icon'])

        listitem = xbmcgui.ListItem(label=label)
        listitem.setContentLookup(False)
        set_video_metadata(
            listitem,
            title=ev['title'],
            genre=ev['category_name'],
            plot=f"Category: {ev['category_name']}\nStatus: {ev['time_text']}\nAvailable Streams: {ev['stream_count']}"
        )

        art = {}
        if ev['icon']:
            art['icon'] = ev['icon']
            art['thumb'] = ev['icon']
        if ev['fanart']:
            art['fanart'] = ev['fanart']
        if art:
            listitem.setArt(art)

        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=True, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def show_streams(base_url, handle, scraper, match_url, match_title, icon):
    """Lists all available stream links for a specific match."""
    xbmcplugin.setContent(handle, 'videos')

    try:
        streams = scraper.get_match_streams(match_url)
    except Exception as e:
        xbmcgui.Dialog().notification('Sportsurge', f"Error fetching streams: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        streams = []

    if not streams:
        empty_item = xbmcgui.ListItem(label="No streams found for this match")
        empty_item.setContentLookup(False)
        xbmcplugin.addDirectoryItem(handle, '', empty_item, isFolder=False)
        xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)
        return

    total = len(streams)
    for s in streams:
        url = build_url(
            base_url,
            action='play',
            stream_url=s['url'],
            title=f"{match_title} - {s['site_name']}",
            icon=icon,
            referer=match_url
        )

        listitem = xbmcgui.ListItem(label=s['title'])
        listitem.setContentLookup(False)
        plot_desc = f"Site: {s['site_name']}\nQuality: {s['resolution']} {s['fps']}\nBitrate: {s['bitrate']}\nLanguage: {s['language']}\nAds: {s['ads']}"
        set_video_metadata(listitem, title=s['title'], plot=plot_desc)
        listitem.setProperty('IsPlayable', 'true')

        if icon:
            listitem.setArt({'icon': icon, 'thumb': icon})

        xbmcplugin.addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=total)

    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def router(argv):
    """Parses Kodi command line and routes to appropriate handler."""
    base_url = argv[0]
    handle = int(argv[1]) if len(argv) > 1 and argv[1].isdigit() else -1
    query = argv[2][1:] if len(argv) > 2 and argv[2].startswith('?') else ''
    params = dict(urllib.parse.parse_qsl(query))

    settings = get_settings()
    scraper = SportsurgeScraper(
        base_url=settings['base_url'],
        user_agent=settings['custom_user_agent'],
        cf_clearance=settings['cf_clearance'],
        use_flaresolverr=settings['use_flaresolverr'],
        flaresolverr_url=settings['flaresolverr_url'],
        use_proxy=settings['use_proxy'],
        proxy_url=settings['proxy_url'],
        timeout=settings['timeout']
    )

    action = params.get('action')

    if not action or action == 'root':
        show_main_menu(base_url, handle, scraper)
    elif action == 'category':
        cat_id = params.get('cat_id', 'all')
        cat_name = params.get('cat_name', 'Live Sports')
        show_events(base_url, handle, scraper, cat_id, cat_name)
    elif action == 'match':
        match_url = params.get('match_url', '')
        match_title = params.get('match_title', 'Match Streams')
        icon = params.get('icon', '')
        show_streams(base_url, handle, scraper, match_url, match_title, icon)
    elif action == 'play':
        stream_url = params.get('stream_url', '')
        title = params.get('title', 'Live Stream')
        icon = params.get('icon', '')
        referer = params.get('referer', settings['base_url'])
        player = SportsurgePlayer(
            handle=handle,
            user_agent=settings['custom_user_agent'],
            timeout=settings['timeout'],
            use_proxy=settings['use_proxy'],
            proxy_url=settings['proxy_url']
        )
        player.play(stream_url, title=title, icon=icon, referer=referer)
    elif action == 'check_update':
        updater.check_and_apply_update(manual=True)
    elif action == 'settings':
        if KODI_ENV:
            xbmcaddon.Addon().openSettings()


if __name__ == '__main__':
    router(sys.argv)
