# -*- coding: utf-8 -*-
"""
Favorites manager for Sportsurge.
Allows bookmarking favorite teams/fighters and filtering live events & replays.
Persists favorites in addon profile directory (favourite_teams.json).
"""

import os
import json

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False

FAVORITES_FILE = "favourite_teams.json"


def _get_storage_path():
    """Returns absolute path to favourite_teams.json."""
    if KODI_ENV:
        addon = xbmcaddon.Addon()
        profile_dir = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not os.path.exists(profile_dir):
            os.makedirs(profile_dir, exist_ok=True)
        return os.path.join(profile_dir, FAVORITES_FILE)
    
    # Fallback for desktop testing
    temp_dir = os.path.join(os.path.expanduser('~'), '.sportsurge')
    os.makedirs(temp_dir, exist_ok=True)
    return os.path.join(temp_dir, FAVORITES_FILE)


class FavoritesManager:
    def __init__(self):
        self.file_path = _get_storage_path()

    def get_favorites(self):
        """Returns list of favorite team/fighter strings."""
        if not os.path.exists(self.file_path):
            return []
        try:
            with open(self.file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return []

    def add_favorite(self, name):
        """Adds a team/fighter to favorites."""
        name = (name or '').strip()
        if not name:
            return False
        favs = self.get_favorites()
        if not any(f.lower() == name.lower() for f in favs):
            favs.append(name)
            self._save(favs)
            return True
        return False

    def remove_favorite(self, name):
        """Removes a team/fighter from favorites."""
        name = (name or '').strip().lower()
        favs = self.get_favorites()
        new_favs = [f for f in favs if f.lower() != name]
        if len(new_favs) != len(favs):
            self._save(new_favs)
            return True
        return False

    def is_favorite_match(self, match):
        """
        Checks if a match involves any favorited team.
        Returns the matched favorite name or None.
        """
        favs = self.get_favorites()
        if not favs:
            return None

        title = match.get('title', '').lower()
        teams = [t.lower() for t in match.get('teams', [])]

        for f in favs:
            f_lower = f.lower()
            if any(f_lower in t for t in teams) or f_lower in title:
                return f
        return None

    def _save(self, favs):
        try:
            with open(self.file_path, 'w', encoding='utf-8') as f:
                json.dump(favs, f, indent=2, ensure_ascii=False)
        except Exception as e:
            if KODI_ENV:
                xbmc.log(f"[Sportsurge Favorites] Save error: {e}", xbmc.LOGWARNING)
