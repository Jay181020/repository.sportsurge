# 🚀 Sportsurge Kodi Add-on - Feature Roadmap & Future Suggestions

This document records the curated list of future enhancement proposals and architectural improvements planned for upcoming releases.

---

## 📋 Backlog & Feature Ideas

### 1. 📊 Real-Time In-Game Scores & Game Clocks (ESPN API)
- **Concept**: Display live scores, active quarters/innings, and countdown timers directly next to match titles in Kodi menus.
- **Example**: `🔴 LIVE (Lions 24 - 21 Bills | 4th Qtr 2:15)`
- **Integration**: Free public ESPN scoreboard API (`site.api.espn.com/apis/site/v2/sports/...`) mapped via `data-espn-event-id`.

---

### 2. ⏰ Game Reminders & Auto-Tune (Context Menu)
- **Concept**: Set notification alarms for upcoming games with one-click automatic stream tuning.
- **Workflow**: Context menu $\rightarrow$ *"⏰ Set Game Reminder"*. Kodi pops up a 10-minute warning before kickoff and automatically tunes in upon confirmation.

---

### 3. 🎙️ Home vs. Away & International Broadcaster Badges
- **Concept**: Distinguish audio and video feed origins:
  - `[HOME - Lions Broadcast (1080p)]`
  - `[AWAY - Bills Broadcast (1080p)]`
  - `[SKY SPORTS UK (1080p 60fps)]`
  - `[TSN CANADA (1080p)]`
  - `[SPANISH COMMENTARY (1080p)]`
- **Settings**: Preference option to always prioritize Home vs. Away or specific regional feeds during Auto-Play.

---

### 4. 📺 Electronic Program Guide (EPG / XMLTV) for 24/7 Channels
- **Concept**: Pair with the existing one-click `.m3u` playlist export to generate an `epg.xml` timeline.
- **Benefit**: Provides IPTV Simple Client users with a full TV guide grid showing current and upcoming shows across ESPN, FS1, TNT, Sky Sports, etc.

---

### 5. 🛡️ Multi-Provider Redundancy (VIPRow + DaddyLiveHD Direct)
- **Concept**: Add secondary unblocked live sports scrapers (VIPRow, DaddyLiveHD) alongside Sportsurge and StreamEast.
- **Benefit**: Guarantees 100% uptime with zero buffering during massive pay-per-view events (UFC Main Cards, Super Bowl, Champions League Final).

---

### 6. 🤖 AI Match Insights & Odds (Sports AI Studio Integration)
- **Concept**: Embed AI win probabilities, point spreads, over/under totals, and team momentum stats inside the Kodi video info plot.
- **Example**: *"AI Win Probability: Detroit 58.4% | Spread: -3.5 | Over/Under: 48.5"*

---

### 7. ⚡ Instant Channel Zapper & Multi-Game Switching
- **Concept**: Rapid channel cycling using remote Up/Down or Next/Previous buttons while watching a live stream, without backing out to Kodi menus.

---

*Saved on: September 17, 2026*
