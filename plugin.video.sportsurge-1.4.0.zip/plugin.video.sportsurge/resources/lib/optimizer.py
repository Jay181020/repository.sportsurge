# -*- coding: utf-8 -*-
"""
One-Click Buffer & Speed Optimizer for Sportsurge Kodi Add-on.
Safely configures optimal Kodi 21 <cache> RAM buffering and network readfactors
tailored for Firestick and PC/Shield devices.
"""

import os
import shutil
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
    KODI_ENV = True
except ImportError:
    KODI_ENV = False


def get_userdata_path():
    """Returns absolute path to Kodi userdata folder."""
    if KODI_ENV:
        try:
            return os.path.abspath(xbmcvfs.translatePath('special://userdata'))
        except Exception:
            pass
    # Windows fallback
    app_data = os.getenv('APPDATA')
    if app_data:
        p = os.path.join(app_data, 'Kodi', 'userdata')
        if os.path.exists(p):
            return p
    return os.path.expanduser('~')


def get_advancedsettings_path():
    """Returns path to advancedsettings.xml."""
    return os.path.join(get_userdata_path(), 'advancedsettings.xml')


def is_android_firestick():
    """Detects if Kodi is running on Android / Fire TV stick."""
    if KODI_ENV:
        try:
            return xbmc.getCondVisibility('system.platform.android')
        except Exception:
            pass
    return False


PRESETS = {
    'firestick': {
        'name': 'Firestick / Android (128MB RAM Cache)',
        'memorysize': '134217728',   # 128 MB RAM (uses ~384 MB total RAM safe for 1GB/2GB sticks)
        'buffermode': '1',           # Buffer all internet streams
        'readfactor': '20',          # Fill cache 20x faster than playback speed
        'curltimeout': '15',
    },
    'pc': {
        'name': 'PC / Shield / 3GB+ RAM (256MB RAM Cache)',
        'memorysize': '268435456',   # 256 MB RAM
        'buffermode': '1',
        'readfactor': '20',
        'curltimeout': '20',
    }
}


def apply_buffer_preset(preset_key='auto'):
    """
    Applies the specified buffer preset to userdata/advancedsettings.xml.
    Backs up existing file before writing.
    Returns (success: bool, message: str)
    """
    if preset_key == 'auto':
        preset_key = 'firestick' if is_android_firestick() else 'pc'

    config = PRESETS.get(preset_key)
    if not config:
        return False, f"Unknown preset: {preset_key}"

    adv_path = get_advancedsettings_path()
    os.makedirs(os.path.dirname(adv_path), exist_ok=True)

    # Backup existing file
    if os.path.exists(adv_path):
        try:
            bak_path = adv_path + '.bak'
            shutil.copy2(adv_path, bak_path)
        except Exception:
            pass

    # Build or update XML
    root = None
    if os.path.exists(adv_path):
        try:
            tree = ET.parse(adv_path)
            root = tree.getroot()
        except Exception:
            root = None

    if root is None or root.tag != 'advancedsettings':
        root = ET.Element('advancedsettings', attrib={'version': '1.0'})

    # Update or add <cache> (Kodi 21 modern format)
    cache_elem = root.find('cache')
    if cache_elem is None:
        cache_elem = ET.SubElement(root, 'cache')

    for tag, val in [('buffermode', config['buffermode']),
                     ('memorysize', config['memorysize']),
                     ('readfactor', config['readfactor'])]:
        node = cache_elem.find(tag)
        if node is None:
            node = ET.SubElement(cache_elem, tag)
        node.text = val

    # Update or add <network>
    net_elem = root.find('network')
    if net_elem is None:
        net_elem = ET.SubElement(root, 'network')

    for tag, val in [('curlclienttimeout', config['curltimeout']),
                     ('curllowspeedtime', config['curltimeout'])]:
        node = net_elem.find(tag)
        if node is None:
            node = ET.SubElement(net_elem, tag)
        node.text = val

    # Write formatted XML
    tree = ET.ElementTree(root)
    ET.indent(tree, space="    ", level=0)
    try:
        tree.write(adv_path, encoding='utf-8', xml_declaration=True)
        return True, f"Configured {config['name']} successfully!"
    except Exception as e:
        return False, str(e)


def restore_backup():
    """Restores previous advancedsettings.xml.bak if available."""
    adv_path = get_advancedsettings_path()
    bak_path = adv_path + '.bak'
    if os.path.exists(bak_path):
        try:
            shutil.copy2(bak_path, adv_path)
            return True, "Restored previous settings from backup."
        except Exception as e:
            return False, f"Restore failed: {e}"
    return False, "No backup file found (.bak)."


def show_optimizer_dialog():
    """Kodi UI entry point for buffer optimizer."""
    if not KODI_ENV:
        return

    dialog = xbmcgui.Dialog()
    options = [
        "⚡ Auto-Detect & Optimize (Recommended)",
        "🔥 Firestick / Low-RAM Device Preset (128MB Buffer)",
        "💻 PC / Nvidia Shield Preset (256MB Buffer)",
        "↩️ Restore Previous Backup Settings"
    ]
    idx = dialog.select("Kodi Buffer & Stream Speed Optimizer", options)
    if idx == 0:
        success, msg = apply_buffer_preset('auto')
    elif idx == 1:
        success, msg = apply_buffer_preset('firestick')
    elif idx == 2:
        success, msg = apply_buffer_preset('pc')
    elif idx == 3:
        success, msg = restore_backup()
    else:
        return

    if success:
        dialog.ok(
            "Buffer Optimization Complete 🚀",
            f"{msg}\n\nImportant: Please restart Kodi to activate the new RAM cache and buffer settings!"
        )
    else:
        dialog.notification("Optimizer Error", msg, xbmcgui.NOTIFICATION_ERROR, 4000)
