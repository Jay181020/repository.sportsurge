# -*- coding: utf-8 -*-
"""
StreamEast scraper module for Sportsurge (v1.2.1).
Scrapes live sports events and 1080p/60fps player feeds from thestreameast.online.
Uses CookieJar to handle the auth.streamea.st SSO redirect seamlessly without Cloudflare blocks.
"""

import re
import json
import urllib.request
import urllib.parse
import http.cookiejar
from bs4 import BeautifulSoup

DEFAULT_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/124.0.0.0 Safari/537.36'
)

ACRONYMS = {'fc', 'afc', 'cf', 'sc', 'ufc', 'nfl', 'nba', 'mlb', 'nhl', 'wwe', 'f1', 'usa', 'la', 'ny', 'dc', 'unam'}

SPORT_MAP = {
    '14': ['nfl', 'cfb', 'football'],
    'basketball': ['nba', 'basketball'],
    '2': ['mlb', 'baseball'],
    'hockey': ['nhl', 'hockey'],
    'mma': ['ufc', 'mma'],
    'boxing': ['boxing'],
    '26': ['soccer'],
    'motorsports': ['f1', 'motorsports'],
    'wwe': ['wwe'],
}


def clean_team_name(name):
    """Cleans up team slug strings into display names (e.g. 'new-york-giants-1' -> 'New York Giants')."""
    name = re.sub(r'-e\d+', '', name)
    name = re.sub(r'-\d+$', '', name)
    words = name.replace('-', ' ').split()
    return ' '.join(w.upper() if w.lower() in ACRONYMS else (w.capitalize() if not w.isupper() else w) for w in words)


class StreamEastScraper:
    def __init__(self, user_agent=DEFAULT_UA, timeout=10):
        self.base_url = 'https://www.thestreameast.online'
        self.user_agent = user_agent or DEFAULT_UA
        self.timeout = timeout
        self.cj = http.cookiejar.CookieJar()
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cj))
        self.headers = {
            'User-Agent': self.user_agent,
            'Referer': self.base_url + '/v2/',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
        }
        self._session_ready = False

    def _ensure_session(self):
        """Visits /v2/ to establish session cookies required for iframe embedding."""
        if not self._session_ready:
            try:
                self.fetch(self.base_url + '/v2/')
                self._session_ready = True
            except Exception:
                pass

    def fetch(self, url):
        req = urllib.request.Request(url, headers=self.headers)
        with self.opener.open(req, timeout=self.timeout) as resp:
            return resp.read().decode('utf-8', errors='ignore')

    def get_live_events(self, category_id=None):
        """Scrapes live games from /v2/."""
        events = []
        try:
            html = self.fetch(self.base_url + '/v2/')
            self._session_ready = True
            soup = BeautifulSoup(html, 'html.parser')

            container = soup.select_one('#se-live-matches') or soup
            cards = container.select('.m-card')
            if not cards:
                cards = container.select(
                    'a[href*="/nfl/"], a[href*="/nba/"], a[href*="/soccer/"], '
                    'a[href*="/mlb/"], a[href*="/nhl/"], a[href*="/ufc/"], '
                    'a[href*="/boxing/"], a[href*="/f1/"], a[href*="/cfb/"], '
                    'a[href*="/other-events/"]'
                )

            for c in cards:
                link_node = c.select_one('a[href]') if c.name != 'a' else c
                if not link_node:
                    continue
                href = link_node.get('href', '')
                if not href or '-streams/' in href:
                    continue

                full_url = urllib.parse.urljoin(self.base_url, href)

                # Sport slug
                sport_slug = href.strip('/').split('/')[0].lower()
                if category_id and category_id != 'all':
                    allowed_slugs = SPORT_MAP.get(str(category_id).lower(), [str(category_id).lower()])
                    if not any(slug in sport_slug for slug in allowed_slugs):
                        continue

                sport_name = sport_slug.upper()
                if sport_name == 'CFB':
                    sport_name = 'College Football'
                elif sport_name == 'OTHER-EVENTS':
                    sport_name = 'Other Sports'

                # Extract teams & title
                team_names_attr = c.get('data-team-names', '') if c.name != 'a' else ''
                if team_names_attr and '|' in team_names_attr:
                    raw_teams = team_names_attr.split('|')
                    team1 = raw_teams[0].strip()
                    team2 = raw_teams[1].strip()
                    title = f"{team1} vs {team2}"
                    teams = [team1, team2]
                else:
                    aria = link_node.get('aria-label', '')
                    if aria and ' vs ' in aria:
                        parts = aria.split(' vs ')
                        team1 = parts[0].strip()
                        team2 = parts[1].strip()
                        title = f"{team1} vs {team2}"
                        teams = [team1, team2]
                    else:
                        names = [s.text.strip() for s in c.select('.m-card__name, [class*="team"], [class*="name"]') if s.text.strip()]
                        if len(names) >= 2:
                            team1 = clean_team_name(names[0])
                            team2 = clean_team_name(names[1])
                            title = f"{team1} vs {team2}"
                            teams = [team1, team2]
                        else:
                            slug = href.strip('/').split('/')[-1]
                            parts = slug.split('-vs-')
                            if len(parts) >= 2:
                                team1 = clean_team_name(parts[0])
                                team2 = clean_team_name(parts[1])
                                title = f"{team1} vs {team2}"
                                teams = [team1, team2]
                            else:
                                title = clean_team_name(slug)
                                teams = [title]

                # Extract logos
                mark_home = c.get('data-mark-home', '') if c.name != 'a' else ''
                mark_away = c.get('data-mark-away', '') if c.name != 'a' else ''
                icon = urllib.parse.urljoin(self.base_url, mark_home) if mark_home else ''
                fanart = urllib.parse.urljoin(self.base_url, mark_away) if mark_away else icon
                if not icon:
                    imgs = [urllib.parse.urljoin(self.base_url, img['src']) for img in c.find_all('img', src=True)]
                    icon = imgs[0] if imgs else ''
                    fanart = imgs[1] if len(imgs) > 1 else icon

                # Extract time / status / timestamp
                pill = c.select_one('.m-card__pill') if c.name != 'a' else None
                if pill:
                    time_text = ' '.join(pill.text.split())
                else:
                    time_node = c.select_one('.m-card__time, [class*="time"], [class*="status"]')
                    time_text = time_node.text.strip() if time_node else 'LIVE'

                classes = c.get('class', []) if c.name != 'a' else []
                is_live_card = 'm-card--live' in classes or (pill and 'live' in pill.text.lower())
                data_time = c.get('data-time') if c.name != 'a' else ''
                start_ts = float(data_time) if data_time and data_time.isdigit() else None

                events.append({
                    'title': title,
                    'teams': teams,
                    'category_name': sport_name,
                    'category_id': sport_slug,
                    'time_text': time_text,
                    'start_timestamp': start_ts,
                    'is_live': is_live_card,
                    'stream_count': 1,
                    'icon': icon,
                    'fanart': fanart,
                    'url': f"streameast://url={urllib.parse.quote(full_url)}",
                    'streameast_url': full_url,
                    'source': 'streameast'
                })

        except Exception:
            pass

        return events

    def get_match_streams(self, match_url):
        """Fetches match page and extracts player iframes for Server 1 and alternative servers."""
        if match_url.startswith('streameast://url='):
            match_url = urllib.parse.unquote(match_url.replace('streameast://url=', ''))

        self._ensure_session()
        streams = []
        try:
            html = self.fetch(match_url)
            soup = BeautifulSoup(html, 'html.parser')

            is_gate = 'showProGate: true' in html or bool(soup.select_one('[data-state="gate"], .se-player--gate-bg'))

            # 1. Main player iframe (Server 1) - only if not locked by Pro Gate
            if not is_gate:
                for ifr in soup.find_all('iframe'):
                    src = ifr.get('src', '').strip()
                    if src and 'sso' not in src and not src.startswith('about:'):
                        streams.append({
                            'title': '[StreamEast HD] Server 1 (1080p 60fps)',
                            'site_name': 'StreamEast',
                            'tier': 'Gold',
                            'resolution': '1080p',
                            'fps': '60fps',
                            'bitrate': 'HD',
                            'language': 'EN',
                            'ads': 'No ads',
                            'url': src,
                            'match_url': match_url
                        })
                        break

            # 2. Alternative server sources (.stream-alt-item) - strictly unlocked free servers
            alt_items = soup.select('.stream-alt-item')
            for item in alt_items:
                if len(streams) >= 4:
                    break
                # Skip locked Pro / Premium servers
                if 'stream-alt-item-pro' in item.get('class', []) or item.select_one('.stream-alt-pro-icon, .fa-crown'):
                    continue

                href = item.get('href', '')
                if not href or href.endswith('/1'):
                    continue

                name_elem = item.select_one('.stream-alt-name')
                alt_name = name_elem.text.strip() if name_elem else f'Server {len(streams) + 1}'
                sub_url = urllib.parse.urljoin(self.base_url, href)
                try:
                    sub_html = self.fetch(sub_url)
                    if 'showProGate: true' in sub_html:
                        continue
                    sub_soup = BeautifulSoup(sub_html, 'html.parser')
                    for ifr in sub_soup.find_all('iframe'):
                        src = ifr.get('src', '').strip()
                        if src and 'sso' not in src and not src.startswith('about:') and not any(s['url'] == src for s in streams):
                            streams.append({
                                'title': f'[StreamEast HD] {alt_name} (1080p 60fps)',
                                'site_name': 'StreamEast',
                                'tier': 'Gold',
                                'resolution': '1080p',
                                'fps': '60fps',
                                'bitrate': 'HD',
                                'language': 'EN',
                                'ads': 'No ads',
                                'url': src,
                                'match_url': match_url
                            })
                            break
                except Exception:
                    pass

            # 3. Check window.SE_PV_SEQ script config fallback
            cfg_match = re.search(r'window\.SE_PV_SEQ\s*=\s*({[^}]+})', html)
            if cfg_match:
                try:
                    cfg = json.loads(cfg_match.group(1))
                    player_url = cfg.get('url')
                    if player_url and not any(s['url'] == player_url for s in streams):
                        streams.append({
                            'title': f"[StreamEast HD] Server {len(streams) + 1} (Direct 1080p)",
                            'site_name': 'StreamEast',
                            'tier': 'Gold',
                            'resolution': '1080p',
                            'fps': '60fps',
                            'bitrate': 'HD',
                            'language': 'EN',
                            'ads': 'No ads',
                            'url': player_url,
                            'match_url': match_url
                        })
                except Exception:
                    pass

        except Exception:
            pass

        return streams
