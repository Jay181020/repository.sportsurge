# -*- coding: utf-8 -*-
"""
Kodi player integration for Sportsurge.
Configures inputstream.adaptive for HLS streams and sets resolved URL for playback.
"""

import sys
import urllib.parse

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    KODI_AVAILABLE = True
except ImportError:
    KODI_AVAILABLE = False

from resolvers import StreamResolver


class SportsurgePlayer:
    def __init__(self, handle, user_agent='', timeout=10, use_proxy=False, proxy_url=''):
        self.handle = handle
        self.user_agent = user_agent
        self.timeout = timeout
        self.use_proxy = use_proxy
        self.proxy_url = proxy_url
        self.resolver = StreamResolver(
            user_agent=user_agent,
            timeout=timeout,
            use_proxy=use_proxy,
            proxy_url=proxy_url
        )


    def play_resolved(self, resolved_url, headers=None, title='Live Stream', icon='', referer=''):
        """
        Directly sets resolved URL for Kodi playback with inputstream.adaptive
        without re-scraping the stream URL.
        """
        if not KODI_AVAILABLE:
            print(f"[SportsurgePlayer] Direct Play: {resolved_url}")
            return resolved_url

        try:
            clean_url = resolved_url.split('|')[0]
            listitem = xbmcgui.ListItem(path=clean_url)
            listitem.setPath(clean_url)
            listitem.setProperty('IsPlayable', 'true')
            listitem.setInfo('video', {
                'title': title,
                'mediatype': 'video',
                'playcount': 0
            })

            if icon:
                listitem.setArt({'icon': icon, 'thumb': icon})

            # Configure inputstream.adaptive for rock-solid HLS playback
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
            listitem.setProperty('mimetype', 'application/vnd.apple.mpegurl')
            listitem.setContentLookup(False)

            hdrs = dict(headers or {})
            if self.user_agent:
                hdrs.setdefault('User-Agent', self.user_agent)
            hdrs.setdefault('Connection', 'keep-alive')
            if referer and 'Referer' not in hdrs:
                hdrs['Referer'] = referer

            header_str = '&'.join(f"{k}={urllib.parse.quote(str(v))}" for k, v in hdrs.items())
            listitem.setProperty('inputstream.adaptive.stream_headers', header_str)
            listitem.setProperty('inputstream.adaptive.manifest_headers', header_str)
            listitem.setProperty('inputstream.adaptive.license_key', '|' + header_str)

            # 1. Resolve via Kodi directory handle
            if self.handle and self.handle > 0:
                try:
                    xbmcplugin.setResolvedUrl(self.handle, True, listitem)
                except Exception:
                    pass

            # 2. Direct Player fallback to ensure playback ALWAYS starts
            xbmc.sleep(300)
            if not xbmc.Player().isPlaying():
                xbmc.Player().play(resolved_url, listitem, False)

            return True
        except Exception as e:
            xbmcgui.Dialog().notification('Sportsurge', f'Playback error: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 3500)
            if self.handle and self.handle > 0:
                try:
                    xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                except Exception:
                    pass
            return False


    def play(self, stream_url, title='Live Stream', icon='', referer='https://v2.sportsurge.net/'):
        """
        Resolves stream URL to playable .m3u8 and passes to Kodi's player.
        """
        if not stream_url:
            return False

        # If already a direct .m3u8 or .mpd URL, bypass re-scraping
        clean = stream_url.split('|')[0].lower()
        if clean.endswith('.m3u8') or clean.endswith('.mpd') or '.m3u8?' in clean or '.mpd?' in clean:
            return self.play_resolved(stream_url, title=title, icon=icon, referer=referer)

        if not KODI_AVAILABLE:
            print(f"[SportsurgePlayer] Resolving: {stream_url}")
            resolved_url, headers = self.resolver.resolve(stream_url, referer=referer)
            print(f"[SportsurgePlayer] Resolved URL: {resolved_url}")
            return resolved_url

        progress = xbmcgui.DialogProgress()
        progress.create('Sportsurge', 'Resolving stream link...')

        try:
            progress.update(25, 'Connecting to provider...')
            resolved_url, headers = self.resolver.resolve(stream_url, referer=referer)
            progress.update(80, 'Configuring player...')

            if not resolved_url:
                progress.close()
                xbmcgui.Dialog().notification('Sportsurge', 'Failed to resolve stream. Try another link.', xbmcgui.NOTIFICATION_WARNING, 3500)
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return False

            progress.update(100, 'Starting playback...')
            progress.close()

            return self.play_resolved(resolved_url, headers=headers, title=title, icon=icon, referer=referer)

        except Exception as e:
            if progress:
                progress.close()
            xbmcgui.Dialog().notification('Sportsurge', f'Playback error: {str(e)}', xbmcgui.NOTIFICATION_ERROR, 4000)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
            return False

